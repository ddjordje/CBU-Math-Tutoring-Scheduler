function authenticate() {
    var usrname = document.getElementById("userid").value;
    var pd = document.getElementById("pswrd").value;
    $.get("http://localhost:4000/api/tutorslogin", function(data, status){
        console.log(usrname);
        data.forEach(tutor => {
            if(tutor.username == usrname && tutor.password == pd)
             {
                 window.open('tutorpage.html')/*opens the target page while Id & password matches*/
                 $.post("http://localhost:4000/api/temptutor", {username : usrname}, function(data, status){
                    console.log("1 record changed");
                });
             }
            // alert("Error Password or Username")/*displays error message*/
        });
    });
}

