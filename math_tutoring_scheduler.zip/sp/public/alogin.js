function authenticate(form)/*function to check userid & password*/
{
 /*the following code checkes whether the entered userid and password are matching*/
 if(form.userid.value == "baumeyerj" && form.pswrd.value == "tutoring")
  {
      var usrname = "baumeyerj";
    $.post("http://localhost:4000/api/tempadmin", {username : usrname}, function(data, status){
        console.log("1 record changed");
    });
    window.open('adminpage.html')/*opens the target page while Id & password matches*/
}
 else
 {
   alert("Error Password or Username")/*displays error message*/
  }
  
}