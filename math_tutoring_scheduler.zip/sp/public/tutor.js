reload();

function reload() {
    $.get("http://localhost:4000/api/courses", function(data, status){
        data.forEach(course => {
            addCourse(course.course);
            console.log(course);
        });
    });
}

function tutors() {
  var tutors = document.getElementById("listoftutors");
  
  var len = tutors.length;
  for (var i = 0; i < len; i++) {
      tutors.remove(0);
  }
  addTutor("");
    $.get("http://localhost:4000/api/tutors", function(data, status){
        var courses = document.getElementById("listofcourses");
        
        data.forEach(tutor => {
            var c = $("option:selected", courses).text();
            if(tutor[c] == 1)
            {
            addTutor(tutor.tutorname);
            }
            console.log(tutor);
        });
    });
}

function dates() {

    var today = new Date();
    var tutors = document.getElementById("listoftutors");
    var t = $("option:selected", tutors).text();
    var dates = document.getElementById("listofdates");

    console.log(t);

    $.get("http://localhost:4000/api/tutorslogin", function(data, status){
        data.forEach(tutor => {
            if(tutor.name == t)
        {
            document.getElementById('desclbl').innerHTML = tutor.description;
        }
            
        });
    });

    var len = dates.length;
    for (var i = 0; i < len; i++) {
        dates.remove(0);
    }

    if(today.getDay() == 6){
    $.get("http://localhost:4000/api/monday", function(data, status){
        data.forEach(tutor => {
            if (tutor.working == 1 && tutor.tutorname == t)
            {
              addDate(2);
              console.log(tutor);
            }
            console.log(tutor);
        });
    });
    $.get("http://localhost:4000/api/tuesday", function(data, status){
        data.forEach(tutor => {
                if (tutor.working == 1 && tutor.tutorname == t)
                {
                addDate(3);
                console.log(tutor);
                }
        });
    });
    $.get("http://localhost:4000/api/wednesday", function(data, status){
        data.forEach(tutor => {
            if (tutor.working == 1 && tutor.tutorname == t)
            {
              addDate(4);
              console.log(tutor);
            }
            
        });
    });

    $.get("http://localhost:4000/api/thursday", function(data, status){
        data.forEach(tutor => {
            if (tutor.working == 1 && tutor.tutorname == t)
            {
              addDate(5);
              console.log(tutor);
            }
            
        });
    });
    $.get("http://localhost:4000/api/friday", function(data, status){
        data.forEach(tutor => {
            if (tutor.working == 1 && tutor.tutorname == t)
            {
              addDate(6);
              console.log(tutor);
            }
            
        });
    });
    $.get("http://localhost:4000/api/saturday", function(data, status){
        data.forEach(tutor => {
            if (tutor.working == 1 && tutor.tutorname == t)
            {
              addDate(7);
              console.log(tutor);
            }
            
        });
    });
    }
    else if(today.getDay() == 0){
        $.get("http://localhost:4000/api/tuesday", function(data, status){
            data.forEach(tutor => {
                if (tutor.working == 1 && tutor.tutorname == t)
                {
                  addDate(2);
                  console.log(tutor);
                }
                console.log(tutor);
            });
        });
        $.get("http://localhost:4000/api/wednesday", function(data, status){
            data.forEach(tutor => {
                    if (tutor.working == 1 && tutor.tutorname == t)
                    {
                    addDate(3);
                    console.log(tutor);
                    }
            });
        });
        $.get("http://localhost:4000/api/thursday", function(data, status){
            data.forEach(tutor => {
                if (tutor.working == 1 && tutor.tutorname == t)
                {
                  addDate(4);
                  console.log(tutor);
                }
                
            });
        });
        $.get("http://localhost:4000/api/friday", function(data, status){
            data.forEach(tutor => {
                if (tutor.working == 1 && tutor.tutorname == t)
                {
                  addDate(5);
                  console.log(tutor);
                }
                
            });
        });
        $.get("http://localhost:4000/api/saturday", function(data, status){
            data.forEach(tutor => {
                if (tutor.working == 1 && tutor.tutorname == t)
                {
                  addDate(6);
                  console.log(tutor);
                }
                
            });
        });
        $.get("http://localhost:4000/api/sunday", function(data, status){
            data.forEach(tutor => {
                if (tutor.working == 1 && tutor.tutorname == t)
                {
                  addDate(7);
                  console.log(tutor);
                }
                
            });
        });
        }
        if(today.getDay() == 1){
            $.get("http://localhost:4000/api/wednesday", function(data, status){
                data.forEach(tutor => {
                    if (tutor.working == 1 && tutor.tutorname == t)
                    {
                      addDate(2);
                      console.log(tutor);
                    }
                    console.log(tutor);
                });
            });
            $.get("http://localhost:4000/api/thursday", function(data, status){
                data.forEach(tutor => {
                        if (tutor.working == 1 && tutor.tutorname == t)
                        {
                        addDate(3);
                        console.log(tutor);
                        }
                });
            });
            $.get("http://localhost:4000/api/friday", function(data, status){
                data.forEach(tutor => {
                    if (tutor.working == 1 && tutor.tutorname == t)
                    {
                      addDate(4);
                      console.log(tutor);
                    }
                    
                });
            });
        
            $.get("http://localhost:4000/api/saturday", function(data, status){
                data.forEach(tutor => {
                    if (tutor.working == 1 && tutor.tutorname == t)
                    {
                      addDate(5);
                      console.log(tutor);
                    }
                    
                });
            });
            $.get("http://localhost:4000/api/sunday", function(data, status){
                data.forEach(tutor => {
                    if (tutor.working == 1 && tutor.tutorname == t)
                    {
                      addDate(6);
                      console.log(tutor);
                    }
                    
                });
            });
            $.get("http://localhost:4000/api/monday", function(data, status){
                data.forEach(tutor => {
                    if (tutor.working == 1 && tutor.tutorname == t)
                    {
                      addDate(7);
                      console.log(tutor);
                    }
                    
                });
            });
            }
            if(today.getDay() == 2){
                $.get("http://localhost:4000/api/thursday", function(data, status){
                    data.forEach(tutor => {
                        if (tutor.working == 1 && tutor.tutorname == t)
                        {
                          addDate(2);
                          console.log(tutor);
                        }
                        console.log(tutor);
                    });
                });
                $.get("http://localhost:4000/api/friday", function(data, status){
                    data.forEach(tutor => {
                            if (tutor.working == 1 && tutor.tutorname == t)
                            {
                            addDate(3);
                            console.log(tutor);
                            }
                    });
                });
                $.get("http://localhost:4000/api/saturday", function(data, status){
                    data.forEach(tutor => {
                        if (tutor.working == 1 && tutor.tutorname == t)
                        {
                          addDate(4);
                          console.log(tutor);
                        }
                        
                    });
                });
            
                $.get("http://localhost:4000/api/sunday", function(data, status){
                    data.forEach(tutor => {
                        if (tutor.working == 1 && tutor.tutorname == t)
                        {
                          addDate(5);
                          console.log(tutor);
                        }
                        
                    });
                });
                $.get("http://localhost:4000/api/monday", function(data, status){
                    data.forEach(tutor => {
                        if (tutor.working == 1 && tutor.tutorname == t)
                        {
                          addDate(6);
                          console.log(tutor);
                        }
                        
                    });
                });
                $.get("http://localhost:4000/api/tuesday", function(data, status){
                    data.forEach(tutor => {
                        if (tutor.working == 1 && tutor.tutorname == t)
                        {
                          addDate(7);
                          console.log(tutor);
                        }
                        
                    });
                });
                }
                if(today.getDay() == 3){
                    $.get("http://localhost:4000/api/friday", function(data, status){
                        data.forEach(tutor => {
                            if (tutor.working == 1 && tutor.tutorname == t)
                            {
                              addDate(2);
                              console.log(tutor);
                            }
                            console.log(tutor);
                        });
                    });
                    $.get("http://localhost:4000/api/saturday", function(data, status){
                        data.forEach(tutor => {
                                if (tutor.working == 1 && tutor.tutorname == t)
                                {
                                addDate(3);
                                console.log(tutor);
                                }
                        });
                    });
                    $.get("http://localhost:4000/api/sunday", function(data, status){
                        data.forEach(tutor => {
                            if (tutor.working == 1 && tutor.tutorname == t)
                            {
                              addDate(4);
                              console.log(tutor);
                            }
                            
                        });
                    });
                
                    $.get("http://localhost:4000/api/monday", function(data, status){
                        data.forEach(tutor => {
                            if (tutor.working == 1 && tutor.tutorname == t)
                            {
                              addDate(5);
                              console.log(tutor);
                            }
                            
                        });
                    });
                    $.get("http://localhost:4000/api/tuesday", function(data, status){
                        data.forEach(tutor => {
                            if (tutor.working == 1 && tutor.tutorname == t)
                            {
                              addDate(6);
                              console.log(tutor);
                            }
                            
                        });
                    });
                    $.get("http://localhost:4000/api/wednesday", function(data, status){
                        data.forEach(tutor => {
                            if (tutor.working == 1 && tutor.tutorname == t)
                            {
                              addDate(7);
                              console.log(tutor);
                            }
                            
                        });
                    });
                    }
        else if(today.getDay() == 4){
            $.get("http://localhost:4000/api/saturday", function(data, status){
                data.forEach(tutor => {
                    if (tutor.working == 1 && tutor.tutorname == t)
                    {
                      addDate(2);
                      console.log(tutor);
                    }
                    console.log(tutor);
                });
            });
            $.get("http://localhost:4000/api/sunday", function(data, status){
                data.forEach(tutor => {
                        if (tutor.working == 1 && tutor.tutorname == t)
                        {
                        addDate(3);
                        console.log(tutor);
                        }
                });
            });
            $.get("http://localhost:4000/api/monday", function(data, status){
                data.forEach(tutor => {
                        if (tutor.working == 1 && tutor.tutorname == t)
                        {
                        addDate(4);
                        console.log(tutor);
                        }
                });
            });
            $.get("http://localhost:4000/api/tuesday", function(data, status){
                data.forEach(tutor => {
                        if (tutor.working == 1 && tutor.tutorname == t)
                        {
                        addDate(5);
                        console.log(tutor);
                        }
                });
            });
            $.get("http://localhost:4000/api/wednesday", function(data, status){
                data.forEach(tutor => {
                        if (tutor.working == 1 && tutor.tutorname == t)
                        {
                        addDate(6);
                        console.log(tutor);
                        }
                });
            });
            $.get("http://localhost:4000/api/thursday", function(data, status){
                data.forEach(tutor => {
                        if (tutor.working == 1 && tutor.tutorname == t)
                        {
                        addDate(7);
                        console.log(tutor);
                        }
                });
            });

            }
            else if(today.getDay() == 5){
                $.get("http://localhost:4000/api/sunday", function(data, status){
                    data.forEach(tutor => {
                        if (tutor.working == 1 && tutor.tutorname == t)
                        {
                          addDate(2);
                          console.log(tutor);
                        }
                        console.log(tutor);
                    });
                });
                $.get("http://localhost:4000/api/monday", function(data, status){
                    data.forEach(tutor => {
                            if (tutor.working == 1 && tutor.tutorname == t)
                            {
                            addDate(3);
                            console.log(tutor);
                            }
                    });
                });
                $.get("http://localhost:4000/api/tuesday", function(data, status){
                    data.forEach(tutor => {
                            if (tutor.working == 1 && tutor.tutorname == t)
                            {
                            addDate(4);
                            console.log(tutor);
                            }
                    });
                });
                $.get("http://localhost:4000/api/wednesday", function(data, status){
                    data.forEach(tutor => {
                            if (tutor.working == 1 && tutor.tutorname == t)
                            {
                            addDate(5);
                            console.log(tutor);
                            }
                    });
                });
                $.get("http://localhost:4000/api/thursday", function(data, status){
                    data.forEach(tutor => {
                            if (tutor.working == 1 && tutor.tutorname == t)
                            {
                            addDate(6);
                            console.log(tutor);
                            }
                    });
                });
                $.get("http://localhost:4000/api/friday", function(data, status){
                    data.forEach(tutor => {
                            if (tutor.working == 1 && tutor.tutorname == t)
                            {
                            addDate(7);
                            console.log(tutor);
                            }
                    });
                });
            
    
                }
}

function times() {

    var dates = document.getElementById("listofdates");
    var selectedDate = $("option:selected", dates).text();
    console.log(selectedDate);
    var date = selectedDate.split("/");
    var month = parseInt(date[0]);
    var m = month - 1;
    var d = new Date(date[2],m,date[1]);
    var tutors = document.getElementById("listoftutors");
    var selectedTutor = $("option:selected", tutors).text();
    console.log(d);
    console.log(d.getDay());
    console.log(date);
    var times = document.getElementById("listoftimes");
  
    var len = times.length;
    for (var i = 0; i < len; i++) {
        times.remove(0);
    }
    if(d.getDay() == 2){
    $.get("http://localhost:4000/api/tuesday", function(data, status){
        data.forEach(tutor => {
          if(tutor.tutorname == selectedTutor){
            if (tutor.tutorname == selectedTutor && tutor["8:00"] == 1)
            {
              addTime("8:00");
            }
            if (tutor["8:30"] == 1)
            {
              addTime("8:30");
            }
            if (tutor["9:00"] == 1)
            {
              addTime("9:00");
            }
            if (tutor["9:30"] == 1)
            {
              addTime("9:30");
            }
            if (tutor["10:00"] == 1)
            {
              addTime("10:00");
            }
            if (tutor["10:30"] == 1)
            {
              addTime("10:30");
            }
            if (tutor["11:00"] == 1)
            {
              addTime("11:00");
            }
            if (tutor["11:30"] == 1)
            {
              addTime("11:30");
            }
            if (tutor["12:00"] == 1)
            {
              addTime("12:00");
            }
            if (tutor["12:30"] == 1)
            {
              addTime("12:30");
            }
            if (tutor["13:00"] == 1)
            {
              addTime("13:00");
            }
            if (tutor["13:30"] == 1)
            {
              addTime("13:30");
            }
            if (tutor["14:00"] == 1)
            {
              addTime("14:00");
            }
            if (tutor["14:30"] == 1)
            {
              addTime("14:30");
            }
            if (tutor["15:00"] == 1)
            {
              addTime("15:00");
            }
            if (tutor["15:30"] == 1)
            {
              addTime("15:30");
            }
            if (tutor["16:00"] == 1)
            {
              addTime("16:30");
            }
            if (tutor["17:00"] == 1)
            {
              addTime("17:00");
            }
            if (tutor["17:30"] == 1)
            {
              addTime("17:30");
            }
            if (tutor["18:00"] == 1)
            {
              addTime("18:00");
            }
            if (tutor["18:30"] == 1)
            {
              addTime("18:30");
            }
            if (tutor["19:00"] == 1)
            {
              addTime("19:00");
            }
            if (tutor["19:30"] == 1)
            {
              addTime("19:30");
            }
            if (tutor["20:00"] == 1)
            {
              addTime("20:00");
            }
          }

        });
    });
    }

    else if(d.getDay() == 0){
        $.get("http://localhost:4000/api/sunday", function(data, status){
            data.forEach(tutor => {
              if(tutor.tutorname == selectedTutor){
                if (tutor["8:00"] == 1)
                {
                  addTime("8:00");
                }
                if (tutor["8:30"] == 1)
                {
                  addTime("8:30");
                }
                if (tutor["9:00"] == 1)
                {
                  addTime("9:00");
                }
                if (tutor["9:30"] == 1)
                {
                  addTime("9:30");
                }
                if (tutor["10:00"] == 1)
                {
                  addTime("10:00");
                }
                if (tutor["10:30"] == 1)
                {
                  addTime("10:30");
                }
                if (tutor["11:00"] == 1)
                {
                  addTime("11:00");
                }
                if (tutor["11:30"] == 1)
                {
                  addTime("11:30");
                }
                if (tutor["12:00"] == 1)
                {
                  addTime("12:00");
                }
                if (tutor["12:30"] == 1)
                {
                  addTime("12:30");
                }
                if (tutor["13:00"] == 1)
                {
                  addTime("13:00");
                }
                if (tutor["13:30"] == 1)
                {
                  addTime("13:30");
                }
                if (tutor["14:00"] == 1)
                {
                  addTime("14:00");
                }
                if (tutor["14:30"] == 1)
                {
                  addTime("14:30");
                }
                if (tutor["15:00"] == 1)
                {
                  addTime("15:00");
                }
                if (tutor["15:30"] == 1)
                {
                  addTime("15:30");
                }
                if (tutor["16:00"] == 1)
                {
                  addTime("16:30");
                }
                if (tutor["17:00"] == 1)
                {
                  addTime("17:00");
                }
                if (tutor["17:30"] == 1)
                {
                  addTime("17:30");
                }
                if (tutor["18:00"] == 1)
                {
                  addTime("18:00");
                }
                if (tutor["18:30"] == 1)
                {
                  addTime("18:30");
                }
                if (tutor["19:00"] == 1)
                {
                  addTime("19:00");
                }
                if (tutor["19:30"] == 1)
                {
                  addTime("19:30");
                }
                if (tutor["20:00"] == 1)
                {
                  addTime("20:00");
                }
              }
            });
        });
        }
        else if(d.getDay() == 1){
            $.get("http://localhost:4000/api/monday", function(data, status){
                data.forEach(tutor => {

                  if(tutor.tutorname == selectedTutor){
                    if (tutor["8:00"] == 1)
                    {
                      addTime("8:00");
                    }
                    if (tutor["8:30"] == 1)
                    {
                      addTime("8:30");
                    }
                    if (tutor["9:00"] == 1)
                    {
                      addTime("9:00");
                    }
                    if (tutor["9:30"] == 1)
                    {
                      addTime("9:30");
                    }
                    if (tutor["10:00"] == 1)
                    {
                      addTime("10:00");
                    }
                    if (tutor["10:30"] == 1)
                    {
                      addTime("10:30");
                    }
                    if (tutor["11:00"] == 1)
                    {
                      addTime("11:00");
                    }
                    if (tutor["11:30"] == 1)
                    {
                      addTime("11:30");
                    }
                    if (tutor["12:00"] == 1)
                    {
                      addTime("12:00");
                    }
                    if (tutor["12:30"] == 1)
                    {
                      addTime("12:30");
                    }
                    if (tutor["13:00"] == 1)
                    {
                      addTime("13:00");
                    }
                    if (tutor["13:30"] == 1)
                    {
                      addTime("13:30");
                    }
                    if (tutor["14:00"] == 1)
                    {
                      addTime("14:00");
                    }
                    if (tutor["14:30"] == 1)
                    {
                      addTime("14:30");
                    }
                    if (tutor["15:00"] == 1)
                    {
                      addTime("15:00");
                    }
                    if (tutor["15:30"] == 1)
                    {
                      addTime("15:30");
                    }
                    if (tutor["16:00"] == 1)
                    {
                      addTime("16:30");
                    }
                    if (tutor["17:00"] == 1)
                    {
                      addTime("17:00");
                    }
                    if (tutor["17:30"] == 1)
                    {
                      addTime("17:30");
                    }
                    if (tutor["18:00"] == 1)
                    {
                      addTime("18:00");
                    }
                    if (tutor["18:30"] == 1)
                    {
                      addTime("18:30");
                    }
                    if (tutor["19:00"] == 1)
                    {
                      addTime("19:00");
                    }
                    if (tutor["19:30"] == 1)
                    {
                      addTime("19:30");
                    }
                    if (tutor["20:00"] == 1)
                    {
                      addTime("20:00");
                    }
                  }
                });
            });
            }

            else if(d.getDay() == 3){
                $.get("http://localhost:4000/api/wednesday", function(data, status){
                    data.forEach(tutor => {
                      if(tutor.tutorname == selectedTutor){
                        if (tutor["8:00"] == 1)
                        {
                          addTime("8:00");
                        }
                        if (tutor["8:30"] == 1)
                        {
                          addTime("8:30");
                        }
                        if (tutor["9:00"] == 1)
                        {
                          addTime("9:00");
                        }
                        if (tutor["9:30"] == 1)
                        {
                          addTime("9:30");
                        }
                        if (tutor["10:00"] == 1)
                        {
                          addTime("10:00");
                        }
                        if (tutor["10:30"] == 1)
                        {
                          addTime("10:30");
                        }
                        if (tutor["11:00"] == 1)
                        {
                          addTime("11:00");
                        }
                        if (tutor["11:30"] == 1)
                        {
                          addTime("11:30");
                        }
                        if (tutor["12:00"] == 1)
                        {
                          addTime("12:00");
                        }
                        if (tutor["12:30"] == 1)
                        {
                          addTime("12:30");
                        }
                        if (tutor["13:00"] == 1)
                        {
                          addTime("13:00");
                        }
                        if (tutor["13:30"] == 1)
                        {
                          addTime("13:30");
                        }
                        if (tutor["14:00"] == 1)
                        {
                          addTime("14:00");
                        }
                        if (tutor["14:30"] == 1)
                        {
                          addTime("14:30");
                        }
                        if (tutor["15:00"] == 1)
                        {
                          addTime("15:00");
                        }
                        if (tutor["15:30"] == 1)
                        {
                          addTime("15:30");
                        }
                        if (tutor["16:00"] == 1)
                        {
                          addTime("16:30");
                        }
                        if (tutor["17:00"] == 1)
                        {
                          addTime("17:00");
                        }
                        if (tutor["17:30"] == 1)
                        {
                          addTime("17:30");
                        }
                        if (tutor["18:00"] == 1)
                        {
                          addTime("18:00");
                        }
                        if (tutor["18:30"] == 1)
                        {
                          addTime("18:30");
                        }
                        if (tutor["19:00"] == 1)
                        {
                          addTime("19:00");
                        }
                        if (tutor["19:30"] == 1)
                        {
                          addTime("19:30");
                        }
                        if (tutor["20:00"] == 1)
                        {
                          addTime("20:00");
                        }
                      }
                    });
                });
                }
                else if(d.getDay() == 4){
                    $.get("http://localhost:4000/api/thursday", function(data, status){
                        data.forEach(tutor => {
                          if(tutor.tutorname == selectedTutor){
                            if (tutor["8:00"] == 1)
                            {
                              addTime("8:00");
                            }
                            if (tutor["8:30"] == 1)
                            {
                              addTime("8:30");
                            }
                            if (tutor["9:00"] == 1)
                            {
                              addTime("9:00");
                            }
                            if (tutor["9:30"] == 1)
                            {
                              addTime("9:30");
                            }
                            if (tutor["10:00"] == 1)
                            {
                              addTime("10:00");
                            }
                            if (tutor["10:30"] == 1)
                            {
                              addTime("10:30");
                            }
                            if (tutor["11:00"] == 1)
                            {
                              addTime("11:00");
                            }
                            if (tutor["11:30"] == 1)
                            {
                              addTime("11:30");
                            }
                            if (tutor["12:00"] == 1)
                            {
                              addTime("12:00");
                            }
                            if (tutor["12:30"] == 1)
                            {
                              addTime("12:30");
                            }
                            if (tutor["13:00"] == 1)
                            {
                              addTime("13:00");
                            }
                            if (tutor["13:30"] == 1)
                            {
                              addTime("13:30");
                            }
                            if (tutor["14:00"] == 1)
                            {
                              addTime("14:00");
                            }
                            if (tutor["14:30"] == 1)
                            {
                              addTime("14:30");
                            }
                            if (tutor["15:00"] == 1)
                            {
                              addTime("15:00");
                            }
                            if (tutor["15:30"] == 1)
                            {
                              addTime("15:30");
                            }
                            if (tutor["16:00"] == 1)
                            {
                              addTime("16:30");
                            }
                            if (tutor["17:00"] == 1)
                            {
                              addTime("17:00");
                            }
                            if (tutor["17:30"] == 1)
                            {
                              addTime("17:30");
                            }
                            if (tutor["18:00"] == 1)
                            {
                              addTime("18:00");
                            }
                            if (tutor["18:30"] == 1)
                            {
                              addTime("18:30");
                            }
                            if (tutor["19:00"] == 1)
                            {
                              addTime("19:00");
                            }
                            if (tutor["19:30"] == 1)
                            {
                              addTime("19:30");
                            }
                            if (tutor["20:00"] == 1)
                            {
                              addTime("20:00");
                            }
                          }                
                        });
                    });
                    }
                    else if(d.getDay() == 5){
                        $.get("http://localhost:4000/api/friday", function(data, status){
                            data.forEach(tutor => {
                              if(tutor.tutorname == selectedTutor){
                                if (tutor["8:00"] == 1)
                                {
                                  addTime("8:00");
                                }
                                if (tutor["8:30"] == 1)
                                {
                                  addTime("8:30");
                                }
                                if (tutor["9:00"] == 1)
                                {
                                  addTime("9:00");
                                }
                                if (tutor["9:30"] == 1)
                                {
                                  addTime("9:30");
                                }
                                if (tutor["10:00"] == 1)
                                {
                                  addTime("10:00");
                                }
                                if (tutor["10:30"] == 1)
                                {
                                  addTime("10:30");
                                }
                                if (tutor["11:00"] == 1)
                                {
                                  addTime("11:00");
                                }
                                if (tutor["11:30"] == 1)
                                {
                                  addTime("11:30");
                                }
                                if (tutor["12:00"] == 1)
                                {
                                  addTime("12:00");
                                }
                                if (tutor["12:30"] == 1)
                                {
                                  addTime("12:30");
                                }
                                if (tutor["13:00"] == 1)
                                {
                                  addTime("13:00");
                                }
                                if (tutor["13:30"] == 1)
                                {
                                  addTime("13:30");
                                }
                                if (tutor["14:00"] == 1)
                                {
                                  addTime("14:00");
                                }
                                if (tutor["14:30"] == 1)
                                {
                                  addTime("14:30");
                                }
                                if (tutor["15:00"] == 1)
                                {
                                  addTime("15:00");
                                }
                                if (tutor["15:30"] == 1)
                                {
                                  addTime("15:30");
                                }
                                if (tutor["16:00"] == 1)
                                {
                                  addTime("16:30");
                                }
                                if (tutor["17:00"] == 1)
                                {
                                  addTime("17:00");
                                }
                                if (tutor["17:30"] == 1)
                                {
                                  addTime("17:30");
                                }
                                if (tutor["18:00"] == 1)
                                {
                                  addTime("18:00");
                                }
                                if (tutor["18:30"] == 1)
                                {
                                  addTime("18:30");
                                }
                                if (tutor["19:00"] == 1)
                                {
                                  addTime("19:00");
                                }
                                if (tutor["19:30"] == 1)
                                    {
                                      addTime("19:30");
                                    }
                                if (tutor["20:00"] == 1)
                                {
                                  addTime("20:00");
                                }
                              }
                            });
                        });
                        }
                        else if(d.getDay() == 6){
                            $.get("http://localhost:4000/api/saturday", function(data, status){
                                data.forEach(tutor => {
                                  if(tutor.tutorname == selectedTutor){
                                    if (tutor["8:00"] == 1)
                                    {
                                      addTime("8:00");
                                    }
                                    if (tutor["8:30"] == 1)
                                    {
                                      addTime("8:30");
                                    }
                                    if (tutor["9:00"] == 1)
                                    {
                                      addTime("9:00");
                                    }
                                    if (tutor["9:30"] == 1)
                                    {
                                      addTime("9:30");
                                    }
                                    if (tutor["10:00"] == 1)
                                    {
                                      addTime("10:00");
                                    }
                                    if (tutor["10:30"] == 1)
                                    {
                                      addTime("10:30");
                                    }
                                    if (tutor["11:00"] == 1)
                                    {
                                      addTime("11:00");
                                    }
                                    if (tutor["11:30"] == 1)
                                    {
                                      addTime("11:30");
                                    }
                                    if (tutor["12:00"] == 1)
                                    {
                                      addTime("12:00");
                                    }
                                    if (tutor["12:30"] == 1)
                                    {
                                      addTime("12:30");
                                    }
                                    if (tutor["13:00"] == 1)
                                    {
                                      addTime("13:00");
                                    }
                                    if (tutor["13:30"] == 1)
                                    {
                                      addTime("13:30");
                                    }
                                    if (tutor["14:00"] == 1)
                                    {
                                      addTime("14:00");
                                    }
                                    if (tutor["14:30"] == 1)
                                    {
                                      addTime("14:30");
                                    }
                                    if (tutor["15:00"] == 1)
                                    {
                                      addTime("15:00");
                                    }
                                    if (tutor["15:30"] == 1)
                                    {
                                      addTime("15:30");
                                    }
                                    if (tutor["16:00"] == 1)
                                    {
                                      addTime("16:30");
                                    }
                                    if (tutor["17:00"] == 1)
                                    {
                                      addTime("17:00");
                                    }
                                    if (tutor["17:30"] == 1)
                                    {
                                      addTime("17:30");
                                    }
                                    if (tutor["18:00"] == 1)
                                    {
                                      addTime("18:00");
                                    }
                                    if (tutor["18:30"] == 1)
                                    {
                                      addTime("18:30");
                                    }
                                    if (tutor["19:00"] == 1)
                                    {
                                      addTime("19:00");
                                    }
                                    if (tutor["19:30"] == 1)
                                    {
                                      addTime("19:30");
                                    }
                                    if (tutor["20:00"] == 1)
                                    {
                                      addTime("20:00");
                                    }
                                  }
                                });
                            });
                            }
}
function addDate(addedDays)
{
    var x = document.getElementById("listofdates");
    var option = document.createElement("option");
    var today = new Date();
    var dd = today.getDate() + addedDays;
    var mm = today.getMonth() + 1; //January is 0!
    var yyyy = today.getFullYear();


    if (dd < 10) {
    dd = '0' + dd;
    }

    if (mm < 10) {
    mm = '0' + mm;
    }

    today = mm + '/' + dd + '/' + yyyy;
    option.text = today;
    x.add(option);
}


function addTime(time){

    var x = document.getElementById("listoftimes");
    var option = document.createElement("option");
    option.text = time;
    x.add(option);
}


function addCourse(course){

    var x = document.getElementById("listofcourses");
    var option = document.createElement("option");
    option.text = course;
    x.add(option);
}

function addTutor(tutor)
{
    var x = document.getElementById("listoftutors");
    var option = document.createElement("option");
    option.text = tutor;
    x.add(option);
}

function displayschedule()
{
    var x = document.getElementById("listoftutors");
    var option = document.createElement("option");
    option.text = tutor;
    x.add(option);
}

function makeAppointment()
{
var courses = document.getElementById("listofcourses");
var selectedCourse = $("option:selected", courses).text();
console.log(selectedCourse);
var dates = document.getElementById("listofdates");
var selectedDate = $("option:selected", dates).text();
var times = document.getElementById("listoftimes");
var selectedTime = $("option:selected", times).text();
var name = document.getElementById("nameinput").value;
var email = document.getElementById("emailinput").value;
var tutors = document.getElementById("listoftutors");
var selectedTutor = $("option:selected", tutors).text();
console.log(selectedTutor);
var usrname = "";
var id = 3;
var tempid = 0;
var tutoremail = "";
//var idtest = 0;
$.get("http://localhost:4000/api/appointmentid", function(data,status){
    data.forEach(appt => {

        //console.log(appt.apptId);
       tempid = appt.apptId;
      // createid(appt.apptId);
       //console.log(tempid);
        });
        id = tempid+1;
        //console.log(idtest);
       //idtest = tempid;
       $.get("http://localhost:4000/api/tutorslogin", function(data, status){
         data.forEach(tutor => {
        console.log(tutor.username);
        if(tutor.name == selectedTutor)
        {
            usrname = tutor.username;
            tutoremail = tutor.email;
        }
        console.log(usrname);
    });
    $.post("http://localhost:4000/api/appointment", {studentName: name, date: selectedDate, time: selectedTime, class: selectedCourse, username:usrname,appointmentId:id, studentEmail:email}, function(data, status){
      console.log("1 record changed");
    });
    $.post("http://localhost:4000/api/sendemail", {email:tutoremail}, function(data, status){
      
    });
    window.alert("SUCCESS!!! \nAppointment created! The tutor will be emailing you soon \nPlease close the window!");


});
});


}



