reload();
setTimeout(deletetmpusr, 3000);

function reload() {


    $.get("http://localhost:4000/api/gettemptutor", function(data, status){
        data.forEach(tutor => {
            document.getElementById('username').innerHTML = tutor.username;
        });
    });


    $.get("http://localhost:4000/api/courses", function(data, status){
        data.forEach(course => {
            addCourse(course.course);
            console.log(course);
        });
    });
    $.get("http://localhost:4000/api/appointmentid", function(data, status){
        var app = "";
        var usrname = document.getElementById("username").textContent;
        data.forEach(ap => {
            if (ap.username==usrname){
            app = ap.studentName + "\xa0\xa0\xa0\xa0\xa0" + ap.date + "\xa0\xa0\xa0\xa0\xa0" + ap.time + "\xa0\xa0\xa0\xa0\xa0" + ap.class + "\xa0\xa0\xa0\xa0\xa0" + ap.email + "\xa0\xa0\xa0\xa0\xa0" + "completed= " + ap.completed + "\xa0\xa0\xa0\xa0\xa0"+ "canceled= "+ap.canceled+ "\xa0\xa0\xa0\xa0\xa0"+ "noshow= "+ap.noshow+ "\xa0\xa0\xa0\xa0\xa0"+"apptId= " + ap.apptId; 
            addAppointment(app);
        }
        });
    });
    $.get("http://localhost:4000/api/appointmentid", function(data, status){
        var usrname = document.getElementById("username").textContent;
        data.forEach(ap => {
        if (ap.username==usrname){
         addIds(ap.apptId)
        }
        });
    });
     
  
    
}

function deletetmpusr(){
    $.post("http://localhost:4000/api/deletetemptutor", function(data, status){
        console.log("1 record changed");
      });
    
}
    


function changeName(){
    var usrname = document.getElementById("username").textContent;
    var newname = document.getElementById("nameinput").value;
    console.log(usrname);
    console.log(newname);
    $.post("http://localhost:4000/api/tutorname", {username : usrname, name : newname}, function(data, status){
        console.log("1 record changed");
     });


}

function changeEmail(){
    var usrname = document.getElementById("username").textContent;
    var newemail = document.getElementById("emailinput").value;
    console.log(usrname);
    console.log(newemail);
    $.post("http://localhost:4000/api/tutoremail", {username : usrname, email : newemail}, function(data, status){
        console.log("1 record changed");
     });
}

function changeDescription(){
    var usrname = document.getElementById("username").textContent;
    var newd = document.getElementById("dinput").value;
    console.log(usrname);
    console.log(newd);
    $.post("http://localhost:4000/api/tutordescription", {username : usrname, description : newd}, function(data, status){
        console.log("1 record changed");
     });
}

function setCoursesoff(){
    var usrname = document.getElementById("username").textContent;
    var courses = document.getElementById("listofcourses");
    var c = $("option:selected", courses).text();

    //var c = document.getElementById("math141").textContent;
    console.log(usrname);
    console.log(c);
    if(c=="Alg105")
    {
    $.post("http://localhost:4000/api/alg105off", {username: usrname}, function(data, status){
        console.log("1 record changed");
     });
    }
    if(c=="Alg108")
    {
    $.post("http://localhost:4000/api/alg108off", {username: usrname}, function(data, status){
        console.log("1 record changed");
     });
    }
    if(c=="Alg118")
    {
    $.post("http://localhost:4000/api/alg118off", {username: usrname}, function(data, status){
        console.log("1 record changed");
     });
    }
    if(c=="Alg120")
    {
    $.post("http://localhost:4000/api/alg120off", {username: usrname}, function(data, status){
        console.log("1 record changed");
     });
    }
    if(c=="Math103")
    {
    $.post("http://localhost:4000/api/math103off", {username: usrname}, function(data, status){
        console.log("1 record changed");
     });
    }
    if(c=="Math105")
    {
    $.post("http://localhost:4000/api/math105off", {username: usrname}, function(data, status){
        console.log("1 record changed");
     });
    }
    if(c=="Math106")
    {
    $.post("http://localhost:4000/api/math106off", {username: usrname}, function(data, status){
        console.log("1 record changed");
     });
    }
    if(c=="Math107")
    {
    $.post("http://localhost:4000/api/math107off", {username: usrname}, function(data, status){
        console.log("1 record changed");
     });
    }
    if(c=="Math110")
    {
    $.post("http://localhost:4000/api/math110off", {username: usrname}, function(data, status){
        console.log("1 record changed");
     });
    }
    if(c=="Math117")
    {
    $.post("http://localhost:4000/api/math117off", {username: usrname}, function(data, status){
        console.log("1 record changed");
     });
    }
    if(c=="Math121")
    {
    $.post("http://localhost:4000/api/math121off", {username: usrname}, function(data, status){
        console.log("1 record changed");
     });
    }
    if(c=="Math129")
    {
    $.post("http://localhost:4000/api/math129off", {username: usrname}, function(data, status){
        console.log("1 record changed");
     });
    }
    if(c=="Math131")
    {
    $.post("http://localhost:4000/api/math131off", {username: usrname}, function(data, status){
        console.log("1 record changed");
     });
    }
    if(c=="Math132")
    {
    $.post("http://localhost:4000/api/math132off", {username: usrname}, function(data, status){
        console.log("1 record changed");
     });
    }

    if(c=="Math141")
    {
    $.post("http://localhost:4000/api/math141off", {username: usrname}, function(data, status){
        console.log("1 record changed");
     });
    }
    if(c=="Math151")
    {
    $.post("http://localhost:4000/api/math151off", {username: usrname}, function(data, status){
        console.log("1 record changed");
     });
    }
    if(c=="Math152")
    {
    $.post("http://localhost:4000/api/math152off", {username: usrname}, function(data, status){
        console.log("1 record changed");
     });
    }
    if(c=="Math162")
    {
    $.post("http://localhost:4000/api/math162off", {username: usrname}, function(data, status){
        console.log("1 record changed");
     });
    }
    if(c=="Math201")
    {
    $.post("http://localhost:4000/api/math201off", {username: usrname}, function(data, status){
        console.log("1 record changed");
     });
    }if(c=="Math231")
    {
    $.post("http://localhost:4000/api/math231off", {username: usrname}, function(data, status){
        console.log("1 record changed");
     });
    }
    if(c=="Math232")
    {
    $.post("http://localhost:4000/api/math232off", {username: usrname}, function(data, status){
        console.log("1 record changed");
     });
    }
    if(c=="Math301")
    {
    $.post("http://localhost:4000/api/math301off", {username: usrname}, function(data, status){
        console.log("1 record changed");
     });
    }
    if(c=="Math308")
    {
    $.post("http://localhost:4000/api/math308off", {username: usrname}, function(data, status){
        console.log("1 record changed");
     });
    }
    if(c=="Math309")
    {
    $.post("http://localhost:4000/api/math309off", {username: usrname}, function(data, status){
        console.log("1 record changed");
     });
    }
    if(c=="Math329")
    {
    $.post("http://localhost:4000/api/math329off", {username: usrname}, function(data, status){
        console.log("1 record changed");
     });
    }
    if(c=="Math401")
    {
    $.post("http://localhost:4000/api/math401off", {username: usrname}, function(data, status){
        console.log("1 record changed");
     });
    }
    if(c=="Math402")
    {
    $.post("http://localhost:4000/api/math402off", {username: usrname}, function(data, status){
        console.log("1 record changed");
     });
    }
    if(c=="Math405")
    {
    $.post("http://localhost:4000/api/math405off", {username: usrname}, function(data, status){
        console.log("1 record changed");
     });
    }
    if(c=="Math413")
    {
    $.post("http://localhost:4000/api/math413off", {username: usrname}, function(data, status){
        console.log("1 record changed");
     });
    }
    if(c=="Math414")
    {
    $.post("http://localhost:4000/api/math414off", {username: usrname}, function(data, status){
        console.log("1 record changed");
     });
    }
}

function setCourseson(){
    var usrname = document.getElementById("username").textContent;
    var courses = document.getElementById("listofcourses");
    var c = $("option:selected", courses).text();

    //var c = document.getElementById("math141").textContent;
    console.log(usrname);
    console.log(c);
    if(c=="Alg105")
    {
    $.post("http://localhost:4000/api/alg105on", {username: usrname}, function(data, status){
        console.log("1 record changed");
     });
    }
    if(c=="Alg108")
    {
    $.post("http://localhost:4000/api/alg108on", {username: usrname}, function(data, status){
        console.log("1 record changed");
     });
    }
    if(c=="Alg118")
    {
    $.post("http://localhost:4000/api/alg118on", {username: usrname}, function(data, status){
        console.log("1 record changed");
     });
    }
    if(c=="Alg120")
    {
    $.post("http://localhost:4000/api/alg120on", {username: usrname}, function(data, status){
        console.log("1 record changed");
     });
    }
    if(c=="Math103")
    {
    $.post("http://localhost:4000/api/math103on", {username: usrname}, function(data, status){
        console.log("1 record changed");
     });
    }
    if(c=="Math105")
    {
    $.post("http://localhost:4000/api/math105on", {username: usrname}, function(data, status){
        console.log("1 record changed");
     });
    }
    if(c=="Math106")
    {
    $.post("http://localhost:4000/api/math106on", {username: usrname}, function(data, status){
        console.log("1 record changed");
     });
    }
    if(c=="Math107")
    {
    $.post("http://localhost:4000/api/math107on", {username: usrname}, function(data, status){
        console.log("1 record changed");
     });
    }
    if(c=="Math110")
    {
    $.post("http://localhost:4000/api/math110on", {username: usrname}, function(data, status){
        console.log("1 record changed");
     });
    }
    if(c=="Math117")
    {
    $.post("http://localhost:4000/api/math117on", {username: usrname}, function(data, status){
        console.log("1 record changed");
     });
    }
    if(c=="Math121")
    {
    $.post("http://localhost:4000/api/math121on", {username: usrname}, function(data, status){
        console.log("1 record changed");
     });
    }
    if(c=="Math129")
    {
    $.post("http://localhost:4000/api/math129on", {username: usrname}, function(data, status){
        console.log("1 record changed");
     });
    }
    if(c=="Math131")
    {
    $.post("http://localhost:4000/api/math131on", {username: usrname}, function(data, status){
        console.log("1 record changed");
     });
    }
    if(c=="Math132")
    {
    $.post("http://localhost:4000/api/math132on", {username: usrname}, function(data, status){
        console.log("1 record changed");
     });
    }

    if(c=="Math141")
    {
    $.post("http://localhost:4000/api/math141on", {username: usrname}, function(data, status){
        console.log("1 record changed");
     });
    }
    if(c=="Math151")
    {
    $.post("http://localhost:4000/api/math151on", {username: usrname}, function(data, status){
        console.log("1 record changed");
     });
    }
    if(c=="Math152")
    {
    $.post("http://localhost:4000/api/math152on", {username: usrname}, function(data, status){
        console.log("1 record changed");
     });
    }
    if(c=="Math162")
    {
    $.post("http://localhost:4000/api/math162on", {username: usrname}, function(data, status){
        console.log("1 record changed");
     });
    }
    if(c=="Math201")
    {
    $.post("http://localhost:4000/api/math201on", {username: usrname}, function(data, status){
        console.log("1 record changed");
     });
    }if(c=="Math231")
    {
    $.post("http://localhost:4000/api/math231on", {username: usrname}, function(data, status){
        console.log("1 record changed");
     });
    }
    if(c=="Math232")
    {
    $.post("http://localhost:4000/api/math232on", {username: usrname}, function(data, status){
        console.log("1 record changed");
     });
    }
    if(c=="Math301")
    {
    $.post("http://localhost:4000/api/math301on", {username: usrname}, function(data, status){
        console.log("1 record changed");
     });
    }
    if(c=="Math308")
    {
    $.post("http://localhost:4000/api/math308on", {username: usrname}, function(data, status){
        console.log("1 record changed");
     });
    }
    if(c=="Math309")
    {
    $.post("http://localhost:4000/api/math309on", {username: usrname}, function(data, status){
        console.log("1 record changed");
     });
    }
    if(c=="Math329")
    {
    $.post("http://localhost:4000/api/math329on", {username: usrname}, function(data, status){
        console.log("1 record changed");
     });
    }
    if(c=="Math401")
    {
    $.post("http://localhost:4000/api/math401on", {username: usrname}, function(data, status){
        console.log("1 record changed");
     });
    }
    if(c=="Math402")
    {
    $.post("http://localhost:4000/api/math402on", {username: usrname}, function(data, status){
        console.log("1 record changed");
     });
    }
    if(c=="Math405")
    {
    $.post("http://localhost:4000/api/math405on", {username: usrname}, function(data, status){
        console.log("1 record changed");
     });
    }
    if(c=="Math413")
    {
    $.post("http://localhost:4000/api/math413on", {username: usrname}, function(data, status){
        console.log("1 record changed");
     });
    }
    if(c=="Math414")
    {
    $.post("http://localhost:4000/api/math414on", {username: usrname}, function(data, status){
        console.log("1 record changed");
     });
    }
}

function setTimeson(){
    var usrname = document.getElementById("username").textContent;
    var days = document.getElementById("listofdates");
    var day = $("option:selected", days).text();
    var times = document.getElementById("listoftimes");
    var time = $("option:selected", times).text();
    console.log(usrname);
    //console.log(c);
    if (day=="Monday"){
    
        if(time == "8:00"){
            $.post("http://localhost:4000/api/mon800on", {username : usrname}, function(data, status){
        });
        }   
        if(time == "8:30"){
            $.post("http://localhost:4000/api/mon830on", {username : usrname}, function(data, status){
        });
        } 
        if(time == "9:00"){
            $.post("http://localhost:4000/api/mon900on", {username : usrname}, function(data, status){
        });
        } 
        if(time == "9:30"){
            $.post("http://localhost:4000/api/mon930on", {username : usrname}, function(data, status){
        });
        } 
        if(time == "10:00"){
            $.post("http://localhost:4000/api/mon1000on", {username : usrname}, function(data, status){
        });
        } 
        if(time == "10:30"){
            $.post("http://localhost:4000/api/mon1030on", {username : usrname}, function(data, status){
        });
        } 
        if(time == "11:00"){
            $.post("http://localhost:4000/api/mon1100on", {username : usrname}, function(data, status){
        });
        } 
        if(time == "11:30"){
            $.post("http://localhost:4000/api/mon1130on", {username : usrname}, function(data, status){
        });
        } 
        if(time == "12:00"){
            $.post("http://localhost:4000/api/mon1200on", {username : usrname}, function(data, status){
        });
        } 
        if(time == "12:30"){
            $.post("http://localhost:4000/api/mon1230on", {username : usrname}, function(data, status){
        });
        } 
        if(time == "13:00"){
            $.post("http://localhost:4000/api/mon1300on", {username : usrname}, function(data, status){
        });
        } 
        if(time == "13:30"){
            $.post("http://localhost:4000/api/mon1330on", {username : usrname}, function(data, status){
        });
        } 
        if(time == "14:00"){
            $.post("http://localhost:4000/api/mon1400on", {username : usrname}, function(data, status){
        });
        } 
        if(time == "14:30"){
            $.post("http://localhost:4000/api/mon1430on", {username : usrname}, function(data, status){
        });
        } 
        if(time == "15:00"){
            $.post("http://localhost:4000/api/mon1500on", {username : usrname}, function(data, status){
        });
        } 
        if(time == "15:30"){
            $.post("http://localhost:4000/api/mon1530on", {username : usrname}, function(data, status){
        });
        } 
        if(time == "16:00"){
            $.post("http://localhost:4000/api/mon1600on", {username : usrname}, function(data, status){
        });
        } 
        if(time == "16:30"){
            $.post("http://localhost:4000/api/mon1630on", {username : usrname}, function(data, status){
        });
        } 
        if(time == "17:00"){
            $.post("http://localhost:4000/api/mon1700on", {username : usrname}, function(data, status){
        });
        } 
        if(time == "17:30"){
            $.post("http://localhost:4000/api/mon1730on", {username : usrname}, function(data, status){
        });
        } 
        if(time == "18:00"){
            $.post("http://localhost:4000/api/mon1800on", {username : usrname}, function(data, status){
        });
        } 
        if(time == "18:30"){
            $.post("http://localhost:4000/api/mon1830on", {username : usrname}, function(data, status){
        });
        } 
        if(time == "19:00"){
            $.post("http://localhost:4000/api/mon1900on", {username : usrname}, function(data, status){
        });
        } 
        if(time == "19:30"){
            $.post("http://localhost:4000/api/mon1930on", {username : usrname}, function(data, status){
        });
        } 
        if(time == "20:00"){
            $.post("http://localhost:4000/api/mon2000on", {username : usrname}, function(data, status){
        });
        } 

}
if (day=="Tuesday"){
    
    if(time == "8:00"){
        $.post("http://localhost:4000/api/tue800on", {username : usrname}, function(data, status){
    });
    }   
    if(time == "8:30"){
        $.post("http://localhost:4000/api/tue830on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "9:00"){
        $.post("http://localhost:4000/api/tue900on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "9:30"){
        $.post("http://localhost:4000/api/tue930on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "10:00"){
        $.post("http://localhost:4000/api/tue1000on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "10:30"){
        $.post("http://localhost:4000/api/tue1030on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "11:00"){
        $.post("http://localhost:4000/api/tue1100on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "11:30"){
        $.post("http://localhost:4000/api/tue1130on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "12:00"){
        $.post("http://localhost:4000/api/tue1200on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "12:30"){
        $.post("http://localhost:4000/api/tue1230on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "13:00"){
        $.post("http://localhost:4000/api/tue1300on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "13:30"){
        $.post("http://localhost:4000/api/tue1330on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "14:00"){
        $.post("http://localhost:4000/api/tue1400on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "14:30"){
        $.post("http://localhost:4000/api/tue1430on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "15:00"){
        $.post("http://localhost:4000/api/tue1500on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "15:30"){
        $.post("http://localhost:4000/api/tue1530on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "16:00"){
        $.post("http://localhost:4000/api/tue1600on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "16:30"){
        $.post("http://localhost:4000/api/tue1630on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "17:00"){
        $.post("http://localhost:4000/api/tue1700on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "17:30"){
        $.post("http://localhost:4000/api/tue1730on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "18:00"){
        $.post("http://localhost:4000/api/tue1800on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "18:30"){
        $.post("http://localhost:4000/api/tue1830on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "19:00"){
        $.post("http://localhost:4000/api/tue1900on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "19:30"){
        $.post("http://localhost:4000/api/tue1930on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "20:00"){
        $.post("http://localhost:4000/api/tue2000on", {username : usrname}, function(data, status){
    });
    } 

}
if (day=="Wednesday"){
    
    if(time == "8:00"){
        $.post("http://localhost:4000/api/wed800on", {username : usrname}, function(data, status){
    });
    }   
    if(time == "8:30"){
        $.post("http://localhost:4000/api/wed830on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "9:00"){
        $.post("http://localhost:4000/api/wed900on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "9:30"){
        $.post("http://localhost:4000/api/wed930on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "10:00"){
        $.post("http://localhost:4000/api/wed1000on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "10:30"){
        $.post("http://localhost:4000/api/wed1030on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "11:00"){
        $.post("http://localhost:4000/api/wed1100on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "11:30"){
        $.post("http://localhost:4000/api/wed1130on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "12:00"){
        $.post("http://localhost:4000/api/wed1200on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "12:30"){
        $.post("http://localhost:4000/api/wed1230on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "13:00"){
        $.post("http://localhost:4000/api/wed1300on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "13:30"){
        $.post("http://localhost:4000/api/wed1330on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "14:00"){
        $.post("http://localhost:4000/api/wed1400on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "14:30"){
        $.post("http://localhost:4000/api/wed1430on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "15:00"){
        $.post("http://localhost:4000/api/wed1500on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "15:30"){
        $.post("http://localhost:4000/api/wed1530on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "16:00"){
        $.post("http://localhost:4000/api/wed1600on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "16:30"){
        $.post("http://localhost:4000/api/wed1630on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "17:00"){
        $.post("http://localhost:4000/api/wed1700on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "17:30"){
        $.post("http://localhost:4000/api/wed1730on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "18:00"){
        $.post("http://localhost:4000/api/wed1800on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "18:30"){
        $.post("http://localhost:4000/api/wed1830on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "19:00"){
        $.post("http://localhost:4000/api/wed1900on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "19:30"){
        $.post("http://localhost:4000/api/wed1930on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "20:00"){
        $.post("http://localhost:4000/api/wed2000on", {username : usrname}, function(data, status){
    });
    } 

}

if (day=="Thursday"){
    
    if(time == "8:00"){
        $.post("http://localhost:4000/api/thu800on", {username : usrname}, function(data, status){
    });
    }   
    if(time == "8:30"){
        $.post("http://localhost:4000/api/thu830on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "9:00"){
        $.post("http://localhost:4000/api/thu900on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "9:30"){
        $.post("http://localhost:4000/api/thu930on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "10:00"){
        $.post("http://localhost:4000/api/thu1000on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "10:30"){
        $.post("http://localhost:4000/api/thu1030on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "11:00"){
        $.post("http://localhost:4000/api/thu1100on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "11:30"){
        $.post("http://localhost:4000/api/thu1130on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "12:00"){
        $.post("http://localhost:4000/api/thu1200on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "12:30"){
        $.post("http://localhost:4000/api/thu1230on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "13:00"){
        $.post("http://localhost:4000/api/thu1300on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "13:30"){
        $.post("http://localhost:4000/api/thu1330on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "14:00"){
        $.post("http://localhost:4000/api/thu1400on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "14:30"){
        $.post("http://localhost:4000/api/thu1430on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "15:00"){
        $.post("http://localhost:4000/api/thu1500on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "15:30"){
        $.post("http://localhost:4000/api/thu1530on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "16:00"){
        $.post("http://localhost:4000/api/thu1600on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "16:30"){
        $.post("http://localhost:4000/api/thu1630on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "17:00"){
        $.post("http://localhost:4000/api/thu1700on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "17:30"){
        $.post("http://localhost:4000/api/thu1730on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "18:00"){
        $.post("http://localhost:4000/api/thu1800on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "18:30"){
        $.post("http://localhost:4000/api/thu1830on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "19:00"){
        $.post("http://localhost:4000/api/thu1900on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "19:30"){
        $.post("http://localhost:4000/api/thu1930on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "20:00"){
        $.post("http://localhost:4000/api/thu2000on", {username : usrname}, function(data, status){
    });
    } 

}

if (day=="Friday"){
    
    if(time == "8:00"){
        $.post("http://localhost:4000/api/fri800on", {username : usrname}, function(data, status){
    });
    }   
    if(time == "8:30"){
        $.post("http://localhost:4000/api/fri830on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "9:00"){
        $.post("http://localhost:4000/api/fri900on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "9:30"){
        $.post("http://localhost:4000/api/fri930on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "10:00"){
        $.post("http://localhost:4000/api/fri1000on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "10:30"){
        $.post("http://localhost:4000/api/fri1030on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "11:00"){
        $.post("http://localhost:4000/api/fri1100on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "11:30"){
        $.post("http://localhost:4000/api/fri1130on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "12:00"){
        $.post("http://localhost:4000/api/fri1200on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "12:30"){
        $.post("http://localhost:4000/api/fri1230on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "13:00"){
        $.post("http://localhost:4000/api/fri1300on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "13:30"){
        $.post("http://localhost:4000/api/fri1330on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "14:00"){
        $.post("http://localhost:4000/api/fri1400on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "14:30"){
        $.post("http://localhost:4000/api/fri1430on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "15:00"){
        $.post("http://localhost:4000/api/fri1500on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "15:30"){
        $.post("http://localhost:4000/api/fri1530on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "16:00"){
        $.post("http://localhost:4000/api/fri1600on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "16:30"){
        $.post("http://localhost:4000/api/fri1630on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "17:00"){
        $.post("http://localhost:4000/api/fri1700on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "17:30"){
        $.post("http://localhost:4000/api/fri1730on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "18:00"){
        $.post("http://localhost:4000/api/fri1800on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "18:30"){
        $.post("http://localhost:4000/api/fri1830on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "19:00"){
        $.post("http://localhost:4000/api/fri1900on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "19:30"){
        $.post("http://localhost:4000/api/fri1930on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "20:00"){
        $.post("http://localhost:4000/api/fri2000on", {username : usrname}, function(data, status){
    });
    } 

}

if (day=="Saturday"){
    
    if(time == "8:00"){
        $.post("http://localhost:4000/api/sat800on", {username : usrname}, function(data, status){
    });
    }   
    if(time == "8:30"){
        $.post("http://localhost:4000/api/sat830on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "9:00"){
        $.post("http://localhost:4000/api/sat900on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "9:30"){
        $.post("http://localhost:4000/api/sat930on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "10:00"){
        $.post("http://localhost:4000/api/sat1000on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "10:30"){
        $.post("http://localhost:4000/api/sat1030on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "11:00"){
        $.post("http://localhost:4000/api/sat1100on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "11:30"){
        $.post("http://localhost:4000/api/sat1130on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "12:00"){
        $.post("http://localhost:4000/api/sat1200on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "12:30"){
        $.post("http://localhost:4000/api/sat1230on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "13:00"){
        $.post("http://localhost:4000/api/sat1300on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "13:30"){
        $.post("http://localhost:4000/api/sat1330on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "14:00"){
        $.post("http://localhost:4000/api/sat1400on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "14:30"){
        $.post("http://localhost:4000/api/sat1430on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "15:00"){
        $.post("http://localhost:4000/api/sat1500on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "15:30"){
        $.post("http://localhost:4000/api/sat1530on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "16:00"){
        $.post("http://localhost:4000/api/sat1600on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "16:30"){
        $.post("http://localhost:4000/api/sat1630on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "17:00"){
        $.post("http://localhost:4000/api/sat1700on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "17:30"){
        $.post("http://localhost:4000/api/sat1730on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "18:00"){
        $.post("http://localhost:4000/api/sat1800on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "18:30"){
        $.post("http://localhost:4000/api/sat1830on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "19:00"){
        $.post("http://localhost:4000/api/sat1900on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "19:30"){
        $.post("http://localhost:4000/api/sat1930on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "20:00"){
        $.post("http://localhost:4000/api/sat2000on", {username : usrname}, function(data, status){
    });
    } 

}
if (day=="Sunday"){
    
    if(time == "8:00"){
        $.post("http://localhost:4000/api/sun800on", {username : usrname}, function(data, status){
    });
    }   
    if(time == "8:30"){
        $.post("http://localhost:4000/api/sun830on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "9:00"){
        $.post("http://localhost:4000/api/sun900on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "9:30"){
        $.post("http://localhost:4000/api/sun930on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "10:00"){
        $.post("http://localhost:4000/api/sun1000on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "10:30"){
        $.post("http://localhost:4000/api/sun1030on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "11:00"){
        $.post("http://localhost:4000/api/sun1100on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "11:30"){
        $.post("http://localhost:4000/api/sun1130on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "12:00"){
        $.post("http://localhost:4000/api/sun1200on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "12:30"){
        $.post("http://localhost:4000/api/sun1230on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "13:00"){
        $.post("http://localhost:4000/api/sun1300on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "13:30"){
        $.post("http://localhost:4000/api/sun1330on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "14:00"){
        $.post("http://localhost:4000/api/sun1400on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "14:30"){
        $.post("http://localhost:4000/api/sun1430on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "15:00"){
        $.post("http://localhost:4000/api/sun1500on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "15:30"){
        $.post("http://localhost:4000/api/sun1530on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "16:00"){
        $.post("http://localhost:4000/api/sun1600on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "16:30"){
        $.post("http://localhost:4000/api/sun1630on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "17:00"){
        $.post("http://localhost:4000/api/sun1700on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "17:30"){
        $.post("http://localhost:4000/api/sun1730on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "18:00"){
        $.post("http://localhost:4000/api/sun1800on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "18:30"){
        $.post("http://localhost:4000/api/sun1830on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "19:00"){
        $.post("http://localhost:4000/api/sun1900on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "19:30"){
        $.post("http://localhost:4000/api/sun1930on", {username : usrname}, function(data, status){
    });
    } 
    if(time == "20:00"){
        $.post("http://localhost:4000/api/sun2000on", {username : usrname}, function(data, status){
    });
    } 

}



}

function setTimesoff(){
    var usrname = document.getElementById("username").textContent;
    var days = document.getElementById("listofdates");
    var day = $("option:selected", days).text();
    var times = document.getElementById("listoftimes");
    var time = $("option:selected", times).text();
    console.log(usrname);
    console.log(day);
    console.log(time);

    if (day=="Monday"){
    
        if(time == "8:00"){
            $.post("http://localhost:4000/api/mon800off", {username : usrname}, function(data, status){
        });
        }   
        if(time == "8:30"){
            $.post("http://localhost:4000/api/mon830off", {username : usrname}, function(data, status){
        });
        } 
        if(time == "9:00"){
            $.post("http://localhost:4000/api/mon900off", {username : usrname}, function(data, status){
        });
        } 
        if(time == "9:30"){
            $.post("http://localhost:4000/api/mon930off", {username : usrname}, function(data, status){
        });
        } 
        if(time == "10:00"){
            $.post("http://localhost:4000/api/mon1000off", {username : usrname}, function(data, status){
        });
        } 
        if(time == "10:30"){
            $.post("http://localhost:4000/api/mon1030off", {username : usrname}, function(data, status){
        });
        } 
        if(time == "11:00"){
            $.post("http://localhost:4000/api/mon1100off", {username : usrname}, function(data, status){
        });
        } 
        if(time == "11:30"){
            $.post("http://localhost:4000/api/mon1130off", {username : usrname}, function(data, status){
        });
        } 
        if(time == "12:00"){
            $.post("http://localhost:4000/api/mon1200off", {username : usrname}, function(data, status){
        });
        } 
        if(time == "12:30"){
            $.post("http://localhost:4000/api/mon1230off", {username : usrname}, function(data, status){
        });
        } 
        if(time == "13:00"){
            $.post("http://localhost:4000/api/mon1300off", {username : usrname}, function(data, status){
        });
        } 
        if(time == "13:30"){
            $.post("http://localhost:4000/api/mon1330off", {username : usrname}, function(data, status){
        });
        } 
        if(time == "14:00"){
            $.post("http://localhost:4000/api/mon1400off", {username : usrname}, function(data, status){
        });
        } 
        if(time == "14:30"){
            $.post("http://localhost:4000/api/mon1430off", {username : usrname}, function(data, status){
        });
        } 
        if(time == "15:00"){
            $.post("http://localhost:4000/api/mon1500off", {username : usrname}, function(data, status){
        });
        } 
        if(time == "15:30"){
            $.post("http://localhost:4000/api/mon1530off", {username : usrname}, function(data, status){
        });
        } 
        if(time == "16:00"){
            $.post("http://localhost:4000/api/mon1600off", {username : usrname}, function(data, status){
        });
        } 
        if(time == "16:30"){
            $.post("http://localhost:4000/api/mon1630off", {username : usrname}, function(data, status){
        });
        } 
        if(time == "17:00"){
            $.post("http://localhost:4000/api/mon1700off", {username : usrname}, function(data, status){
        });
        } 
        if(time == "17:30"){
            $.post("http://localhost:4000/api/mon1730off", {username : usrname}, function(data, status){
        });
        } 
        if(time == "18:00"){
            $.post("http://localhost:4000/api/mon1800off", {username : usrname}, function(data, status){
        });
        } 
        if(time == "18:30"){
            $.post("http://localhost:4000/api/mon1830off", {username : usrname}, function(data, status){
        });
        } 
        if(time == "19:00"){
            $.post("http://localhost:4000/api/mon1900off", {username : usrname}, function(data, status){
        });
        } 
        if(time == "19:30"){
            $.post("http://localhost:4000/api/mon1930off", {username : usrname}, function(data, status){
        });
        } 
        if(time == "20:00"){
            $.post("http://localhost:4000/api/mon2000off", {username : usrname}, function(data, status){
        });
        } 


}
if (day=="Tuesday"){
    
    if(time == "8:00"){
        $.post("http://localhost:4000/api/tue800off", {username : usrname}, function(data, status){
    });
    }   
    if(time == "8:30"){
        $.post("http://localhost:4000/api/tue830off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "9:00"){
        $.post("http://localhost:4000/api/tue900off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "9:30"){
        $.post("http://localhost:4000/api/tue930off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "10:00"){
        $.post("http://localhost:4000/api/tue1000off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "10:30"){
        $.post("http://localhost:4000/api/tue1030off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "11:00"){
        $.post("http://localhost:4000/api/tue1100off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "11:30"){
        $.post("http://localhost:4000/api/tue1130off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "12:00"){
        $.post("http://localhost:4000/api/tue1200off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "12:30"){
        $.post("http://localhost:4000/api/tue1230off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "13:00"){
        $.post("http://localhost:4000/api/tue1300off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "13:30"){
        $.post("http://localhost:4000/api/tue1330off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "14:00"){
        $.post("http://localhost:4000/api/tue1400off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "14:30"){
        $.post("http://localhost:4000/api/tue1430off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "15:00"){
        $.post("http://localhost:4000/api/tue1500off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "15:30"){
        $.post("http://localhost:4000/api/tue1530off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "16:00"){
        $.post("http://localhost:4000/api/tue1600off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "16:30"){
        $.post("http://localhost:4000/api/tue1630off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "17:00"){
        $.post("http://localhost:4000/api/tue1700off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "17:30"){
        $.post("http://localhost:4000/api/tue1730off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "18:00"){
        $.post("http://localhost:4000/api/tue1800off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "18:30"){
        $.post("http://localhost:4000/api/tue1830off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "19:00"){
        $.post("http://localhost:4000/api/tue1900off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "19:30"){
        $.post("http://localhost:4000/api/tue1930off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "20:00"){
        $.post("http://localhost:4000/api/tue2000off", {username : usrname}, function(data, status){
    });
    } 

}
if (day=="Wednesday"){
    
    if(time == "8:00"){
        $.post("http://localhost:4000/api/wed800off", {username : usrname}, function(data, status){
    });
    }   
    if(time == "8:30"){
        $.post("http://localhost:4000/api/wed830off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "9:00"){
        $.post("http://localhost:4000/api/wed900off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "9:30"){
        $.post("http://localhost:4000/api/wed930off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "10:00"){
        $.post("http://localhost:4000/api/wed1000off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "10:30"){
        $.post("http://localhost:4000/api/wed1030off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "11:00"){
        $.post("http://localhost:4000/api/wed1100off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "11:30"){
        $.post("http://localhost:4000/api/wed1130off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "12:00"){
        $.post("http://localhost:4000/api/wed1200off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "12:30"){
        $.post("http://localhost:4000/api/wed1230off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "13:00"){
        $.post("http://localhost:4000/api/wed1300off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "13:30"){
        $.post("http://localhost:4000/api/wed1330off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "14:00"){
        $.post("http://localhost:4000/api/wed1400off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "14:30"){
        $.post("http://localhost:4000/api/wed1430off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "15:00"){
        $.post("http://localhost:4000/api/wed1500off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "15:30"){
        $.post("http://localhost:4000/api/wed1530off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "16:00"){
        $.post("http://localhost:4000/api/wed1600off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "16:30"){
        $.post("http://localhost:4000/api/wed1630off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "17:00"){
        $.post("http://localhost:4000/api/wed1700off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "17:30"){
        $.post("http://localhost:4000/api/wed1730off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "18:00"){
        $.post("http://localhost:4000/api/wed1800off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "18:30"){
        $.post("http://localhost:4000/api/wed1830off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "19:00"){
        $.post("http://localhost:4000/api/wed1900off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "19:30"){
        $.post("http://localhost:4000/api/wed1930off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "20:00"){
        $.post("http://localhost:4000/api/wed2000off", {username : usrname}, function(data, status){
    });
    } 

}

if (day=="Thursday"){
    
    if(time == "8:00"){
        $.post("http://localhost:4000/api/thu800off", {username : usrname}, function(data, status){
    });
    }   
    if(time == "8:30"){
        $.post("http://localhost:4000/api/thu830off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "9:00"){
        $.post("http://localhost:4000/api/thu900off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "9:30"){
        $.post("http://localhost:4000/api/thu930off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "10:00"){
        $.post("http://localhost:4000/api/thu1000off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "10:30"){
        $.post("http://localhost:4000/api/thu1030off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "11:00"){
        $.post("http://localhost:4000/api/thu1100off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "11:30"){
        $.post("http://localhost:4000/api/thu1130off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "12:00"){
        $.post("http://localhost:4000/api/thu1200off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "12:30"){
        $.post("http://localhost:4000/api/thu1230off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "13:00"){
        $.post("http://localhost:4000/api/thu1300off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "13:30"){
        $.post("http://localhost:4000/api/thu1330off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "14:00"){
        $.post("http://localhost:4000/api/thu1400off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "14:30"){
        $.post("http://localhost:4000/api/thu1430off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "15:00"){
        $.post("http://localhost:4000/api/thu1500off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "15:30"){
        $.post("http://localhost:4000/api/thu1530off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "16:00"){
        $.post("http://localhost:4000/api/thu1600off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "16:30"){
        $.post("http://localhost:4000/api/thu1630off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "17:00"){
        $.post("http://localhost:4000/api/thu1700off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "17:30"){
        $.post("http://localhost:4000/api/thu1730off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "18:00"){
        $.post("http://localhost:4000/api/thu1800off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "18:30"){
        $.post("http://localhost:4000/api/thu1830off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "19:00"){
        $.post("http://localhost:4000/api/thu1900off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "19:30"){
        $.post("http://localhost:4000/api/thu1930off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "20:00"){
        $.post("http://localhost:4000/api/thu2000off", {username : usrname}, function(data, status){
    });
    } 

}

if (day=="Friday"){
    
    if(time == "8:00"){
        $.post("http://localhost:4000/api/fri800off", {username : usrname}, function(data, status){
    });
    }   
    if(time == "8:30"){
        $.post("http://localhost:4000/api/fri830off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "9:00"){
        $.post("http://localhost:4000/api/fri900off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "9:30"){
        $.post("http://localhost:4000/api/fri930off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "10:00"){
        $.post("http://localhost:4000/api/fri1000off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "10:30"){
        $.post("http://localhost:4000/api/fri1030off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "11:00"){
        $.post("http://localhost:4000/api/fri1100off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "11:30"){
        $.post("http://localhost:4000/api/fri1130off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "12:00"){
        $.post("http://localhost:4000/api/fri1200off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "12:30"){
        $.post("http://localhost:4000/api/fri1230off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "13:00"){
        $.post("http://localhost:4000/api/fri1300off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "13:30"){
        $.post("http://localhost:4000/api/fri1330off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "14:00"){
        $.post("http://localhost:4000/api/fri1400off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "14:30"){
        $.post("http://localhost:4000/api/fri1430off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "15:00"){
        $.post("http://localhost:4000/api/fri1500off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "15:30"){
        $.post("http://localhost:4000/api/fri1530off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "16:00"){
        $.post("http://localhost:4000/api/fri1600off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "16:30"){
        $.post("http://localhost:4000/api/fri1630off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "17:00"){
        $.post("http://localhost:4000/api/fri1700off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "17:30"){
        $.post("http://localhost:4000/api/fri1730off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "18:00"){
        $.post("http://localhost:4000/api/fri1800off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "18:30"){
        $.post("http://localhost:4000/api/fri1830off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "19:00"){
        $.post("http://localhost:4000/api/fri1900off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "19:30"){
        $.post("http://localhost:4000/api/fri1930off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "20:00"){
        $.post("http://localhost:4000/api/fri2000off", {username : usrname}, function(data, status){
    });
    } 

}

if (day=="Saturday"){
    
    if(time == "8:00"){
        $.post("http://localhost:4000/api/sat800off", {username : usrname}, function(data, status){
    });
    }   
    if(time == "8:30"){
        $.post("http://localhost:4000/api/sat830off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "9:00"){
        $.post("http://localhost:4000/api/sat900off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "9:30"){
        $.post("http://localhost:4000/api/sat930off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "10:00"){
        $.post("http://localhost:4000/api/sat1000off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "10:30"){
        $.post("http://localhost:4000/api/sat1030off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "11:00"){
        $.post("http://localhost:4000/api/sat1100off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "11:30"){
        $.post("http://localhost:4000/api/sat1130off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "12:00"){
        $.post("http://localhost:4000/api/sat1200off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "12:30"){
        $.post("http://localhost:4000/api/sat1230off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "13:00"){
        $.post("http://localhost:4000/api/sat1300off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "13:30"){
        $.post("http://localhost:4000/api/sat1330off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "14:00"){
        $.post("http://localhost:4000/api/sat1400off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "14:30"){
        $.post("http://localhost:4000/api/sat1430off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "15:00"){
        $.post("http://localhost:4000/api/sat1500off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "15:30"){
        $.post("http://localhost:4000/api/sat1530off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "16:00"){
        $.post("http://localhost:4000/api/sat1600off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "16:30"){
        $.post("http://localhost:4000/api/sat1630off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "17:00"){
        $.post("http://localhost:4000/api/sat1700off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "17:30"){
        $.post("http://localhost:4000/api/sat1730off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "18:00"){
        $.post("http://localhost:4000/api/sat1800off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "18:30"){
        $.post("http://localhost:4000/api/sat1830off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "19:00"){
        $.post("http://localhost:4000/api/sat1900off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "19:30"){
        $.post("http://localhost:4000/api/sat1930off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "20:00"){
        $.post("http://localhost:4000/api/sat2000off", {username : usrname}, function(data, status){
    });
    } 

}
if (day=="Sunday"){
    
    if(time == "8:00"){
        $.post("http://localhost:4000/api/sun800off", {username : usrname}, function(data, status){
    });
    }   
    if(time == "8:30"){
        $.post("http://localhost:4000/api/sun830off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "9:00"){
        $.post("http://localhost:4000/api/sun900off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "9:30"){
        $.post("http://localhost:4000/api/sun930off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "10:00"){
        $.post("http://localhost:4000/api/sun1000off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "10:30"){
        $.post("http://localhost:4000/api/sun1030off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "11:00"){
        $.post("http://localhost:4000/api/sun1100off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "11:30"){
        $.post("http://localhost:4000/api/sun1130off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "12:00"){
        $.post("http://localhost:4000/api/sun1200off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "12:30"){
        $.post("http://localhost:4000/api/sun1230off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "13:00"){
        $.post("http://localhost:4000/api/sun1300off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "13:30"){
        $.post("http://localhost:4000/api/sun1330off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "14:00"){
        $.post("http://localhost:4000/api/sun1400off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "14:30"){
        $.post("http://localhost:4000/api/sun1430off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "15:00"){
        $.post("http://localhost:4000/api/sun1500off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "15:30"){
        $.post("http://localhost:4000/api/sun1530off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "16:00"){
        $.post("http://localhost:4000/api/sun1600off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "16:30"){
        $.post("http://localhost:4000/api/sun1630off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "17:00"){
        $.post("http://localhost:4000/api/sun1700off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "17:30"){
        $.post("http://localhost:4000/api/sun1730off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "18:00"){
        $.post("http://localhost:4000/api/sun1800off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "18:30"){
        $.post("http://localhost:4000/api/sun1830off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "19:00"){
        $.post("http://localhost:4000/api/sun1900off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "19:30"){
        $.post("http://localhost:4000/api/sun1930off", {username : usrname}, function(data, status){
    });
    } 
    if(time == "20:00"){
        $.post("http://localhost:4000/api/sun2000off", {username : usrname}, function(data, status){
    });
    } 

}

}


function addAppointment(appointment){

    var x = document.getElementById("listofappointments");
    var option = document.createElement("option");
    option.text = appointment;
    x.add(option);
}

function addIds(id){

    var x = document.getElementById("listofids");
    var option = document.createElement("option");
    option.text = id;
    x.add(option);
}


function addCourse(course){

    var x = document.getElementById("listofcourses");
    var option = document.createElement("option");
    option.text = course;
    x.add(option);
}

function setComplete(){
    var ids = document.getElementById("listofids");
    var i = $("option:selected", ids).text();
    $.post("http://localhost:4000/api/completed", {id : i}, function(data, status){
    });
}

function setCancel(){
    var ids = document.getElementById("listofids");
    var i = $("option:selected", ids).text();
    $.post("http://localhost:4000/api/canceled", {id : i}, function(data, status){
    });
}

function setNoshow(){
    var ids = document.getElementById("listofids");
    var i = $("option:selected", ids).text();
    $.post("http://localhost:4000/api/noshow", {id : i}, function(data, status){
    });
}

function dowork(){
    var usrname = document.getElementById("username").textContent;
    var days = document.getElementById("listofdates");
    var day = $("option:selected", days).text();
    console.log(day);
    console.log(usrname);
    if(day=="Monday"){
        $.post("http://localhost:4000/api/workmon", {username:usrname}, function(data, status){
    });
}
    if(day=="Tuesday"){
        $.post("http://localhost:4000/api/worktue", {username:usrname}, function(data, status){
    });
}
    if(day=="Wednesday"){
        $.post("http://localhost:4000/api/workwed", {username:usrname}, function(data, status){
    });
}
    if(day=="Thursday"){
        $.post("http://localhost:4000/api/workthu", {username:usrname}, function(data, status){
    });
}
    if(day=="Friday"){
        $.post("http://localhost:4000/api/workfri", {username:usrname}, function(data, status){
    });
}
    if(day=="Saturday"){
        $.post("http://localhost:4000/api/worksat", {username:usrname}, function(data, status){
    });
}
    if(day=="Sunday"){
        $.post("http://localhost:4000/api/worksun", {username:usrname}, function(data, status){
    });
    }
}

function notwork(){
    var usrname = document.getElementById("username").textContent;
    var days = document.getElementById("listofdates");
    var day = $("option:selected", days).text();
    if(day=="Monday"){
        $.post("http://localhost:4000/api/noworkmon", {username:usrname}, function(data, status){
    });
}
    if(day=="Tuesday"){
        $.post("http://localhost:4000/api/noworktue", {username:usrname}, function(data, status){
    });
}
    if(day=="Wednesday"){
        $.post("http://localhost:4000/api/noworkwed", {username:usrname}, function(data, status){
    });
}
    if(day=="Thursday"){
        $.post("http://localhost:4000/api/noworkthu", {username:usrname}, function(data, status){
    });
}
    if(day=="Friday"){
        $.post("http://localhost:4000/api/noworkfri", {username:usrname}, function(data, status){
    });
}
    if(day=="Saturday"){
        $.post("http://localhost:4000/api/noworksat", {username:usrname}, function(data, status){
    });
}
    if(day=="Sunday"){
        $.post("http://localhost:4000/api/noworksun", {username:usrname}, function(data, status){
    });
    }
}
