reload();
setTimeout(deletetmpusr, 3000);

function reload() {

   $.get("http://localhost:4000/api/gettempadmin", function(data, status){
        data.forEach(admin => {
            document.getElementById('username').innerHTML = admin.username;
        });
    });

    $.get("http://localhost:4000/api/appointmentid", function(data, status){
      var adminname = document.getElementById("username").textContent;
      if(adminname == "baumeyerj"){
        var app = "";
        data.forEach(ap => {
         app = ap.username + "\xa0\xa0\xa0\xa0\xa0"+ ap.studentName + "\xa0\xa0\xa0\xa0\xa0" + ap.date + "\xa0\xa0\xa0\xa0\xa0" + ap.time + "\xa0\xa0\xa0\xa0\xa0" + ap.class + "\xa0\xa0\xa0\xa0\xa0" + ap.email + "\xa0\xa0\xa0\xa0\xa0" + "completed= " + ap.completed + "\xa0\xa0\xa0\xa0\xa0"+ "canceled= "+ap.canceled+ "\xa0\xa0\xa0\xa0\xa0"+ "noshow= "+ap.noshow+ "\xa0\xa0\xa0\xa0\xa0"+"apptId= " + ap.apptId; 
            addAppointment(app);
        });
      }
    });
}

function deletetmpusr(){
   $.post("http://localhost:4000/api/deletetempadmin", function(data, status){
       console.log("1 record changed");
     });
   
}

function addAppointment(appointment){

    var x = document.getElementById("listofas");
    var option = document.createElement("option");
    option.text = appointment;
    x.add(option);
}

function mf() {
   var adminname = document.getElementById("username").textContent;
   $.get("http://localhost:4000/api/appointmentid", function(data, status){
      var adminname = document.getElementById("username").textContent;
     
        var app = "";
        var txt = "";
        data.forEach(ap => {
         app = ap.studentName + "\xa0\xa0\xa0\xa0\xa0" + ap.date + "\xa0\xa0\xa0\xa0\xa0" + ap.time + "\xa0\xa0\xa0\xa0\xa0" + ap.class + "\xa0\xa0\xa0\xa0\xa0" + ap.email + "\xa0\xa0\xa0\xa0\xa0" + "completed= " + ap.completed + "\xa0\xa0\xa0\xa0\xa0"+ "canceled= "+ap.canceled+ "\xa0\xa0\xa0\xa0\xa0"+ "noshow= "+ap.noshow+ "\xa0\xa0\xa0\xa0\xa0"+"apptId= " + ap.apptId+"\n"; 
            txt+=app;
         
            addAppointment(app);
        });
        console.log(txt);
        if(adminname == "baumeyerj"){
   
         $.post("http://localhost:4000/api/makeFile",{text:txt}, function(data, status){
         });

         window.open("http://localhost:4000/api/download");
     
        }

      
      
    });

}

function createTutor(){
    var usrname = document.getElementById("exampleInputEmail1").value;
    var pwd = document.getElementById("exampleInputPassword1").value;
    var adminname = document.getElementById("username").textContent;
    console.log(usrname);
    console.log(pwd);
    if(adminname == "baumeyerj"){
    $.post("http://localhost:4000/api/cttutors", {username : usrname, password : pwd}, function(data, status){
        console.log("1 record changed");
     });
   }
}

function deleteTutor(){
   var usrname = document.getElementById("exampleInputEmail2").value;
   var adminname = document.getElementById("username").textContent;
   console.log(usrname);
   if(adminname == "baumeyerj"){
   $.post("http://localhost:4000/api/dttutors", {username : usrname}, function(data, status){
       console.log("1 record changed");
    });
   }
}

function deleteaps(){
   var adminname = document.getElementById("username").textContent;
   if(adminname == "baumeyerj"){
      $.post("http://localhost:4000/api/deleteapps", function(data, status){
          console.log("1 record changed");
       });
      }
}