const bodyParser = require('body-parser')
const express = require("express")
const app = express(); //server object
const router = express.Router(); 
const port = 4000; //localhost:4000

app.set('port', port);


app.listen(port, ()=> {
    console.log("We are using port: " + port);
  });

  // This code right here is magic!
app.use(function(req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
});

app.use('/', express.static('public'))

app.use('/api', router);
router.use(bodyParser.json());
router.use(bodyParser.urlencoded({ extended: true }));
// ^^ Magic code!!

var mysql = require('mysql');

var con = mysql.createConnection({
  host: "suttonnet.tk",
  user: "tutoringadmin",
  password: "math4me!",
  database: "tutoring"
});

//  con.connect(function(err) {
//    if (err) throw err;
//    console.log("Connected!");
//  });


// app.get('/courses', function(req, res) {
//     con.connect(function(err) {
//         if (err) throw err;
//         con.query("SELECT * FROM coursesNames", function (err, data, fields) {
//           if (err) throw err;
//           console.log(data);
//         });
//       });      
//         res.status(200).send(data)
//     })

 router.route('/courses').get(function(req, res) {
     con.connect(function(err) {
         //if (err) throw err;
         con.query("SELECT * FROM coursesNames", function (err, data, fields) {
           if (err) throw err;
           console.log(data);
           res.status(200).send(data)
         });
       });   
     })
  
     router.route('/tutors').get(function(req, res) {
      con.connect(function(err) {
          //if (err) throw err;
          con.query("SELECT * FROM courses", function (err, data, fields) {
            if (err) throw err;
            console.log(data);
            res.status(200).send(data)
          });
        });   
      })

      router.route('/monday').get(function(req, res) {
        con.connect(function(err) {
            //if (err) throw err;
            con.query("SELECT * FROM monday", function (err, data, fields) {
              if (err) throw err;
              console.log(data);
              res.status(200).send(data)
            });
          });   
        })

        router.route('/tuesday').get(function(req, res) {
          con.connect(function(err) {
              //if (err) throw err;
              con.query("SELECT * FROM tuesday", function (err, data, fields) {
                if (err) throw err;
                console.log(data);
                res.status(200).send(data)
              });
            });   
          })

          router.route('/wednesday').get(function(req, res) {
            con.connect(function(err) {
                //if (err) throw err;
                con.query("SELECT * FROM wednesday", function (err, data, fields) {
                  if (err) throw err;
                  console.log(data);
                  res.status(200).send(data)
                });
              });   
            })

            router.route('/thursday').get(function(req, res) {
              con.connect(function(err) {
                  //if (err) throw err;
                  con.query("SELECT * FROM thursday", function (err, data, fields) {
                    if (err) throw err;
                    console.log(data);
                    res.status(200).send(data)
                  });
                });   
              })
              router.route('/friday').get(function(req, res) {
                con.connect(function(err) {
                    //if (err) throw err;
                    con.query("SELECT * FROM friday", function (err, data, fields) {
                      if (err) throw err;
                      console.log(data);
                      res.status(200).send(data)
                    });
                  });   
                })

                router.route('/saturday').get(function(req, res) {
                  con.connect(function(err) {
                      //if (err) throw err;
                      con.query("SELECT * FROM saturday", function (err, data, fields) {
                        if (err) throw err;
                        console.log(data);
                        res.status(200).send(data)
                      });
                    });   
                  })
                  router.route('/sunday').get(function(req, res) {
                    con.connect(function(err) {
                        //if (err) throw err;
                        con.query("SELECT * FROM sunday", function (err, data, fields) {
                          if (err) throw err;
                          console.log(data);
                          res.status(200).send(data)
                        });
                      });   
                    })
            
        

            router.route('/tutorname').post(function(req, res) {
              con.connect(function(err) {
                  //if (err) throw err;
                  con.query("Update tutors set name = ? where username = ?",[ req.body.name, req.body.username ], function (err, results) {
                    if (err) throw err;
                    res.status(200)
                  });
                });
                con.connect(function(err) {
                  //if (err) throw err;
                  con.query("Update courses set tutorname = ? where username = ?",[ req.body.name, req.body.username ], function (err, results) {
                    if (err) throw err;
                    res.status(200)
                  });
                });   
                con.connect(function(err) {
                  //if (err) throw err;
                  con.query("Update monday set tutorname = ? where username = ?",[ req.body.name, req.body.username ], function (err, results) {
                    if (err) throw err;
                    res.status(200)
                  });
                });
                con.connect(function(err) {
                  //if (err) throw err;
                  con.query("Update tuesday set tutorname = ? where username = ?",[ req.body.name, req.body.username ], function (err, results) {
                    if (err) throw err;
                    res.status(200)
                  });
                });
                con.connect(function(err) {
                  //if (err) throw err;
                  con.query("Update wednesday set tutorname = ? where username = ?",[ req.body.name, req.body.username ], function (err, results) {
                    if (err) throw err;
                    res.status(200)
                  });
                });
                con.connect(function(err) {
                  //if (err) throw err;
                  con.query("Update thursday set tutorname = ? where username = ?",[ req.body.name, req.body.username ], function (err, results) {
                    if (err) throw err;
                    res.status(200)
                  });
                });
                con.connect(function(err) {
                  //if (err) throw err;
                  con.query("Update friday set tutorname = ? where username = ?",[ req.body.name, req.body.username ], function (err, results) {
                    if (err) throw err;
                    res.status(200)
                  });
                });
                con.connect(function(err) {
                  //if (err) throw err;
                  con.query("Update saturday set tutorname = ? where username = ?",[ req.body.name, req.body.username ], function (err, results) {
                    if (err) throw err;
                    res.status(200)
                  });
                });
                con.connect(function(err) {
                  //if (err) throw err;
                  con.query("Update sunday set tutorname = ? where username = ?",[ req.body.name, req.body.username ], function (err, results) {
                    if (err) throw err;
                    res.status(200)
                  });
                });
              })


              router.route('/tutoremail').post(function(req, res) {
                con.connect(function(err) {
                    //if (err) throw err;
                    con.query("Update tutors set email = ? where username = ?",[ req.body.email, req.body.username ], function (err, results) {
                      if (err) throw err;
                      res.status(200)
                    });
                  });   
                })

                router.route('/tutordescription').post(function(req, res) {
                  con.connect(function(err) {
                      //if (err) throw err;
                      con.query("Update tutors set description = ? where username = ?",[ req.body.description, req.body.username ], function (err, results) {
                        if (err) throw err;
                        res.status(200)
                      });
                    });   
                  })

                  router.route('/alg105on').post(function(req, res) {
                    con.connect(function(err) {
                        //if (err) throw err;
                        con.query("Update courses set `Alg105` = 1 where username = ?",[req.body.username], function (err, results) {
                          if (err) throw err;
                          res.status(200)
                        });
                      });   
                  })

                  router.route('/alg108on').post(function(req, res) {
                    con.connect(function(err) {
                        //if (err) throw err;
                        con.query("Update courses set `Alg108` = 1 where username = ?",[req.body.username], function (err, results) {
                          if (err) throw err;
                          res.status(200)
                        });
                      });   
                  })
                  router.route('/alg118on').post(function(req, res) {
                    con.connect(function(err) {
                        //if (err) throw err;
                        con.query("Update courses set `Alg118` = 1 where username = ?",[req.body.username], function (err, results) {
                          if (err) throw err;
                          res.status(200)
                        });
                      });   
                  })
                  router.route('/alg120on').post(function(req, res) {
                    con.connect(function(err) {
                        //if (err) throw err;
                        con.query("Update courses set `Alg120` = 1 where username = ?",[req.body.username], function (err, results) {
                          if (err) throw err;
                          res.status(200)
                        });
                      });   
                  })
                  router.route('/math103on').post(function(req, res) {
                    con.connect(function(err) {
                        //if (err) throw err;
                        con.query("Update courses set `Math103` = 1 where username = ?",[req.body.username], function (err, results) {
                          if (err) throw err;
                          res.status(200)
                        });
                      });   
                  })
                  router.route('/math105on').post(function(req, res) {
                    con.connect(function(err) {
                        //if (err) throw err;
                        con.query("Update courses set `Math105` = 1 where username = ?",[req.body.username], function (err, results) {
                          if (err) throw err;
                          res.status(200)
                        });
                      });   
                  })
                  router.route('/math106on').post(function(req, res) {
                    con.connect(function(err) {
                        //if (err) throw err;
                        con.query("Update courses set `Math106` = 1 where username = ?",[req.body.username], function (err, results) {
                          if (err) throw err;
                          res.status(200)
                        });
                      });   
                  })
                  router.route('/math107on').post(function(req, res) {
                    con.connect(function(err) {
                        //if (err) throw err;
                        con.query("Update courses set `Math107` = 1 where username = ?",[req.body.username], function (err, results) {
                          if (err) throw err;
                          res.status(200)
                        });
                      });   
                  })
                  router.route('/math110on').post(function(req, res) {
                    con.connect(function(err) {
                        //if (err) throw err;
                        con.query("Update courses set `Math110` = 1 where username = ?",[req.body.username], function (err, results) {
                          if (err) throw err;
                          res.status(200)
                        });
                      });   
                  })
                  router.route('/math117on').post(function(req, res) {
                    con.connect(function(err) {
                        //if (err) throw err;
                        con.query("Update courses set `Math117` = 1 where username = ?",[req.body.username], function (err, results) {
                          if (err) throw err;
                          res.status(200)
                        });
                      });   
                  })
                  router.route('/math121on').post(function(req, res) {
                    con.connect(function(err) {
                        //if (err) throw err;
                        con.query("Update courses set `Math121` = 1 where username = ?",[req.body.username], function (err, results) {
                          if (err) throw err;
                          res.status(200)
                        });
                      });   
                  })
                  router.route('/math129on').post(function(req, res) {
                    con.connect(function(err) {
                        //if (err) throw err;
                        con.query("Update courses set `Math129` = 1 where username = ?",[req.body.username], function (err, results) {
                          if (err) throw err;
                          res.status(200)
                        });
                      });   
                  })
                  router.route('/math131on').post(function(req, res) {
                    con.connect(function(err) {
                        //if (err) throw err;
                        con.query("Update courses set `Math131` = 1 where username = ?",[req.body.username], function (err, results) {
                          if (err) throw err;
                          res.status(200)
                        });
                      });   
                  })
                  router.route('/math132on').post(function(req, res) {
                    con.connect(function(err) {
                        //if (err) throw err;
                        con.query("Update courses set `Math132` = 1 where username = ?",[req.body.username], function (err, results) {
                          if (err) throw err;
                          res.status(200)
                        });
                      });   
                  })
                  router.route('/math141on').post(function(req, res) {
                    con.connect(function(err) {
                        //if (err) throw err;
                        con.query("Update courses set `Math141` = 1 where username = ?",[req.body.username], function (err, results) {
                          if (err) throw err;
                          res.status(200)
                        });
                      });   
                  })
                  router.route('/math151on').post(function(req, res) {
                    con.connect(function(err) {
                        //if (err) throw err;
                        con.query("Update courses set `Math151` = 1 where username = ?",[req.body.username], function (err, results) {
                          if (err) throw err;
                          res.status(200)
                        });
                      });   
                  })
                  router.route('/math152on').post(function(req, res) {
                    con.connect(function(err) {
                        //if (err) throw err;
                        con.query("Update courses set `Math103` = 1 where username = ?",[req.body.username], function (err, results) {
                          if (err) throw err;
                          res.status(200)
                        });
                      });   
                  })
                  router.route('/math162on').post(function(req, res) {
                    con.connect(function(err) {
                        //if (err) throw err;
                        con.query("Update courses set `Math162` = 1 where username = ?",[req.body.username], function (err, results) {
                          if (err) throw err;
                          res.status(200)
                        });
                      });   
                  })
                  router.route('/math231on').post(function(req, res) {
                    con.connect(function(err) {
                        //if (err) throw err;
                        con.query("Update courses set `Math231` = 1 where username = ?",[req.body.username], function (err, results) {
                          if (err) throw err;
                          res.status(200)
                        });
                      });   
                  })
                  router.route('/math232on').post(function(req, res) {
                    con.connect(function(err) {
                        //if (err) throw err;
                        con.query("Update courses set `Math232` = 1 where username = ?",[req.body.username], function (err, results) {
                          if (err) throw err;
                          res.status(200)
                        });
                      });   
                  })
                  router.route('/math301on').post(function(req, res) {
                    con.connect(function(err) {
                        //if (err) throw err;
                        con.query("Update courses set `Math301` = 1 where username = ?",[req.body.username], function (err, results) {
                          if (err) throw err;
                          res.status(200)
                        });
                      });   
                  })
                  router.route('/math308on').post(function(req, res) {
                    con.connect(function(err) {
                        //if (err) throw err;
                        con.query("Update courses set `Math308` = 1 where username = ?",[req.body.username], function (err, results) {
                          if (err) throw err;
                          res.status(200)
                        });
                      });   
                  })
                  router.route('/math309on').post(function(req, res) {
                    con.connect(function(err) {
                        //if (err) throw err;
                        con.query("Update courses set `Math309` = 1 where username = ?",[req.body.username], function (err, results) {
                          if (err) throw err;
                          res.status(200)
                        });
                      });   
                  })
                  router.route('/math329on').post(function(req, res) {
                    con.connect(function(err) {
                        //if (err) throw err;
                        con.query("Update courses set `Math329` = 1 where username = ?",[req.body.username], function (err, results) {
                          if (err) throw err;
                          res.status(200)
                        });
                      });   
                  })
                  router.route('/math401on').post(function(req, res) {
                    con.connect(function(err) {
                        //if (err) throw err;
                        con.query("Update courses set `Math401` = 1 where username = ?",[req.body.username], function (err, results) {
                          if (err) throw err;
                          res.status(200)
                        });
                      });   
                  })
                  router.route('/math402on').post(function(req, res) {
                    con.connect(function(err) {
                        //if (err) throw err;
                        con.query("Update courses set `Math402` = 1 where username = ?",[req.body.username], function (err, results) {
                          if (err) throw err;
                          res.status(200)
                        });
                      });   
                  })
                  router.route('/math405on').post(function(req, res) {
                    con.connect(function(err) {
                        //if (err) throw err;
                        con.query("Update courses set `Math405` = 1 where username = ?",[req.body.username], function (err, results) {
                          if (err) throw err;
                          res.status(200)
                        });
                      });   
                  })
                  router.route('/math413on').post(function(req, res) {
                    con.connect(function(err) {
                        //if (err) throw err;
                        con.query("Update courses set `Math413` = 1 where username = ?",[req.body.username], function (err, results) {
                          if (err) throw err;
                          res.status(200)
                        });
                      });   
                  })
                  router.route('/math414on').post(function(req, res) {
                    con.connect(function(err) {
                        //if (err) throw err;
                        con.query("Update courses set `Math414` = 1 where username = ?",[req.body.username], function (err, results) {
                          if (err) throw err;
                          res.status(200)
                        });
                      });   
                  })

                  router.route('/alg105off').post(function(req, res) {
                    con.connect(function(err) {
                        //if (err) throw err;
                        con.query("Update courses set `Alg105` = 0 where username = ?",[req.body.username], function (err, results) {
                          if (err) throw err;
                          res.status(200)
                        });
                      });   
                  })

                  router.route('/alg108off').post(function(req, res) {
                    con.connect(function(err) {
                        //if (err) throw err;
                        con.query("Update courses set `Alg108` = 0 where username = ?",[req.body.username], function (err, results) {
                          if (err) throw err;
                          res.status(200)
                        });
                      });   
                  })
                  router.route('/alg118off').post(function(req, res) {
                    con.connect(function(err) {
                        //if (err) throw err;
                        con.query("Update courses set `Alg118` = 0 where username = ?",[req.body.username], function (err, results) {
                          if (err) throw err;
                          res.status(200)
                        });
                      });   
                  })
                  router.route('/alg120off').post(function(req, res) {
                    con.connect(function(err) {
                        //if (err) throw err;
                        con.query("Update courses set `Alg120` = 0 where username = ?",[req.body.username], function (err, results) {
                          if (err) throw err;
                          res.status(200)
                        });
                      });   
                  })
                  router.route('/math103off').post(function(req, res) {
                    con.connect(function(err) {
                        //if (err) throw err;
                        con.query("Update courses set `Math103` = 0 where username = ?",[req.body.username], function (err, results) {
                          if (err) throw err;
                          res.status(200)
                        });
                      });   
                  })
                  router.route('/math105off').post(function(req, res) {
                    con.connect(function(err) {
                        //if (err) throw err;
                        con.query("Update courses set `Math105` = 0 where username = ?",[req.body.username], function (err, results) {
                          if (err) throw err;
                          res.status(200)
                        });
                      });   
                  })
                  router.route('/math106off').post(function(req, res) {
                    con.connect(function(err) {
                        //if (err) throw err;
                        con.query("Update courses set `Math106` = 0 where username = ?",[req.body.username], function (err, results) {
                          if (err) throw err;
                          res.status(200)
                        });
                      });   
                  })
                  router.route('/math107off').post(function(req, res) {
                    con.connect(function(err) {
                        //if (err) throw err;
                        con.query("Update courses set `Math107` = 0 where username = ?",[req.body.username], function (err, results) {
                          if (err) throw err;
                          res.status(200)
                        });
                      });   
                  })
                  router.route('/math110off').post(function(req, res) {
                    con.connect(function(err) {
                        //if (err) throw err;
                        con.query("Update courses set `Math110` = 0 where username = ?",[req.body.username], function (err, results) {
                          if (err) throw err;
                          res.status(200)
                        });
                      });   
                  })
                  router.route('/math117off').post(function(req, res) {
                    con.connect(function(err) {
                        //if (err) throw err;
                        con.query("Update courses set `Math117` = 0 where username = ?",[req.body.username], function (err, results) {
                          if (err) throw err;
                          res.status(200)
                        });
                      });   
                  })
                  router.route('/math121off').post(function(req, res) {
                    con.connect(function(err) {
                        //if (err) throw err;
                        con.query("Update courses set `Math121` = 0 where username = ?",[req.body.username], function (err, results) {
                          if (err) throw err;
                          res.status(200)
                        });
                      });   
                  })
                  router.route('/math129off').post(function(req, res) {
                    con.connect(function(err) {
                        //if (err) throw err;
                        con.query("Update courses set `Math129` = 0 where username = ?",[req.body.username], function (err, results) {
                          if (err) throw err;
                          res.status(200)
                        });
                      });   
                  })
                  router.route('/math131off').post(function(req, res) {
                    con.connect(function(err) {
                        //if (err) throw err;
                        con.query("Update courses set `Math131` = 0 where username = ?",[req.body.username], function (err, results) {
                          if (err) throw err;
                          res.status(200)
                        });
                      });   
                  })
                  router.route('/math132off').post(function(req, res) {
                    con.connect(function(err) {
                        //if (err) throw err;
                        con.query("Update courses set `Math132` = 0 where username = ?",[req.body.username], function (err, results) {
                          if (err) throw err;
                          res.status(200)
                        });
                      });   
                  })
                  router.route('/math141off').post(function(req, res) {
                    con.connect(function(err) {
                        //if (err) throw err;
                        con.query("Update courses set `Math141` = 0 where username = ?",[req.body.username], function (err, results) {
                          if (err) throw err;
                          res.status(200)
                        });
                      });   
                  })
                  router.route('/math151off').post(function(req, res) {
                    con.connect(function(err) {
                        //if (err) throw err;
                        con.query("Update courses set `Math151` = 0 where username = ?",[req.body.username], function (err, results) {
                          if (err) throw err;
                          res.status(200)
                        });
                      });   
                  })
                  router.route('/math152off').post(function(req, res) {
                    con.connect(function(err) {
                        //if (err) throw err;
                        con.query("Update courses set `Math103` = 0 where username = ?",[req.body.username], function (err, results) {
                          if (err) throw err;
                          res.status(200)
                        });
                      });   
                  })
                  router.route('/math162off').post(function(req, res) {
                    con.connect(function(err) {
                        //if (err) throw err;
                        con.query("Update courses set `Math162` = 0 where username = ?",[req.body.username], function (err, results) {
                          if (err) throw err;
                          res.status(200)
                        });
                      });   
                  })
                  router.route('/math231off').post(function(req, res) {
                    con.connect(function(err) {
                        //if (err) throw err;
                        con.query("Update courses set `Math231` = 0 where username = ?",[req.body.username], function (err, results) {
                          if (err) throw err;
                          res.status(200)
                        });
                      });   
                  })
                  router.route('/math232off').post(function(req, res) {
                    con.connect(function(err) {
                        //if (err) throw err;
                        con.query("Update courses set `Math232` = 0 where username = ?",[req.body.username], function (err, results) {
                          if (err) throw err;
                          res.status(200)
                        });
                      });   
                  })
                  router.route('/math301off').post(function(req, res) {
                    con.connect(function(err) {
                        //if (err) throw err;
                        con.query("Update courses set `Math301` = 0 where username = ?",[req.body.username], function (err, results) {
                          if (err) throw err;
                          res.status(200)
                        });
                      });   
                  })
                  router.route('/math308off').post(function(req, res) {
                    con.connect(function(err) {
                        //if (err) throw err;
                        con.query("Update courses set `Math308` = 0 where username = ?",[req.body.username], function (err, results) {
                          if (err) throw err;
                          res.status(200)
                        });
                      });   
                  })
                  router.route('/math309off').post(function(req, res) {
                    con.connect(function(err) {
                        //if (err) throw err;
                        con.query("Update courses set `Math309` = 0 where username = ?",[req.body.username], function (err, results) {
                          if (err) throw err;
                          res.status(200)
                        });
                      });   
                  })
                  router.route('/math329off').post(function(req, res) {
                    con.connect(function(err) {
                        //if (err) throw err;
                        con.query("Update courses set `Math329` = 0 where username = ?",[req.body.username], function (err, results) {
                          if (err) throw err;
                          res.status(200)
                        });
                      });   
                  })
                  router.route('/math401off').post(function(req, res) {
                    con.connect(function(err) {
                        //if (err) throw err;
                        con.query("Update courses set `Math401` = 0 where username = ?",[req.body.username], function (err, results) {
                          if (err) throw err;
                          res.status(200)
                        });
                      });   
                  })
                  router.route('/math402off').post(function(req, res) {
                    con.connect(function(err) {
                        //if (err) throw err;
                        con.query("Update courses set `Math402` = 0 where username = ?",[req.body.username], function (err, results) {
                          if (err) throw err;
                          res.status(200)
                        });
                      });   
                  })
                  router.route('/math405off').post(function(req, res) {
                    con.connect(function(err) {
                        //if (err) throw err;
                        con.query("Update courses set `Math405` = 0 where username = ?",[req.body.username], function (err, results) {
                          if (err) throw err;
                          res.status(200)
                        });
                      });   
                  })
                  router.route('/math413off').post(function(req, res) {
                    con.connect(function(err) {
                        //if (err) throw err;
                        con.query("Update courses set `Math413` = 0 where username = ?",[req.body.username], function (err, results) {
                          if (err) throw err;
                          res.status(200)
                        });
                      });   
                  })
                  router.route('/math414off').post(function(req, res) {
                    con.connect(function(err) {
                        //if (err) throw err;
                        con.query("Update courses set `Math414` = 0 where username = ?",[req.body.username], function (err, results) {
                          if (err) throw err;
                          res.status(200)
                        });
                      });   
                  })
                 

                  router.route('/mon800on').post(function(req, res) {
                    con.connect(function(err) {
                        //if (err) throw err;
                        con.query("Update monday set `8:00` = 1 where username = ?",[req.body.username], function (err, results) {
                          if (err) throw err;
                          res.status(200)
                        });
                      });   
                    })

                    router.route('/mon830on').post(function(req, res) {
                      con.connect(function(err) {
                          //if (err) throw err;
                          con.query("Update monday set `8:30` = 1 where username = ?",[req.body.username], function (err, results) {
                            if (err) throw err;
                            res.status(200)
                          });
                        });   
                      })
                      router.route('/mon900on').post(function(req, res) {
                        con.connect(function(err) {
                            //if (err) throw err;
                            con.query("Update monday set `9:00` = 1 where username = ?",[req.body.username], function (err, results) {
                              if (err) throw err;
                              res.status(200)
                            });
                          });   
                        })
                        router.route('/mon930on').post(function(req, res) {
                          con.connect(function(err) {
                              //if (err) throw err;
                              con.query("Update monday set `9:30` = 1 where username = ?",[req.body.username], function (err, results) {
                                if (err) throw err;
                                res.status(200)
                              });
                            });   
                          })
                          router.route('/mon1000on').post(function(req, res) {
                            con.connect(function(err) {
                                //if (err) throw err;
                                con.query("Update monday set `10:00` = 1 where username = ?",[req.body.username], function (err, results) {
                                  if (err) throw err;
                                  res.status(200)
                                });
                              });   
                            })
                            router.route('/mon1030on').post(function(req, res) {
                              con.connect(function(err) {
                                  //if (err) throw err;
                                  con.query("Update monday set `10:30` = 1 where username = ?",[req.body.username], function (err, results) {
                                    if (err) throw err;
                                    res.status(200)
                                  });
                                });   
                              })
                              router.route('/mon1100on').post(function(req, res) {
                                con.connect(function(err) {
                                    //if (err) throw err;
                                    con.query("Update monday set `11:00` = 1 where username = ?",[req.body.username], function (err, results) {
                                      if (err) throw err;
                                      res.status(200)
                                    });
                                  });   
                                })
                                router.route('/mon1130on').post(function(req, res) {
                                  con.connect(function(err) {
                                      //if (err) throw err;
                                      con.query("Update monday set `11:30` = 1 where username = ?",[req.body.username], function (err, results) {
                                        if (err) throw err;
                                        res.status(200)
                                      });
                                    });   
                                  })
                                  router.route('/mon1200on').post(function(req, res) {
                                    con.connect(function(err) {
                                        //if (err) throw err;
                                        con.query("Update monday set `12:00` = 1 where username = ?",[req.body.username], function (err, results) {
                                          if (err) throw err;
                                          res.status(200)
                                        });
                                      });   
                                    })
                                    router.route('/mon1230on').post(function(req, res) {
                                      con.connect(function(err) {
                                          //if (err) throw err;
                                          con.query("Update monday set `12:30` = 1 where username = ?",[req.body.username], function (err, results) {
                                            if (err) throw err;
                                            res.status(200)
                                          });
                                        });   
                                      })
                                      router.route('/mon1300on').post(function(req, res) {
                                        con.connect(function(err) {
                                            //if (err) throw err;
                                            con.query("Update monday set `13:00` = 1 where username = ?",[req.body.username], function (err, results) {
                                              if (err) throw err;
                                              res.status(200)
                                            });
                                          });   
                                        })
                                        router.route('/mon1330on').post(function(req, res) {
                                          con.connect(function(err) {
                                              //if (err) throw err;
                                              con.query("Update monday set `13:30` = 1 where username = ?",[req.body.username], function (err, results) {
                                                if (err) throw err;
                                                res.status(200)
                                              });
                                            });   
                                          })
                                          router.route('/mon1400on').post(function(req, res) {
                                            con.connect(function(err) {
                                                //if (err) throw err;
                                                con.query("Update monday set `14:00` = 1 where username = ?",[req.body.username], function (err, results) {
                                                  if (err) throw err;
                                                  res.status(200)
                                                });
                                              });   
                                            })
                                            router.route('/mon1430on').post(function(req, res) {
                                              con.connect(function(err) {
                                                  //if (err) throw err;
                                                  con.query("Update monday set `14:30` = 1 where username = ?",[req.body.username], function (err, results) {
                                                    if (err) throw err;
                                                    res.status(200)
                                                  });
                                                });   
                                              })
                                            router.route('/mon1500on').post(function(req, res) {
                                              con.connect(function(err) {
                                                  //if (err) throw err;
                                                  con.query("Update monday set `15:00` = 1 where username = ?",[req.body.username], function (err, results) {
                                                    if (err) throw err;
                                                    res.status(200)
                                                  });
                                                });   
                                              })
                                              router.route('/mon1530on').post(function(req, res) {
                                                con.connect(function(err) {
                                                    //if (err) throw err;
                                                    con.query("Update monday set `15:30` = 1 where username = ?",[req.body.username], function (err, results) {
                                                      if (err) throw err;
                                                      res.status(200)
                                                    });
                                                  });   
                                                })
                                                router.route('/mon1600on').post(function(req, res) {
                                                  con.connect(function(err) {
                                                      //if (err) throw err;
                                                      con.query("Update monday set `16:00` = 1 where username = ?",[req.body.username], function (err, results) {
                                                        if (err) throw err;
                                                        res.status(200)
                                                      });
                                                    });   
                                                  })
                                                  router.route('/mon1630on').post(function(req, res) {
                                                    con.connect(function(err) {
                                                        //if (err) throw err;
                                                        con.query("Update monday set `16:30` = 1 where username = ?",[req.body.username], function (err, results) {
                                                          if (err) throw err;
                                                          res.status(200)
                                                        });
                                                      });   
                                                    })
                                                    router.route('/mon1700on').post(function(req, res) {
                                                      con.connect(function(err) {
                                                          //if (err) throw err;
                                                          con.query("Update monday set `17:00` = 1 where username = ?",[req.body.username], function (err, results) {
                                                            if (err) throw err;
                                                            res.status(200)
                                                          });
                                                        });   
                                                      })
                                                      router.route('/mon1730on').post(function(req, res) {
                                                        con.connect(function(err) {
                                                            //if (err) throw err;
                                                            con.query("Update monday set `17:30` = 1 where username = ?",[req.body.username], function (err, results) {
                                                              if (err) throw err;
                                                              res.status(200)
                                                            });
                                                          });   
                                                        })
                                                        router.route('/mon1800on').post(function(req, res) {
                                                          con.connect(function(err) {
                                                              //if (err) throw err;
                                                              con.query("Update monday set `18:00` = 1 where username = ?",[req.body.username], function (err, results) {
                                                                if (err) throw err;
                                                                res.status(200)
                                                              });
                                                            });   
                                                          })
                                                          router.route('/mon1830on').post(function(req, res) {
                                                            con.connect(function(err) {
                                                                //if (err) throw err;
                                                                con.query("Update monday set `18:30` = 1 where username = ?",[req.body.username], function (err, results) {
                                                                  if (err) throw err;
                                                                  res.status(200)
                                                                });
                                                              });   
                                                            })
                                                            router.route('/mon1900on').post(function(req, res) {
                                                              con.connect(function(err) {
                                                                  //if (err) throw err;
                                                                  con.query("Update monday set `19:00` = 1 where username = ?",[req.body.username], function (err, results) {
                                                                    if (err) throw err;
                                                                    res.status(200)
                                                                  });
                                                                });   
                                                              })
                                                              router.route('/mon1930on').post(function(req, res) {
                                                                con.connect(function(err) {
                                                                    //if (err) throw err;
                                                                    con.query("Update monday set `19:30` = 1 where username = ?",[req.body.username], function (err, results) {
                                                                      if (err) throw err;
                                                                      res.status(200)
                                                                    });
                                                                  });   
                                                                })
                                                                router.route('/mon2000on').post(function(req, res) {
                                                                  con.connect(function(err) {
                                                                      //if (err) throw err;
                                                                      con.query("Update monday set `20:00` = 1 where username = ?",[req.body.username], function (err, results) {
                                                                        if (err) throw err;
                                                                        res.status(200)
                                                                      });
                                                                    });   
                                                                  })
              
                  router.route('/mon800off').post(function(req, res) {
                    con.connect(function(err) {
                        //if (err) throw err;
                        con.query("Update monday set `8:00` = 0 where username = ?",[req.body.username], function (err, results) {
                          if (err) throw err;
                          res.status(200)
                        });
                      });   
                    })

                    router.route('/mon830off').post(function(req, res) {
                      con.connect(function(err) {
                          //if (err) throw err;
                          con.query("Update monday set `8:30` = 0 where username = ?",[req.body.username], function (err, results) {
                            if (err) throw err;
                            res.status(200)
                          });
                        });   
                      })
                      router.route('/mon900off').post(function(req, res) {
                        con.connect(function(err) {
                            //if (err) throw err;
                            con.query("Update monday set `9:00` = 0 where username = ?",[req.body.username], function (err, results) {
                              if (err) throw err;
                              res.status(200)
                            });
                          });   
                        })
                        router.route('/mon930off').post(function(req, res) {
                          con.connect(function(err) {
                              //if (err) throw err;
                              con.query("Update monday set `9:30` = 0 where username = ?",[req.body.username], function (err, results) {
                                if (err) throw err;
                                res.status(200)
                              });
                            });   
                          })
                          router.route('/mon1000off').post(function(req, res) {
                            con.connect(function(err) {
                                //if (err) throw err;
                                con.query("Update monday set `10:00` = 0 where username = ?",[req.body.username], function (err, results) {
                                  if (err) throw err;
                                  res.status(200)
                                });
                              });   
                            })
                            router.route('/mon1030off').post(function(req, res) {
                              con.connect(function(err) {
                                  //if (err) throw err;
                                  con.query("Update monday set `10:30` = 0 where username = ?",[req.body.username], function (err, results) {
                                    if (err) throw err;
                                    res.status(200)
                                  });
                                });   
                              })
                              router.route('/mon1100off').post(function(req, res) {
                                con.connect(function(err) {
                                    //if (err) throw err;
                                    con.query("Update monday set `11:00` = 0 where username = ?",[req.body.username], function (err, results) {
                                      if (err) throw err;
                                      res.status(200)
                                    });
                                  });   
                                })
                                router.route('/mon1130off').post(function(req, res) {
                                  con.connect(function(err) {
                                      //if (err) throw err;
                                      con.query("Update monday set `11:30` = 0 where username = ?",[req.body.username], function (err, results) {
                                        if (err) throw err;
                                        res.status(200)
                                      });
                                    });   
                                  })
                                  router.route('/mon1200off').post(function(req, res) {
                                    con.connect(function(err) {
                                        //if (err) throw err;
                                        con.query("Update monday set `12:00` = 0 where username = ?",[req.body.username], function (err, results) {
                                          if (err) throw err;
                                          res.status(200)
                                        });
                                      });   
                                    })
                                    router.route('/mon1230off').post(function(req, res) {
                                      con.connect(function(err) {
                                          //if (err) throw err;
                                          con.query("Update monday set `12:30` = 0 where username = ?",[req.body.username], function (err, results) {
                                            if (err) throw err;
                                            res.status(200)
                                          });
                                        });   
                                      })
                                      router.route('/mon1300off').post(function(req, res) {
                                        con.connect(function(err) {
                                            //if (err) throw err;
                                            con.query("Update monday set `13:00` = 0 where username = ?",[req.body.username], function (err, results) {
                                              if (err) throw err;
                                              res.status(200)
                                            });
                                          });   
                                        })
                                        router.route('/mon1330off').post(function(req, res) {
                                          con.connect(function(err) {
                                              //if (err) throw err;
                                              con.query("Update monday set `13:30` = 0 where username = ?",[req.body.username], function (err, results) {
                                                if (err) throw err;
                                                res.status(200)
                                              });
                                            });   
                                          })
                                          router.route('/mon1400off').post(function(req, res) {
                                            con.connect(function(err) {
                                                //if (err) throw err;
                                                con.query("Update monday set `14:00` = 0 where username = ?",[req.body.username], function (err, results) {
                                                  if (err) throw err;
                                                  res.status(200)
                                                });
                                              });   
                                            })
                                            router.route('/mon1430off').post(function(req, res) {
                                              con.connect(function(err) {
                                                  //if (err) throw err;
                                                  con.query("Update monday set `14:30` = 0 where username = ?",[req.body.username], function (err, results) {
                                                    if (err) throw err;
                                                    res.status(200)
                                                  });
                                                });   
                                              })
                                            router.route('/mon1500off').post(function(req, res) {
                                              con.connect(function(err) {
                                                  //if (err) throw err;
                                                  con.query("Update monday set `15:00` = 0 where username = ?",[req.body.username], function (err, results) {
                                                    if (err) throw err;
                                                    res.status(200)
                                                  });
                                                });   
                                              })
                                              router.route('/mon1530off').post(function(req, res) {
                                                con.connect(function(err) {
                                                    //if (err) throw err;
                                                    con.query("Update monday set `15:30` = 0 where username = ?",[req.body.username], function (err, results) {
                                                      if (err) throw err;
                                                      res.status(200)
                                                    });
                                                  });   
                                                })
                                                router.route('/mon1600off').post(function(req, res) {
                                                  con.connect(function(err) {
                                                      //if (err) throw err;
                                                      con.query("Update monday set `16:00` = 0 where username = ?",[req.body.username], function (err, results) {
                                                        if (err) throw err;
                                                        res.status(200)
                                                      });
                                                    });   
                                                  })
                                                  router.route('/mon1630off').post(function(req, res) {
                                                    con.connect(function(err) {
                                                        //if (err) throw err;
                                                        con.query("Update monday set `16:30` = 0 where username = ?",[req.body.username], function (err, results) {
                                                          if (err) throw err;
                                                          res.status(200)
                                                        });
                                                      });   
                                                    })
                                                    router.route('/mon1700off').post(function(req, res) {
                                                      con.connect(function(err) {
                                                          //if (err) throw err;
                                                          con.query("Update monday set `17:00` = 0 where username = ?",[req.body.username], function (err, results) {
                                                            if (err) throw err;
                                                            res.status(200)
                                                          });
                                                        });   
                                                      })
                                                      router.route('/mon1730off').post(function(req, res) {
                                                        con.connect(function(err) {
                                                            //if (err) throw err;
                                                            con.query("Update monday set `17:30` = 0 where username = ?",[req.body.username], function (err, results) {
                                                              if (err) throw err;
                                                              res.status(200)
                                                            });
                                                          });   
                                                        })
                                                        router.route('/mon1800off').post(function(req, res) {
                                                          con.connect(function(err) {
                                                              //if (err) throw err;
                                                              con.query("Update monday set `18:00` = 0 where username = ?",[req.body.username], function (err, results) {
                                                                if (err) throw err;
                                                                res.status(200)
                                                              });
                                                            });   
                                                          })
                                                          router.route('/mon1830off').post(function(req, res) {
                                                            con.connect(function(err) {
                                                                //if (err) throw err;
                                                                con.query("Update monday set `18:30` = 0 where username = ?",[req.body.username], function (err, results) {
                                                                  if (err) throw err;
                                                                  res.status(200)
                                                                });
                                                              });   
                                                            })
                                                            router.route('/mon1900off').post(function(req, res) {
                                                              con.connect(function(err) {
                                                                  //if (err) throw err;
                                                                  con.query("Update monday set `19:00` = 0 where username = ?",[req.body.username], function (err, results) {
                                                                    if (err) throw err;
                                                                    res.status(200)
                                                                  });
                                                                });   
                                                              })
                                                              router.route('/mon1930off').post(function(req, res) {
                                                                con.connect(function(err) {
                                                                    //if (err) throw err;
                                                                    con.query("Update monday set `19:30` = 0 where username = ?",[req.body.username], function (err, results) {
                                                                      if (err) throw err;
                                                                      res.status(200)
                                                                    });
                                                                  });   
                                                                })
                                                                router.route('/mon2000off').post(function(req, res) {
                                                                  con.connect(function(err) {
                                                                      //if (err) throw err;
                                                                      con.query("Update monday set `20:00` = 0 where username = ?",[req.body.username], function (err, results) {
                                                                        if (err) throw err;
                                                                        res.status(200)
                                                                      });
                                                                    });   
                                                                  })
              
              
                  router.route('/tue800on').post(function(req, res) {
                    con.connect(function(err) {
                        //if (err) throw err;
                        con.query("Update tuesday set `8:00` = 1 where username = ?",[req.body.username], function (err, results) {
                          if (err) throw err;
                          res.status(200)
                        });
                      });   
                    })

                    router.route('/tue830on').post(function(req, res) {
                      con.connect(function(err) {
                          //if (err) throw err;
                          con.query("Update tuesday set `8:30` = 1 where username = ?",[req.body.username], function (err, results) {
                            if (err) throw err;
                            res.status(200)
                          });
                        });   
                      })
                      router.route('/tue900on').post(function(req, res) {
                        con.connect(function(err) {
                            //if (err) throw err;
                            con.query("Update tuesday set `9:00` = 1 where username = ?",[req.body.username], function (err, results) {
                              if (err) throw err;
                              res.status(200)
                            });
                          });   
                        })
                        router.route('/tue930on').post(function(req, res) {
                          con.connect(function(err) {
                              //if (err) throw err;
                              con.query("Update tuesday set `9:30` = 1 where username = ?",[req.body.username], function (err, results) {
                                if (err) throw err;
                                res.status(200)
                              });
                            });   
                          })
                          router.route('/tue1000on').post(function(req, res) {
                            con.connect(function(err) {
                                //if (err) throw err;
                                con.query("Update tuesday set `10:00` = 1 where username = ?",[req.body.username], function (err, results) {
                                  if (err) throw err;
                                  res.status(200)
                                });
                              });   
                            })
                            router.route('/tue1030on').post(function(req, res) {
                              con.connect(function(err) {
                                  //if (err) throw err;
                                  con.query("Update tuesday set `10:30` = 1 where username = ?",[req.body.username], function (err, results) {
                                    if (err) throw err;
                                    res.status(200)
                                  });
                                });   
                              })
                              router.route('/tue1100on').post(function(req, res) {
                                con.connect(function(err) {
                                    //if (err) throw err;
                                    con.query("Update tuesday set `11:00` = 1 where username = ?",[req.body.username], function (err, results) {
                                      if (err) throw err;
                                      res.status(200)
                                    });
                                  });   
                                })
                                router.route('/tue1130on').post(function(req, res) {
                                  con.connect(function(err) {
                                      //if (err) throw err;
                                      con.query("Update tuesday set `11:30` = 1 where username = ?",[req.body.username], function (err, results) {
                                        if (err) throw err;
                                        res.status(200)
                                      });
                                    });   
                                  })
                                  router.route('/tue1200on').post(function(req, res) {
                                    con.connect(function(err) {
                                        //if (err) throw err;
                                        con.query("Update tuesday set `12:00` = 1 where username = ?",[req.body.username], function (err, results) {
                                          if (err) throw err;
                                          res.status(200)
                                        });
                                      });   
                                    })
                                    router.route('/tue1230on').post(function(req, res) {
                                      con.connect(function(err) {
                                          //if (err) throw err;
                                          con.query("Update tuesday set `12:30` = 1 where username = ?",[req.body.username], function (err, results) {
                                            if (err) throw err;
                                            res.status(200)
                                          });
                                        });   
                                      })
                                      router.route('/tue1300on').post(function(req, res) {
                                        con.connect(function(err) {
                                            //if (err) throw err;
                                            con.query("Update tuesday set `13:00` = 1 where username = ?",[req.body.username], function (err, results) {
                                              if (err) throw err;
                                              res.status(200)
                                            });
                                          });   
                                        })
                                        router.route('/tue1330on').post(function(req, res) {
                                          con.connect(function(err) {
                                              //if (err) throw err;
                                              con.query("Update tuesday set `13:30` = 1 where username = ?",[req.body.username], function (err, results) {
                                                if (err) throw err;
                                                res.status(200)
                                              });
                                            });   
                                          })
                                          router.route('/tue1400on').post(function(req, res) {
                                            con.connect(function(err) {
                                                //if (err) throw err;
                                                con.query("Update tuesday set `14:00` = 1 where username = ?",[req.body.username], function (err, results) {
                                                  if (err) throw err;
                                                  res.status(200)
                                                });
                                              });   
                                            })
                                            router.route('/tue1430on').post(function(req, res) {
                                              con.connect(function(err) {
                                                  //if (err) throw err;
                                                  con.query("Update tuesday set `14:30` = 1 where username = ?",[req.body.username], function (err, results) {
                                                    if (err) throw err;
                                                    res.status(200)
                                                  });
                                                });   
                                              })
                                            router.route('/tue1500on').post(function(req, res) {
                                              con.connect(function(err) {
                                                  //if (err) throw err;
                                                  con.query("Update tuesday set `15:00` = 1 where username = ?",[req.body.username], function (err, results) {
                                                    if (err) throw err;
                                                    res.status(200)
                                                  });
                                                });   
                                              })
                                              router.route('/tue1530on').post(function(req, res) {
                                                con.connect(function(err) {
                                                    //if (err) throw err;
                                                    con.query("Update tuesday set `15:30` = 1 where username = ?",[req.body.username], function (err, results) {
                                                      if (err) throw err;
                                                      res.status(200)
                                                    });
                                                  });   
                                                })
                                                router.route('/tue1600on').post(function(req, res) {
                                                  con.connect(function(err) {
                                                      //if (err) throw err;
                                                      con.query("Update tuesday set `16:00` = 1 where username = ?",[req.body.username], function (err, results) {
                                                        if (err) throw err;
                                                        res.status(200)
                                                      });
                                                    });   
                                                  })
                                                  router.route('/tue1630on').post(function(req, res) {
                                                    con.connect(function(err) {
                                                        //if (err) throw err;
                                                        con.query("Update tuesday set `16:30` = 1 where username = ?",[req.body.username], function (err, results) {
                                                          if (err) throw err;
                                                          res.status(200)
                                                        });
                                                      });   
                                                    })
                                                    router.route('/tue1700on').post(function(req, res) {
                                                      con.connect(function(err) {
                                                          //if (err) throw err;
                                                          con.query("Update tuesday set `17:00` = 1 where username = ?",[req.body.username], function (err, results) {
                                                            if (err) throw err;
                                                            res.status(200)
                                                          });
                                                        });   
                                                      })
                                                      router.route('/tue1730on').post(function(req, res) {
                                                        con.connect(function(err) {
                                                            //if (err) throw err;
                                                            con.query("Update tuesday set `17:30` = 1 where username = ?",[req.body.username], function (err, results) {
                                                              if (err) throw err;
                                                              res.status(200)
                                                            });
                                                          });   
                                                        })
                                                        router.route('/tue1800on').post(function(req, res) {
                                                          con.connect(function(err) {
                                                              //if (err) throw err;
                                                              con.query("Update tuesday set `18:00` = 1 where username = ?",[req.body.username], function (err, results) {
                                                                if (err) throw err;
                                                                res.status(200)
                                                              });
                                                            });   
                                                          })
                                                          router.route('/tue1830on').post(function(req, res) {
                                                            con.connect(function(err) {
                                                                //if (err) throw err;
                                                                con.query("Update tuesday set `18:30` = 1 where username = ?",[req.body.username], function (err, results) {
                                                                  if (err) throw err;
                                                                  res.status(200)
                                                                });
                                                              });   
                                                            })
                                                            router.route('/tue1900on').post(function(req, res) {
                                                              con.connect(function(err) {
                                                                  //if (err) throw err;
                                                                  con.query("Update tuesday set `19:00` = 1 where username = ?",[req.body.username], function (err, results) {
                                                                    if (err) throw err;
                                                                    res.status(200)
                                                                  });
                                                                });   
                                                              })
                                                              router.route('/tue1930on').post(function(req, res) {
                                                                con.connect(function(err) {
                                                                    //if (err) throw err;
                                                                    con.query("Update tuesday set `19:30` = 1 where username = ?",[req.body.username], function (err, results) {
                                                                      if (err) throw err;
                                                                      res.status(200)
                                                                    });
                                                                  });   
                                                                })
                                                                router.route('/tue2000on').post(function(req, res) {
                                                                  con.connect(function(err) {
                                                                      //if (err) throw err;
                                                                      con.query("Update tuesday set `20:00` = 1 where username = ?",[req.body.username], function (err, results) {
                                                                        if (err) throw err;
                                                                        res.status(200)
                                                                      });
                                                                    });   
                                                                  })
              
                  router.route('/tue800off').post(function(req, res) {
                    con.connect(function(err) {
                        //if (err) throw err;
                        con.query("Update tuesday set `8:00` = 0 where username = ?",[req.body.username], function (err, results) {
                          if (err) throw err;
                          res.status(200)
                        });
                      });   
                    })

                    router.route('/tue830off').post(function(req, res) {
                      con.connect(function(err) {
                          //if (err) throw err;
                          con.query("Update tuesday set `8:30` = 0 where username = ?",[req.body.username], function (err, results) {
                            if (err) throw err;
                            res.status(200)
                          });
                        });   
                      })
                      router.route('/tue900off').post(function(req, res) {
                        con.connect(function(err) {
                            //if (err) throw err;
                            con.query("Update tuesday set `9:00` = 0 where username = ?",[req.body.username], function (err, results) {
                              if (err) throw err;
                              res.status(200)
                            });
                          });   
                        })
                        router.route('/tue930off').post(function(req, res) {
                          con.connect(function(err) {
                              //if (err) throw err;
                              con.query("Update tuesday set `9:30` = 0 where username = ?",[req.body.username], function (err, results) {
                                if (err) throw err;
                                res.status(200)
                              });
                            });   
                          })
                          router.route('/tue1000off').post(function(req, res) {
                            con.connect(function(err) {
                                //if (err) throw err;
                                con.query("Update tuesday set `10:00` = 0 where username = ?",[req.body.username], function (err, results) {
                                  if (err) throw err;
                                  res.status(200)
                                });
                              });   
                            })
                            router.route('/tue1030off').post(function(req, res) {
                              con.connect(function(err) {
                                  //if (err) throw err;
                                  con.query("Update tuesday set `10:30` = 0 where username = ?",[req.body.username], function (err, results) {
                                    if (err) throw err;
                                    res.status(200)
                                  });
                                });   
                              })
                              router.route('/tue1100off').post(function(req, res) {
                                con.connect(function(err) {
                                    //if (err) throw err;
                                    con.query("Update tuesday set `11:00` = 0 where username = ?",[req.body.username], function (err, results) {
                                      if (err) throw err;
                                      res.status(200)
                                    });
                                  });   
                                })
                                router.route('/tue1130off').post(function(req, res) {
                                  con.connect(function(err) {
                                      //if (err) throw err;
                                      con.query("Update tuesday set `11:30` = 0 where username = ?",[req.body.username], function (err, results) {
                                        if (err) throw err;
                                        res.status(200)
                                      });
                                    });   
                                  })
                                  router.route('/tue1200off').post(function(req, res) {
                                    con.connect(function(err) {
                                        //if (err) throw err;
                                        con.query("Update tuesday set `12:00` = 0 where username = ?",[req.body.username], function (err, results) {
                                          if (err) throw err;
                                          res.status(200)
                                        });
                                      });   
                                    })
                                    router.route('/tue1230off').post(function(req, res) {
                                      con.connect(function(err) {
                                          //if (err) throw err;
                                          con.query("Update tuesday set `12:30` = 0 where username = ?",[req.body.username], function (err, results) {
                                            if (err) throw err;
                                            res.status(200)
                                          });
                                        });   
                                      })
                                      router.route('/tue1300off').post(function(req, res) {
                                        con.connect(function(err) {
                                            //if (err) throw err;
                                            con.query("Update tuesday set `13:00` = 0 where username = ?",[req.body.username], function (err, results) {
                                              if (err) throw err;
                                              res.status(200)
                                            });
                                          });   
                                        })
                                        router.route('/tue1330off').post(function(req, res) {
                                          con.connect(function(err) {
                                              //if (err) throw err;
                                              con.query("Update tuesday set `13:30` = 0 where username = ?",[req.body.username], function (err, results) {
                                                if (err) throw err;
                                                res.status(200)
                                              });
                                            });   
                                          })
                                          router.route('/tue1400off').post(function(req, res) {
                                            con.connect(function(err) {
                                                //if (err) throw err;
                                                con.query("Update tuesday set `14:00` = 0 where username = ?",[req.body.username], function (err, results) {
                                                  if (err) throw err;
                                                  res.status(200)
                                                });
                                              });   
                                            })
                                            router.route('/tue1430off').post(function(req, res) {
                                              con.connect(function(err) {
                                                  //if (err) throw err;
                                                  con.query("Update tuesday set `14:30` = 0 where username = ?",[req.body.username], function (err, results) {
                                                    if (err) throw err;
                                                    res.status(200)
                                                  });
                                                });   
                                              })
                                            router.route('/tue1500off').post(function(req, res) {
                                              con.connect(function(err) {
                                                  //if (err) throw err;
                                                  con.query("Update tuesday set `15:00` = 0 where username = ?",[req.body.username], function (err, results) {
                                                    if (err) throw err;
                                                    res.status(200)
                                                  });
                                                });   
                                              })
                                              router.route('/tue1530off').post(function(req, res) {
                                                con.connect(function(err) {
                                                    //if (err) throw err;
                                                    con.query("Update tuesday set `15:30` = 0 where username = ?",[req.body.username], function (err, results) {
                                                      if (err) throw err;
                                                      res.status(200)
                                                    });
                                                  });   
                                                })
                                                router.route('/tue1600off').post(function(req, res) {
                                                  con.connect(function(err) {
                                                      //if (err) throw err;
                                                      con.query("Update tuesday set `16:00` = 0 where username = ?",[req.body.username], function (err, results) {
                                                        if (err) throw err;
                                                        res.status(200)
                                                      });
                                                    });   
                                                  })
                                                  router.route('/tue1630off').post(function(req, res) {
                                                    con.connect(function(err) {
                                                        //if (err) throw err;
                                                        con.query("Update tuesday set `16:30` = 0 where username = ?",[req.body.username], function (err, results) {
                                                          if (err) throw err;
                                                          res.status(200)
                                                        });
                                                      });   
                                                    })
                                                    router.route('/tue1700off').post(function(req, res) {
                                                      con.connect(function(err) {
                                                          //if (err) throw err;
                                                          con.query("Update tuesday set `17:00` = 0 where username = ?",[req.body.username], function (err, results) {
                                                            if (err) throw err;
                                                            res.status(200)
                                                          });
                                                        });   
                                                      })
                                                      router.route('/tue1730off').post(function(req, res) {
                                                        con.connect(function(err) {
                                                            //if (err) throw err;
                                                            con.query("Update tuesday set `17:30` = 0 where username = ?",[req.body.username], function (err, results) {
                                                              if (err) throw err;
                                                              res.status(200)
                                                            });
                                                          });   
                                                        })
                                                        router.route('/tue1800off').post(function(req, res) {
                                                          con.connect(function(err) {
                                                              //if (err) throw err;
                                                              con.query("Update tuesday set `18:00` = 0 where username = ?",[req.body.username], function (err, results) {
                                                                if (err) throw err;
                                                                res.status(200)
                                                              });
                                                            });   
                                                          })
                                                          router.route('/tue1830off').post(function(req, res) {
                                                            con.connect(function(err) {
                                                                //if (err) throw err;
                                                                con.query("Update tuesday set `18:30` = 0 where username = ?",[req.body.username], function (err, results) {
                                                                  if (err) throw err;
                                                                  res.status(200)
                                                                });
                                                              });   
                                                            })
                                                            router.route('/tue1900off').post(function(req, res) {
                                                              con.connect(function(err) {
                                                                  //if (err) throw err;
                                                                  con.query("Update tuesday set `19:00` = 0 where username = ?",[req.body.username], function (err, results) {
                                                                    if (err) throw err;
                                                                    res.status(200)
                                                                  });
                                                                });   
                                                              })
                                                              router.route('/tue1930off').post(function(req, res) {
                                                                con.connect(function(err) {
                                                                    //if (err) throw err;
                                                                    con.query("Update tuesday set `19:30` = 0 where username = ?",[req.body.username], function (err, results) {
                                                                      if (err) throw err;
                                                                      res.status(200)
                                                                    });
                                                                  });   
                                                                })
                                                                router.route('/tue2000off').post(function(req, res) {
                                                                  con.connect(function(err) {
                                                                      //if (err) throw err;
                                                                      con.query("Update tuesday set `20:00` = 0 where username = ?",[req.body.username], function (err, results) {
                                                                        if (err) throw err;
                                                                        res.status(200)
                                                                      });
                                                                    });   
                                                                  })
              
               router.route('/wed800on').post(function(req, res) {
                    con.connect(function(err) {
                        //if (err) throw err;
                        con.query("Update wednesday set `8:00` = 1 where username = ?",[req.body.username], function (err, results) {
                          if (err) throw err;
                          res.status(200)
                        });
                      });   
                    })

                    router.route('/wed830on').post(function(req, res) {
                      con.connect(function(err) {
                          //if (err) throw err;
                          con.query("Update wednesday set `8:30` = 1 where username = ?",[req.body.username], function (err, results) {
                            if (err) throw err;
                            res.status(200)
                          });
                        });   
                      })
                      router.route('/wed900on').post(function(req, res) {
                        con.connect(function(err) {
                            //if (err) throw err;
                            con.query("Update wednesday set `9:00` = 1 where username = ?",[req.body.username], function (err, results) {
                              if (err) throw err;
                              res.status(200)
                            });
                          });   
                        })
                        router.route('/wed930on').post(function(req, res) {
                          con.connect(function(err) {
                              //if (err) throw err;
                              con.query("Update wednesday set `9:30` = 1 where username = ?",[req.body.username], function (err, results) {
                                if (err) throw err;
                                res.status(200)
                              });
                            });   
                          })
                          router.route('/wed1000on').post(function(req, res) {
                            con.connect(function(err) {
                                //if (err) throw err;
                                con.query("Update wednesday set `10:00` = 1 where username = ?",[req.body.username], function (err, results) {
                                  if (err) throw err;
                                  res.status(200)
                                });
                              });   
                            })
                            router.route('/wed1030on').post(function(req, res) {
                              con.connect(function(err) {
                                  //if (err) throw err;
                                  con.query("Update wednesday set `10:30` = 1 where username = ?",[req.body.username], function (err, results) {
                                    if (err) throw err;
                                    res.status(200)
                                  });
                                });   
                              })
                              router.route('/wed1100on').post(function(req, res) {
                                con.connect(function(err) {
                                    //if (err) throw err;
                                    con.query("Update wednesday set `11:00` = 1 where username = ?",[req.body.username], function (err, results) {
                                      if (err) throw err;
                                      res.status(200)
                                    });
                                  });   
                                })
                                router.route('/wed1130on').post(function(req, res) {
                                  con.connect(function(err) {
                                      //if (err) throw err;
                                      con.query("Update wednesday set `11:30` = 1 where username = ?",[req.body.username], function (err, results) {
                                        if (err) throw err;
                                        res.status(200)
                                      });
                                    });   
                                  })
                                  router.route('/wed1200on').post(function(req, res) {
                                    con.connect(function(err) {
                                        //if (err) throw err;
                                        con.query("Update wednesday set `12:00` = 1 where username = ?",[req.body.username], function (err, results) {
                                          if (err) throw err;
                                          res.status(200)
                                        });
                                      });   
                                    })
                                    router.route('/wed1230on').post(function(req, res) {
                                      con.connect(function(err) {
                                          //if (err) throw err;
                                          con.query("Update wednesday set `12:30` = 1 where username = ?",[req.body.username], function (err, results) {
                                            if (err) throw err;
                                            res.status(200)
                                          });
                                        });   
                                      })
                                      router.route('/wed1300on').post(function(req, res) {
                                        con.connect(function(err) {
                                            //if (err) throw err;
                                            con.query("Update wednesday set `13:00` = 1 where username = ?",[req.body.username], function (err, results) {
                                              if (err) throw err;
                                              res.status(200)
                                            });
                                          });   
                                        })
                                        router.route('/wed1330on').post(function(req, res) {
                                          con.connect(function(err) {
                                              //if (err) throw err;
                                              con.query("Update wednesday set `13:30` = 1 where username = ?",[req.body.username], function (err, results) {
                                                if (err) throw err;
                                                res.status(200)
                                              });
                                            });   
                                          })
                                          router.route('/wed1400on').post(function(req, res) {
                                            con.connect(function(err) {
                                                //if (err) throw err;
                                                con.query("Update wednesday set `14:00` = 1 where username = ?",[req.body.username], function (err, results) {
                                                  if (err) throw err;
                                                  res.status(200)
                                                });
                                              });   
                                            })
                                            router.route('/wed1430on').post(function(req, res) {
                                              con.connect(function(err) {
                                                  //if (err) throw err;
                                                  con.query("Update wednesday set `14:30` = 1 where username = ?",[req.body.username], function (err, results) {
                                                    if (err) throw err;
                                                    res.status(200)
                                                  });
                                                });   
                                              })
                                            router.route('/wed1500on').post(function(req, res) {
                                              con.connect(function(err) {
                                                  //if (err) throw err;
                                                  con.query("Update wednesday set `15:00` = 1 where username = ?",[req.body.username], function (err, results) {
                                                    if (err) throw err;
                                                    res.status(200)
                                                  });
                                                });   
                                              })
                                              router.route('/wed1530on').post(function(req, res) {
                                                con.connect(function(err) {
                                                    //if (err) throw err;
                                                    con.query("Update wednesday set `15:30` = 1 where username = ?",[req.body.username], function (err, results) {
                                                      if (err) throw err;
                                                      res.status(200)
                                                    });
                                                  });   
                                                })
                                                router.route('/wed1600on').post(function(req, res) {
                                                  con.connect(function(err) {
                                                      //if (err) throw err;
                                                      con.query("Update wednesday set `16:00` = 1 where username = ?",[req.body.username], function (err, results) {
                                                        if (err) throw err;
                                                        res.status(200)
                                                      });
                                                    });   
                                                  })
                                                  router.route('/wed1630on').post(function(req, res) {
                                                    con.connect(function(err) {
                                                        //if (err) throw err;
                                                        con.query("Update wednesday set `16:30` = 1 where username = ?",[req.body.username], function (err, results) {
                                                          if (err) throw err;
                                                          res.status(200)
                                                        });
                                                      });   
                                                    })
                                                    router.route('/wed1700on').post(function(req, res) {
                                                      con.connect(function(err) {
                                                          //if (err) throw err;
                                                          con.query("Update wednesday set `17:00` = 1 where username = ?",[req.body.username], function (err, results) {
                                                            if (err) throw err;
                                                            res.status(200)
                                                          });
                                                        });   
                                                      })
                                                      router.route('/wed1730on').post(function(req, res) {
                                                        con.connect(function(err) {
                                                            //if (err) throw err;
                                                            con.query("Update wednesday set `17:30` = 1 where username = ?",[req.body.username], function (err, results) {
                                                              if (err) throw err;
                                                              res.status(200)
                                                            });
                                                          });   
                                                        })
                                                        router.route('/wed1800on').post(function(req, res) {
                                                          con.connect(function(err) {
                                                              //if (err) throw err;
                                                              con.query("Update wednesday set `18:00` = 1 where username = ?",[req.body.username], function (err, results) {
                                                                if (err) throw err;
                                                                res.status(200)
                                                              });
                                                            });   
                                                          })
                                                          router.route('/wed1830on').post(function(req, res) {
                                                            con.connect(function(err) {
                                                                //if (err) throw err;
                                                                con.query("Update wednesday set `18:30` = 1 where username = ?",[req.body.username], function (err, results) {
                                                                  if (err) throw err;
                                                                  res.status(200)
                                                                });
                                                              });   
                                                            })
                                                            router.route('/wed1900on').post(function(req, res) {
                                                              con.connect(function(err) {
                                                                  //if (err) throw err;
                                                                  con.query("Update wednesday set `19:00` = 1 where username = ?",[req.body.username], function (err, results) {
                                                                    if (err) throw err;
                                                                    res.status(200)
                                                                  });
                                                                });   
                                                              })
                                                              router.route('/wed1930on').post(function(req, res) {
                                                                con.connect(function(err) {
                                                                    //if (err) throw err;
                                                                    con.query("Update wednesday set `19:30` = 1 where username = ?",[req.body.username], function (err, results) {
                                                                      if (err) throw err;
                                                                      res.status(200)
                                                                    });
                                                                  });   
                                                                })
                                                                router.route('/wed2000on').post(function(req, res) {
                                                                  con.connect(function(err) {
                                                                      //if (err) throw err;
                                                                      con.query("Update wednesday set `20:00` = 1 where username = ?",[req.body.username], function (err, results) {
                                                                        if (err) throw err;
                                                                        res.status(200)
                                                                      });
                                                                    });   
                                                                  })
              
               
                  router.route('/wed800off').post(function(req, res) {
                    con.connect(function(err) {
                        //if (err) throw err;
                        con.query("Update wednesday set `8:00` = 0 where username = ?",[req.body.username], function (err, results) {
                          if (err) throw err;
                          res.status(200)
                        });
                      });   
                    })

                    router.route('/wed830off').post(function(req, res) {
                      con.connect(function(err) {
                          //if (err) throw err;
                          con.query("Update wednesday set `8:30` = 0 where username = ?",[req.body.username], function (err, results) {
                            if (err) throw err;
                            res.status(200)
                          });
                        });   
                      })
                      router.route('/wed900off').post(function(req, res) {
                        con.connect(function(err) {
                            //if (err) throw err;
                            con.query("Update wednesday set `9:00` = 0 where username = ?",[req.body.username], function (err, results) {
                              if (err) throw err;
                              res.status(200)
                            });
                          });   
                        })
                        router.route('/wed930off').post(function(req, res) {
                          con.connect(function(err) {
                              //if (err) throw err;
                              con.query("Update wednesday set `9:30` = 0 where username = ?",[req.body.username], function (err, results) {
                                if (err) throw err;
                                res.status(200)
                              });
                            });   
                          })
                          router.route('/wed1000off').post(function(req, res) {
                            con.connect(function(err) {
                                //if (err) throw err;
                                con.query("Update wednesday set `10:00` = 0 where username = ?",[req.body.username], function (err, results) {
                                  if (err) throw err;
                                  res.status(200)
                                });
                              });   
                            })
                            router.route('/wed1030off').post(function(req, res) {
                              con.connect(function(err) {
                                  //if (err) throw err;
                                  con.query("Update wednesday set `10:30` = 0 where username = ?",[req.body.username], function (err, results) {
                                    if (err) throw err;
                                    res.status(200)
                                  });
                                });   
                              })
                              router.route('/wed1100off').post(function(req, res) {
                                con.connect(function(err) {
                                    //if (err) throw err;
                                    con.query("Update wednesday set `11:00` = 0 where username = ?",[req.body.username], function (err, results) {
                                      if (err) throw err;
                                      res.status(200)
                                    });
                                  });   
                                })
                                router.route('/wed1130off').post(function(req, res) {
                                  con.connect(function(err) {
                                      //if (err) throw err;
                                      con.query("Update wednesday set `11:30` = 0 where username = ?",[req.body.username], function (err, results) {
                                        if (err) throw err;
                                        res.status(200)
                                      });
                                    });   
                                  })
                                  router.route('/wed1200off').post(function(req, res) {
                                    con.connect(function(err) {
                                        //if (err) throw err;
                                        con.query("Update wednesday set `12:00` = 0 where username = ?",[req.body.username], function (err, results) {
                                          if (err) throw err;
                                          res.status(200)
                                        });
                                      });   
                                    })
                                    router.route('/wed1230off').post(function(req, res) {
                                      con.connect(function(err) {
                                          //if (err) throw err;
                                          con.query("Update wednesday set `12:30` = 0 where username = ?",[req.body.username], function (err, results) {
                                            if (err) throw err;
                                            res.status(200)
                                          });
                                        });   
                                      })
                                      router.route('/wed1300off').post(function(req, res) {
                                        con.connect(function(err) {
                                            //if (err) throw err;
                                            con.query("Update wednesday set `13:00` = 0 where username = ?",[req.body.username], function (err, results) {
                                              if (err) throw err;
                                              res.status(200)
                                            });
                                          });   
                                        })
                                        router.route('/wed1330off').post(function(req, res) {
                                          con.connect(function(err) {
                                              //if (err) throw err;
                                              con.query("Update wednesday set `13:30` = 0 where username = ?",[req.body.username], function (err, results) {
                                                if (err) throw err;
                                                res.status(200)
                                              });
                                            });   
                                          })
                                          router.route('/wed1400off').post(function(req, res) {
                                            con.connect(function(err) {
                                                //if (err) throw err;
                                                con.query("Update wednesday set `14:00` = 0 where username = ?",[req.body.username], function (err, results) {
                                                  if (err) throw err;
                                                  res.status(200)
                                                });
                                              });   
                                            })
                                            router.route('/wed1430off').post(function(req, res) {
                                              con.connect(function(err) {
                                                  //if (err) throw err;
                                                  con.query("Update wednesday set `14:30` = 0 where username = ?",[req.body.username], function (err, results) {
                                                    if (err) throw err;
                                                    res.status(200)
                                                  });
                                                });   
                                              })
                                            router.route('/wed1500off').post(function(req, res) {
                                              con.connect(function(err) {
                                                  //if (err) throw err;
                                                  con.query("Update wednesday set `15:00` = 0 where username = ?",[req.body.username], function (err, results) {
                                                    if (err) throw err;
                                                    res.status(200)
                                                  });
                                                });   
                                              })
                                              router.route('/wed1530off').post(function(req, res) {
                                                con.connect(function(err) {
                                                    //if (err) throw err;
                                                    con.query("Update wednesday set `15:30` = 0 where username = ?",[req.body.username], function (err, results) {
                                                      if (err) throw err;
                                                      res.status(200)
                                                    });
                                                  });   
                                                })
                                                router.route('/wed1600off').post(function(req, res) {
                                                  con.connect(function(err) {
                                                      //if (err) throw err;
                                                      con.query("Update wednesday set `16:00` = 0 where username = ?",[req.body.username], function (err, results) {
                                                        if (err) throw err;
                                                        res.status(200)
                                                      });
                                                    });   
                                                  })
                                                  router.route('/wed1630off').post(function(req, res) {
                                                    con.connect(function(err) {
                                                        //if (err) throw err;
                                                        con.query("Update wednesday set `16:30` = 0 where username = ?",[req.body.username], function (err, results) {
                                                          if (err) throw err;
                                                          res.status(200)
                                                        });
                                                      });   
                                                    })
                                                    router.route('/wed1700off').post(function(req, res) {
                                                      con.connect(function(err) {
                                                          //if (err) throw err;
                                                          con.query("Update wednesday set `17:00` = 0 where username = ?",[req.body.username], function (err, results) {
                                                            if (err) throw err;
                                                            res.status(200)
                                                          });
                                                        });   
                                                      })
                                                      router.route('/wed1730off').post(function(req, res) {
                                                        con.connect(function(err) {
                                                            //if (err) throw err;
                                                            con.query("Update wednesday set `17:30` = 0 where username = ?",[req.body.username], function (err, results) {
                                                              if (err) throw err;
                                                              res.status(200)
                                                            });
                                                          });   
                                                        })
                                                        router.route('/wed1800off').post(function(req, res) {
                                                          con.connect(function(err) {
                                                              //if (err) throw err;
                                                              con.query("Update wednesday set `18:00` = 0 where username = ?",[req.body.username], function (err, results) {
                                                                if (err) throw err;
                                                                res.status(200)
                                                              });
                                                            });   
                                                          })
                                                          router.route('/wed1830off').post(function(req, res) {
                                                            con.connect(function(err) {
                                                                //if (err) throw err;
                                                                con.query("Update wednesday set `18:30` = 0 where username = ?",[req.body.username], function (err, results) {
                                                                  if (err) throw err;
                                                                  res.status(200)
                                                                });
                                                              });   
                                                            })
                                                            router.route('/wed1900off').post(function(req, res) {
                                                              con.connect(function(err) {
                                                                  //if (err) throw err;
                                                                  con.query("Update wednesday set `19:00` = 0 where username = ?",[req.body.username], function (err, results) {
                                                                    if (err) throw err;
                                                                    res.status(200)
                                                                  });
                                                                });   
                                                              })
                                                              router.route('/wed1930off').post(function(req, res) {
                                                                con.connect(function(err) {
                                                                    //if (err) throw err;
                                                                    con.query("Update wednesday set `19:30` = 0 where username = ?",[req.body.username], function (err, results) {
                                                                      if (err) throw err;
                                                                      res.status(200)
                                                                    });
                                                                  });   
                                                                })
                                                                router.route('/wed2000off').post(function(req, res) {
                                                                  con.connect(function(err) {
                                                                      //if (err) throw err;
                                                                      con.query("Update wednesday set `20:00` = 0 where username = ?",[req.body.username], function (err, results) {
                                                                        if (err) throw err;
                                                                        res.status(200)
                                                                      });
                                                                    });   
                                                                  })               
              
               
               router.route('/thu800on').post(function(req, res) {
                    con.connect(function(err) {
                        //if (err) throw err;
                        con.query("Update thursday set `8:00` = 1 where username = ?",[req.body.username], function (err, results) {
                          if (err) throw err;
                          res.status(200)
                        });
                      });   
                    })

                    router.route('/thu830on').post(function(req, res) {
                      con.connect(function(err) {
                          //if (err) throw err;
                          con.query("Update thursday set `8:30` = 1 where username = ?",[req.body.username], function (err, results) {
                            if (err) throw err;
                            res.status(200)
                          });
                        });   
                      })
                      router.route('/thu900on').post(function(req, res) {
                        con.connect(function(err) {
                            //if (err) throw err;
                            con.query("Update thursday set `9:00` = 1 where username = ?",[req.body.username], function (err, results) {
                              if (err) throw err;
                              res.status(200)
                            });
                          });   
                        })
                        router.route('/thu930on').post(function(req, res) {
                          con.connect(function(err) {
                              //if (err) throw err;
                              con.query("Update thursday set `9:30` = 1 where username = ?",[req.body.username], function (err, results) {
                                if (err) throw err;
                                res.status(200)
                              });
                            });   
                          })
                          router.route('/thu1000on').post(function(req, res) {
                            con.connect(function(err) {
                                //if (err) throw err;
                                con.query("Update thursday set `10:00` = 1 where username = ?",[req.body.username], function (err, results) {
                                  if (err) throw err;
                                  res.status(200)
                                });
                              });   
                            })
                            router.route('/thu1030on').post(function(req, res) {
                              con.connect(function(err) {
                                  //if (err) throw err;
                                  con.query("Update thursday set `10:30` = 1 where username = ?",[req.body.username], function (err, results) {
                                    if (err) throw err;
                                    res.status(200)
                                  });
                                });   
                              })
                              router.route('/thu1100on').post(function(req, res) {
                                con.connect(function(err) {
                                    //if (err) throw err;
                                    con.query("Update thursday set `11:00` = 1 where username = ?",[req.body.username], function (err, results) {
                                      if (err) throw err;
                                      res.status(200)
                                    });
                                  });   
                                })
                                router.route('/thu1130on').post(function(req, res) {
                                  con.connect(function(err) {
                                      //if (err) throw err;
                                      con.query("Update thursday set `11:30` = 1 where username = ?",[req.body.username], function (err, results) {
                                        if (err) throw err;
                                        res.status(200)
                                      });
                                    });   
                                  })
                                  router.route('/thu1200on').post(function(req, res) {
                                    con.connect(function(err) {
                                        //if (err) throw err;
                                        con.query("Update thursday set `12:00` = 1 where username = ?",[req.body.username], function (err, results) {
                                          if (err) throw err;
                                          res.status(200)
                                        });
                                      });   
                                    })
                                    router.route('/thu1230on').post(function(req, res) {
                                      con.connect(function(err) {
                                          //if (err) throw err;
                                          con.query("Update thursday set `12:30` = 1 where username = ?",[req.body.username], function (err, results) {
                                            if (err) throw err;
                                            res.status(200)
                                          });
                                        });   
                                      })
                                      router.route('/thu1300on').post(function(req, res) {
                                        con.connect(function(err) {
                                            //if (err) throw err;
                                            con.query("Update thursday set `13:00` = 1 where username = ?",[req.body.username], function (err, results) {
                                              if (err) throw err;
                                              res.status(200)
                                            });
                                          });   
                                        })
                                        router.route('/thu1330on').post(function(req, res) {
                                          con.connect(function(err) {
                                              //if (err) throw err;
                                              con.query("Update thursday set `13:30` = 1 where username = ?",[req.body.username], function (err, results) {
                                                if (err) throw err;
                                                res.status(200)
                                              });
                                            });   
                                          })
                                          router.route('/thu1400on').post(function(req, res) {
                                            con.connect(function(err) {
                                                //if (err) throw err;
                                                con.query("Update thursday set `14:00` = 1 where username = ?",[req.body.username], function (err, results) {
                                                  if (err) throw err;
                                                  res.status(200)
                                                });
                                              });   
                                            })
                                            router.route('/thu1430on').post(function(req, res) {
                                              con.connect(function(err) {
                                                  //if (err) throw err;
                                                  con.query("Update thursday set `14:30` = 1 where username = ?",[req.body.username], function (err, results) {
                                                    if (err) throw err;
                                                    res.status(200)
                                                  });
                                                });   
                                              })
                                            router.route('/thu1500on').post(function(req, res) {
                                              con.connect(function(err) {
                                                  //if (err) throw err;
                                                  con.query("Update thursday set `15:00` = 1 where username = ?",[req.body.username], function (err, results) {
                                                    if (err) throw err;
                                                    res.status(200)
                                                  });
                                                });   
                                              })
                                              router.route('/thu1530on').post(function(req, res) {
                                                con.connect(function(err) {
                                                    //if (err) throw err;
                                                    con.query("Update thursday set `15:30` = 1 where username = ?",[req.body.username], function (err, results) {
                                                      if (err) throw err;
                                                      res.status(200)
                                                    });
                                                  });   
                                                })
                                                router.route('/thu1600on').post(function(req, res) {
                                                  con.connect(function(err) {
                                                      //if (err) throw err;
                                                      con.query("Update thursday set `16:00` = 1 where username = ?",[req.body.username], function (err, results) {
                                                        if (err) throw err;
                                                        res.status(200)
                                                      });
                                                    });   
                                                  })
                                                  router.route('/thu1630on').post(function(req, res) {
                                                    con.connect(function(err) {
                                                        //if (err) throw err;
                                                        con.query("Update thursday set `16:30` = 1 where username = ?",[req.body.username], function (err, results) {
                                                          if (err) throw err;
                                                          res.status(200)
                                                        });
                                                      });   
                                                    })
                                                    router.route('/thu1700on').post(function(req, res) {
                                                      con.connect(function(err) {
                                                          //if (err) throw err;
                                                          con.query("Update thursday set `17:00` = 1 where username = ?",[req.body.username], function (err, results) {
                                                            if (err) throw err;
                                                            res.status(200)
                                                          });
                                                        });   
                                                      })
                                                      router.route('/thu1730on').post(function(req, res) {
                                                        con.connect(function(err) {
                                                            //if (err) throw err;
                                                            con.query("Update thursday set `17:30` = 1 where username = ?",[req.body.username], function (err, results) {
                                                              if (err) throw err;
                                                              res.status(200)
                                                            });
                                                          });   
                                                        })
                                                        router.route('/thu1800on').post(function(req, res) {
                                                          con.connect(function(err) {
                                                              //if (err) throw err;
                                                              con.query("Update thursday set `18:00` = 1 where username = ?",[req.body.username], function (err, results) {
                                                                if (err) throw err;
                                                                res.status(200)
                                                              });
                                                            });   
                                                          })
                                                          router.route('/thu1830on').post(function(req, res) {
                                                            con.connect(function(err) {
                                                                //if (err) throw err;
                                                                con.query("Update thursday set `18:30` = 1 where username = ?",[req.body.username], function (err, results) {
                                                                  if (err) throw err;
                                                                  res.status(200)
                                                                });
                                                              });   
                                                            })
                                                            router.route('/thu1900on').post(function(req, res) {
                                                              con.connect(function(err) {
                                                                  //if (err) throw err;
                                                                  con.query("Update thursday set `19:00` = 1 where username = ?",[req.body.username], function (err, results) {
                                                                    if (err) throw err;
                                                                    res.status(200)
                                                                  });
                                                                });   
                                                              })
                                                              router.route('/thu1930on').post(function(req, res) {
                                                                con.connect(function(err) {
                                                                    //if (err) throw err;
                                                                    con.query("Update thursday set `19:30` = 1 where username = ?",[req.body.username], function (err, results) {
                                                                      if (err) throw err;
                                                                      res.status(200)
                                                                    });
                                                                  });   
                                                                })
                                                                router.route('/thu2000on').post(function(req, res) {
                                                                  con.connect(function(err) {
                                                                      //if (err) throw err;
                                                                      con.query("Update thursday set `20:00` = 1 where username = ?",[req.body.username], function (err, results) {
                                                                        if (err) throw err;
                                                                        res.status(200)
                                                                      });
                                                                    });   
                                                                  })
               
                  router.route('/thu800off').post(function(req, res) {
                    con.connect(function(err) {
                        //if (err) throw err;
                        con.query("Update thursday set `8:00` = 0 where username = ?",[req.body.username], function (err, results) {
                          if (err) throw err;
                          res.status(200)
                        });
                      });   
                    })

                    router.route('/thu830off').post(function(req, res) {
                      con.connect(function(err) {
                          //if (err) throw err;
                          con.query("Update thursday set `8:30` = 0 where username = ?",[req.body.username], function (err, results) {
                            if (err) throw err;
                            res.status(200)
                          });
                        });   
                      })
                      router.route('/thu900off').post(function(req, res) {
                        con.connect(function(err) {
                            //if (err) throw err;
                            con.query("Update thursday set `9:00` = 0 where username = ?",[req.body.username], function (err, results) {
                              if (err) throw err;
                              res.status(200)
                            });
                          });   
                        })
                        router.route('/thu930off').post(function(req, res) {
                          con.connect(function(err) {
                              //if (err) throw err;
                              con.query("Update thursday set `9:30` = 0 where username = ?",[req.body.username], function (err, results) {
                                if (err) throw err;
                                res.status(200)
                              });
                            });   
                          })
                          router.route('/thu1000off').post(function(req, res) {
                            con.connect(function(err) {
                                //if (err) throw err;
                                con.query("Update thursday set `10:00` = 0 where username = ?",[req.body.username], function (err, results) {
                                  if (err) throw err;
                                  res.status(200)
                                });
                              });   
                            })
                            router.route('/thu1030off').post(function(req, res) {
                              con.connect(function(err) {
                                  //if (err) throw err;
                                  con.query("Update thursday set `10:30` = 0 where username = ?",[req.body.username], function (err, results) {
                                    if (err) throw err;
                                    res.status(200)
                                  });
                                });   
                              })
                              router.route('/thu1100off').post(function(req, res) {
                                con.connect(function(err) {
                                    //if (err) throw err;
                                    con.query("Update thursday set `11:00` = 0 where username = ?",[req.body.username], function (err, results) {
                                      if (err) throw err;
                                      res.status(200)
                                    });
                                  });   
                                })
                                router.route('/thu1130off').post(function(req, res) {
                                  con.connect(function(err) {
                                      //if (err) throw err;
                                      con.query("Update thursday set `11:30` = 0 where username = ?",[req.body.username], function (err, results) {
                                        if (err) throw err;
                                        res.status(200)
                                      });
                                    });   
                                  })
                                  router.route('/thu1200off').post(function(req, res) {
                                    con.connect(function(err) {
                                        //if (err) throw err;
                                        con.query("Update thursday set `12:00` = 0 where username = ?",[req.body.username], function (err, results) {
                                          if (err) throw err;
                                          res.status(200)
                                        });
                                      });   
                                    })
                                    router.route('/thu1230off').post(function(req, res) {
                                      con.connect(function(err) {
                                          //if (err) throw err;
                                          con.query("Update thursday set `12:30` = 0 where username = ?",[req.body.username], function (err, results) {
                                            if (err) throw err;
                                            res.status(200)
                                          });
                                        });   
                                      })
                                      router.route('/thu1300off').post(function(req, res) {
                                        con.connect(function(err) {
                                            //if (err) throw err;
                                            con.query("Update thursday set `13:00` = 0 where username = ?",[req.body.username], function (err, results) {
                                              if (err) throw err;
                                              res.status(200)
                                            });
                                          });   
                                        })
                                        router.route('/thu1330off').post(function(req, res) {
                                          con.connect(function(err) {
                                              //if (err) throw err;
                                              con.query("Update thursday set `13:30` = 0 where username = ?",[req.body.username], function (err, results) {
                                                if (err) throw err;
                                                res.status(200)
                                              });
                                            });   
                                          })
                                          router.route('/thu1400off').post(function(req, res) {
                                            con.connect(function(err) {
                                                //if (err) throw err;
                                                con.query("Update thursday set `14:00` = 0 where username = ?",[req.body.username], function (err, results) {
                                                  if (err) throw err;
                                                  res.status(200)
                                                });
                                              });   
                                            })
                                            router.route('/thu1430off').post(function(req, res) {
                                              con.connect(function(err) {
                                                  //if (err) throw err;
                                                  con.query("Update thursday set `14:30` = 0 where username = ?",[req.body.username], function (err, results) {
                                                    if (err) throw err;
                                                    res.status(200)
                                                  });
                                                });   
                                              })
                                            router.route('/thu1500off').post(function(req, res) {
                                              con.connect(function(err) {
                                                  //if (err) throw err;
                                                  con.query("Update thursday set `15:00` = 0 where username = ?",[req.body.username], function (err, results) {
                                                    if (err) throw err;
                                                    res.status(200)
                                                  });
                                                });   
                                              })
                                              router.route('/thu1530off').post(function(req, res) {
                                                con.connect(function(err) {
                                                    //if (err) throw err;
                                                    con.query("Update thursday set `15:30` = 0 where username = ?",[req.body.username], function (err, results) {
                                                      if (err) throw err;
                                                      res.status(200)
                                                    });
                                                  });   
                                                })
                                                router.route('/thu1600off').post(function(req, res) {
                                                  con.connect(function(err) {
                                                      //if (err) throw err;
                                                      con.query("Update thursday set `16:00` = 0 where username = ?",[req.body.username], function (err, results) {
                                                        if (err) throw err;
                                                        res.status(200)
                                                      });
                                                    });   
                                                  })
                                                  router.route('/thu1630off').post(function(req, res) {
                                                    con.connect(function(err) {
                                                        //if (err) throw err;
                                                        con.query("Update thursday set `16:30` = 0 where username = ?",[req.body.username], function (err, results) {
                                                          if (err) throw err;
                                                          res.status(200)
                                                        });
                                                      });   
                                                    })
                                                    router.route('/thu1700off').post(function(req, res) {
                                                      con.connect(function(err) {
                                                          //if (err) throw err;
                                                          con.query("Update thursday set `17:00` = 0 where username = ?",[req.body.username], function (err, results) {
                                                            if (err) throw err;
                                                            res.status(200)
                                                          });
                                                        });   
                                                      })
                                                      router.route('/thu1730off').post(function(req, res) {
                                                        con.connect(function(err) {
                                                            //if (err) throw err;
                                                            con.query("Update thursday set `17:30` = 0 where username = ?",[req.body.username], function (err, results) {
                                                              if (err) throw err;
                                                              res.status(200)
                                                            });
                                                          });   
                                                        })
                                                        router.route('/thu1800off').post(function(req, res) {
                                                          con.connect(function(err) {
                                                              //if (err) throw err;
                                                              con.query("Update thursday set `18:00` = 0 where username = ?",[req.body.username], function (err, results) {
                                                                if (err) throw err;
                                                                res.status(200)
                                                              });
                                                            });   
                                                          })
                                                          router.route('/thu1830off').post(function(req, res) {
                                                            con.connect(function(err) {
                                                                //if (err) throw err;
                                                                con.query("Update thursday set `18:30` = 0 where username = ?",[req.body.username], function (err, results) {
                                                                  if (err) throw err;
                                                                  res.status(200)
                                                                });
                                                              });   
                                                            })
                                                            router.route('/thu1900off').post(function(req, res) {
                                                              con.connect(function(err) {
                                                                  //if (err) throw err;
                                                                  con.query("Update thursday set `19:00` = 0 where username = ?",[req.body.username], function (err, results) {
                                                                    if (err) throw err;
                                                                    res.status(200)
                                                                  });
                                                                });   
                                                              })
                                                              router.route('/thu1930off').post(function(req, res) {
                                                                con.connect(function(err) {
                                                                    //if (err) throw err;
                                                                    con.query("Update thursday set `19:30` = 0 where username = ?",[req.body.username], function (err, results) {
                                                                      if (err) throw err;
                                                                      res.status(200)
                                                                    });
                                                                  });   
                                                                })
                                                                router.route('/thu2000off').post(function(req, res) {
                                                                  con.connect(function(err) {
                                                                      //if (err) throw err;
                                                                      con.query("Update thursday set `20:00` = 0 where username = ?",[req.body.username], function (err, results) {
                                                                        if (err) throw err;
                                                                        res.status(200)
                                                                      });
                                                                    });   
                                                                  })     
               
               router.route('/fri800on').post(function(req, res) {
                    con.connect(function(err) {
                        //if (err) throw err;
                        con.query("Update friday set `8:00` = 1 where username = ?",[req.body.username], function (err, results) {
                          if (err) throw err;
                          res.status(200)
                        });
                      });   
                    })

                    router.route('/fri830on').post(function(req, res) {
                      con.connect(function(err) {
                          //if (err) throw err;
                          con.query("Update friday set `8:30` = 1 where username = ?",[req.body.username], function (err, results) {
                            if (err) throw err;
                            res.status(200)
                          });
                        });   
                      })
                      router.route('/fri900on').post(function(req, res) {
                        con.connect(function(err) {
                            //if (err) throw err;
                            con.query("Update friday set `9:00` = 1 where username = ?",[req.body.username], function (err, results) {
                              if (err) throw err;
                              res.status(200)
                            });
                          });   
                        })
                        router.route('/fri930on').post(function(req, res) {
                          con.connect(function(err) {
                              //if (err) throw err;
                              con.query("Update friday set `9:30` = 1 where username = ?",[req.body.username], function (err, results) {
                                if (err) throw err;
                                res.status(200)
                              });
                            });   
                          })
                          router.route('/fri1000on').post(function(req, res) {
                            con.connect(function(err) {
                                //if (err) throw err;
                                con.query("Update friday set `10:00` = 1 where username = ?",[req.body.username], function (err, results) {
                                  if (err) throw err;
                                  res.status(200)
                                });
                              });   
                            })
                            router.route('/fri1030on').post(function(req, res) {
                              con.connect(function(err) {
                                  //if (err) throw err;
                                  con.query("Update friday set `10:30` = 1 where username = ?",[req.body.username], function (err, results) {
                                    if (err) throw err;
                                    res.status(200)
                                  });
                                });   
                              })
                              router.route('/fri1100on').post(function(req, res) {
                                con.connect(function(err) {
                                    //if (err) throw err;
                                    con.query("Update friday set `11:00` = 1 where username = ?",[req.body.username], function (err, results) {
                                      if (err) throw err;
                                      res.status(200)
                                    });
                                  });   
                                })
                                router.route('/fri1130on').post(function(req, res) {
                                  con.connect(function(err) {
                                      //if (err) throw err;
                                      con.query("Update friday set `11:30` = 1 where username = ?",[req.body.username], function (err, results) {
                                        if (err) throw err;
                                        res.status(200)
                                      });
                                    });   
                                  })
                                  router.route('/fri1200on').post(function(req, res) {
                                    con.connect(function(err) {
                                        //if (err) throw err;
                                        con.query("Update friday set `12:00` = 1 where username = ?",[req.body.username], function (err, results) {
                                          if (err) throw err;
                                          res.status(200)
                                        });
                                      });   
                                    })
                                    router.route('/fri1230on').post(function(req, res) {
                                      con.connect(function(err) {
                                          //if (err) throw err;
                                          con.query("Update friday set `12:30` = 1 where username = ?",[req.body.username], function (err, results) {
                                            if (err) throw err;
                                            res.status(200)
                                          });
                                        });   
                                      })
                                      router.route('/fri1300on').post(function(req, res) {
                                        con.connect(function(err) {
                                            //if (err) throw err;
                                            con.query("Update friday set `13:00` = 1 where username = ?",[req.body.username], function (err, results) {
                                              if (err) throw err;
                                              res.status(200)
                                            });
                                          });   
                                        })
                                        router.route('/fri1330on').post(function(req, res) {
                                          con.connect(function(err) {
                                              //if (err) throw err;
                                              con.query("Update friday set `13:30` = 1 where username = ?",[req.body.username], function (err, results) {
                                                if (err) throw err;
                                                res.status(200)
                                              });
                                            });   
                                          })
                                          router.route('/fri1400on').post(function(req, res) {
                                            con.connect(function(err) {
                                                //if (err) throw err;
                                                con.query("Update friday set `14:00` = 1 where username = ?",[req.body.username], function (err, results) {
                                                  if (err) throw err;
                                                  res.status(200)
                                                });
                                              });   
                                            })
                                            router.route('/fri1430on').post(function(req, res) {
                                              con.connect(function(err) {
                                                  //if (err) throw err;
                                                  con.query("Update friday set `14:30` = 1 where username = ?",[req.body.username], function (err, results) {
                                                    if (err) throw err;
                                                    res.status(200)
                                                  });
                                                });   
                                              })
                                            router.route('/fri1500on').post(function(req, res) {
                                              con.connect(function(err) {
                                                  //if (err) throw err;
                                                  con.query("Update friday set `15:00` = 1 where username = ?",[req.body.username], function (err, results) {
                                                    if (err) throw err;
                                                    res.status(200)
                                                  });
                                                });   
                                              })
                                              router.route('/fri1530on').post(function(req, res) {
                                                con.connect(function(err) {
                                                    //if (err) throw err;
                                                    con.query("Update friday set `15:30` = 1 where username = ?",[req.body.username], function (err, results) {
                                                      if (err) throw err;
                                                      res.status(200)
                                                    });
                                                  });   
                                                })
                                                router.route('/fri1600on').post(function(req, res) {
                                                  con.connect(function(err) {
                                                      //if (err) throw err;
                                                      con.query("Update friday set `16:00` = 1 where username = ?",[req.body.username], function (err, results) {
                                                        if (err) throw err;
                                                        res.status(200)
                                                      });
                                                    });   
                                                  })
                                                  router.route('/fri1630on').post(function(req, res) {
                                                    con.connect(function(err) {
                                                        //if (err) throw err;
                                                        con.query("Update friday set `16:30` = 1 where username = ?",[req.body.username], function (err, results) {
                                                          if (err) throw err;
                                                          res.status(200)
                                                        });
                                                      });   
                                                    })
                                                    router.route('/fri1700on').post(function(req, res) {
                                                      con.connect(function(err) {
                                                          //if (err) throw err;
                                                          con.query("Update friday set `17:00` = 1 where username = ?",[req.body.username], function (err, results) {
                                                            if (err) throw err;
                                                            res.status(200)
                                                          });
                                                        });   
                                                      })
                                                      router.route('/fri1730on').post(function(req, res) {
                                                        con.connect(function(err) {
                                                            //if (err) throw err;
                                                            con.query("Update friday set `17:30` = 1 where username = ?",[req.body.username], function (err, results) {
                                                              if (err) throw err;
                                                              res.status(200)
                                                            });
                                                          });   
                                                        })
                                                        router.route('/fri1800on').post(function(req, res) {
                                                          con.connect(function(err) {
                                                              //if (err) throw err;
                                                              con.query("Update friday set `18:00` = 1 where username = ?",[req.body.username], function (err, results) {
                                                                if (err) throw err;
                                                                res.status(200)
                                                              });
                                                            });   
                                                          })
                                                          router.route('/fri1830on').post(function(req, res) {
                                                            con.connect(function(err) {
                                                                //if (err) throw err;
                                                                con.query("Update friday set `18:30` = 1 where username = ?",[req.body.username], function (err, results) {
                                                                  if (err) throw err;
                                                                  res.status(200)
                                                                });
                                                              });   
                                                            })
                                                            router.route('/fri1900on').post(function(req, res) {
                                                              con.connect(function(err) {
                                                                  //if (err) throw err;
                                                                  con.query("Update friday set `19:00` = 1 where username = ?",[req.body.username], function (err, results) {
                                                                    if (err) throw err;
                                                                    res.status(200)
                                                                  });
                                                                });   
                                                              })
                                                              router.route('/fri1930on').post(function(req, res) {
                                                                con.connect(function(err) {
                                                                    //if (err) throw err;
                                                                    con.query("Update friday set `19:30` = 1 where username = ?",[req.body.username], function (err, results) {
                                                                      if (err) throw err;
                                                                      res.status(200)
                                                                    });
                                                                  });   
                                                                })
                                                                router.route('/fri2000on').post(function(req, res) {
                                                                  con.connect(function(err) {
                                                                      //if (err) throw err;
                                                                      con.query("Update friday set `20:00` = 1 where username = ?",[req.body.username], function (err, results) {
                                                                        if (err) throw err;
                                                                        res.status(200)
                                                                      });
                                                                    });   
                                                                  })                                           
              
                  router.route('/fri800off').post(function(req, res) {
                    con.connect(function(err) {
                        //if (err) throw err;
                        con.query("Update friday set `8:00` = 0 where username = ?",[req.body.username], function (err, results) {
                          if (err) throw err;
                          res.status(200)
                        });
                      });   
                    })

                    router.route('/fri830off').post(function(req, res) {
                      con.connect(function(err) {
                          //if (err) throw err;
                          con.query("Update friday set `8:30` = 0 where username = ?",[req.body.username], function (err, results) {
                            if (err) throw err;
                            res.status(200)
                          });
                        });   
                      })
                      router.route('/fri900off').post(function(req, res) {
                        con.connect(function(err) {
                            //if (err) throw err;
                            con.query("Update friday set `9:00` = 0 where username = ?",[req.body.username], function (err, results) {
                              if (err) throw err;
                              res.status(200)
                            });
                          });   
                        })
                        router.route('/fri930off').post(function(req, res) {
                          con.connect(function(err) {
                              //if (err) throw err;
                              con.query("Update friday set `9:30` = 0 where username = ?",[req.body.username], function (err, results) {
                                if (err) throw err;
                                res.status(200)
                              });
                            });   
                          })
                          router.route('/fri1000off').post(function(req, res) {
                            con.connect(function(err) {
                                //if (err) throw err;
                                con.query("Update friday set `10:00` = 0 where username = ?",[req.body.username], function (err, results) {
                                  if (err) throw err;
                                  res.status(200)
                                });
                              });   
                            })
                            router.route('/fri1030off').post(function(req, res) {
                              con.connect(function(err) {
                                  //if (err) throw err;
                                  con.query("Update friday set `10:30` = 0 where username = ?",[req.body.username], function (err, results) {
                                    if (err) throw err;
                                    res.status(200)
                                  });
                                });   
                              })
                              router.route('/fri1100off').post(function(req, res) {
                                con.connect(function(err) {
                                    //if (err) throw err;
                                    con.query("Update friday set `11:00` = 0 where username = ?",[req.body.username], function (err, results) {
                                      if (err) throw err;
                                      res.status(200)
                                    });
                                  });   
                                })
                                router.route('/fri1130off').post(function(req, res) {
                                  con.connect(function(err) {
                                      //if (err) throw err;
                                      con.query("Update friday set `11:30` = 0 where username = ?",[req.body.username], function (err, results) {
                                        if (err) throw err;
                                        res.status(200)
                                      });
                                    });   
                                  })
                                  router.route('/fri1200off').post(function(req, res) {
                                    con.connect(function(err) {
                                        //if (err) throw err;
                                        con.query("Update friday set `12:00` = 0 where username = ?",[req.body.username], function (err, results) {
                                          if (err) throw err;
                                          res.status(200)
                                        });
                                      });   
                                    })
                                    router.route('/fri1230off').post(function(req, res) {
                                      con.connect(function(err) {
                                          //if (err) throw err;
                                          con.query("Update friday set `12:30` = 0 where username = ?",[req.body.username], function (err, results) {
                                            if (err) throw err;
                                            res.status(200)
                                          });
                                        });   
                                      })
                                      router.route('/fri1300off').post(function(req, res) {
                                        con.connect(function(err) {
                                            //if (err) throw err;
                                            con.query("Update friday set `13:00` = 0 where username = ?",[req.body.username], function (err, results) {
                                              if (err) throw err;
                                              res.status(200)
                                            });
                                          });   
                                        })
                                        router.route('/fri1330off').post(function(req, res) {
                                          con.connect(function(err) {
                                              //if (err) throw err;
                                              con.query("Update friday set `13:30` = 0 where username = ?",[req.body.username], function (err, results) {
                                                if (err) throw err;
                                                res.status(200)
                                              });
                                            });   
                                          })
                                          router.route('/fri1400off').post(function(req, res) {
                                            con.connect(function(err) {
                                                //if (err) throw err;
                                                con.query("Update friday set `14:00` = 0 where username = ?",[req.body.username], function (err, results) {
                                                  if (err) throw err;
                                                  res.status(200)
                                                });
                                              });   
                                            })
                                            router.route('/fri1430off').post(function(req, res) {
                                              con.connect(function(err) {
                                                  //if (err) throw err;
                                                  con.query("Update friday set `14:30` = 0 where username = ?",[req.body.username], function (err, results) {
                                                    if (err) throw err;
                                                    res.status(200)
                                                  });
                                                });   
                                              })
                                            router.route('/fri1500off').post(function(req, res) {
                                              con.connect(function(err) {
                                                  //if (err) throw err;
                                                  con.query("Update friday set `15:00` = 0 where username = ?",[req.body.username], function (err, results) {
                                                    if (err) throw err;
                                                    res.status(200)
                                                  });
                                                });   
                                              })
                                              router.route('/fri1530off').post(function(req, res) {
                                                con.connect(function(err) {
                                                    //if (err) throw err;
                                                    con.query("Update friday set `15:30` = 0 where username = ?",[req.body.username], function (err, results) {
                                                      if (err) throw err;
                                                      res.status(200)
                                                    });
                                                  });   
                                                })
                                                router.route('/fri1600off').post(function(req, res) {
                                                  con.connect(function(err) {
                                                      //if (err) throw err;
                                                      con.query("Update friday set `16:00` = 0 where username = ?",[req.body.username], function (err, results) {
                                                        if (err) throw err;
                                                        res.status(200)
                                                      });
                                                    });   
                                                  })
                                                  router.route('/fri1630off').post(function(req, res) {
                                                    con.connect(function(err) {
                                                        //if (err) throw err;
                                                        con.query("Update friday set `16:30` = 0 where username = ?",[req.body.username], function (err, results) {
                                                          if (err) throw err;
                                                          res.status(200)
                                                        });
                                                      });   
                                                    })
                                                    router.route('/fri1700off').post(function(req, res) {
                                                      con.connect(function(err) {
                                                          //if (err) throw err;
                                                          con.query("Update friday set `17:00` = 0 where username = ?",[req.body.username], function (err, results) {
                                                            if (err) throw err;
                                                            res.status(200)
                                                          });
                                                        });   
                                                      })
                                                      router.route('/fri1730off').post(function(req, res) {
                                                        con.connect(function(err) {
                                                            //if (err) throw err;
                                                            con.query("Update friday set `17:30` = 0 where username = ?",[req.body.username], function (err, results) {
                                                              if (err) throw err;
                                                              res.status(200)
                                                            });
                                                          });   
                                                        })
                                                        router.route('/fri1800off').post(function(req, res) {
                                                          con.connect(function(err) {
                                                              //if (err) throw err;
                                                              con.query("Update friday set `18:00` = 0 where username = ?",[req.body.username], function (err, results) {
                                                                if (err) throw err;
                                                                res.status(200)
                                                              });
                                                            });   
                                                          })
                                                          router.route('/fri1830off').post(function(req, res) {
                                                            con.connect(function(err) {
                                                                //if (err) throw err;
                                                                con.query("Update friday set `18:30` = 0 where username = ?",[req.body.username], function (err, results) {
                                                                  if (err) throw err;
                                                                  res.status(200)
                                                                });
                                                              });   
                                                            })
                                                            router.route('/fri1900off').post(function(req, res) {
                                                              con.connect(function(err) {
                                                                  //if (err) throw err;
                                                                  con.query("Update friday set `19:00` = 0 where username = ?",[req.body.username], function (err, results) {
                                                                    if (err) throw err;
                                                                    res.status(200)
                                                                  });
                                                                });   
                                                              })
                                                              router.route('/fri1930off').post(function(req, res) {
                                                                con.connect(function(err) {
                                                                    //if (err) throw err;
                                                                    con.query("Update friday set `19:30` = 0 where username = ?",[req.body.username], function (err, results) {
                                                                      if (err) throw err;
                                                                      res.status(200)
                                                                    });
                                                                  });   
                                                                })
                                                                router.route('/fri2000off').post(function(req, res) {
                                                                  con.connect(function(err) {
                                                                      //if (err) throw err;
                                                                      con.query("Update friday set `20:00` = 0 where username = ?",[req.body.username], function (err, results) {
                                                                        if (err) throw err;
                                                                        res.status(200)
                                                                      });
                                                                    });   
                                                                  })
              
               
               router.route('/sat800on').post(function(req, res) {
                    con.connect(function(err) {
                        //if (err) throw err;
                        con.query("Update saturday set `8:00` = 1 where username = ?",[req.body.username], function (err, results) {
                          if (err) throw err;
                          res.status(200)
                        });
                      });   
                    })

                    router.route('/sat830on').post(function(req, res) {
                      con.connect(function(err) {
                          //if (err) throw err;
                          con.query("Update saturday set `8:30` = 1 where username = ?",[req.body.username], function (err, results) {
                            if (err) throw err;
                            res.status(200)
                          });
                        });   
                      })
                      router.route('/sat900on').post(function(req, res) {
                        con.connect(function(err) {
                            //if (err) throw err;
                            con.query("Update saturday set `9:00` = 1 where username = ?",[req.body.username], function (err, results) {
                              if (err) throw err;
                              res.status(200)
                            });
                          });   
                        })
                        router.route('/sat930on').post(function(req, res) {
                          con.connect(function(err) {
                              //if (err) throw err;
                              con.query("Update saturday set `9:30` = 1 where username = ?",[req.body.username], function (err, results) {
                                if (err) throw err;
                                res.status(200)
                              });
                            });   
                          })
                          router.route('/sat1000on').post(function(req, res) {
                            con.connect(function(err) {
                                //if (err) throw err;
                                con.query("Update saturday set `10:00` = 1 where username = ?",[req.body.username], function (err, results) {
                                  if (err) throw err;
                                  res.status(200)
                                });
                              });   
                            })
                            router.route('/sat1030on').post(function(req, res) {
                              con.connect(function(err) {
                                  //if (err) throw err;
                                  con.query("Update saturday set `10:30` = 1 where username = ?",[req.body.username], function (err, results) {
                                    if (err) throw err;
                                    res.status(200)
                                  });
                                });   
                              })
                              router.route('/sat1100on').post(function(req, res) {
                                con.connect(function(err) {
                                    //if (err) throw err;
                                    con.query("Update saturday set `11:00` = 1 where username = ?",[req.body.username], function (err, results) {
                                      if (err) throw err;
                                      res.status(200)
                                    });
                                  });   
                                })
                                router.route('/sat1130on').post(function(req, res) {
                                  con.connect(function(err) {
                                      //if (err) throw err;
                                      con.query("Update saturday set `11:30` = 1 where username = ?",[req.body.username], function (err, results) {
                                        if (err) throw err;
                                        res.status(200)
                                      });
                                    });   
                                  })
                                  router.route('/sat1200on').post(function(req, res) {
                                    con.connect(function(err) {
                                        //if (err) throw err;
                                        con.query("Update saturday set `12:00` = 1 where username = ?",[req.body.username], function (err, results) {
                                          if (err) throw err;
                                          res.status(200)
                                        });
                                      });   
                                    })
                                    router.route('/sat1230on').post(function(req, res) {
                                      con.connect(function(err) {
                                          //if (err) throw err;
                                          con.query("Update saturday set `12:30` = 1 where username = ?",[req.body.username], function (err, results) {
                                            if (err) throw err;
                                            res.status(200)
                                          });
                                        });   
                                      })
                                      router.route('/sat1300on').post(function(req, res) {
                                        con.connect(function(err) {
                                            //if (err) throw err;
                                            con.query("Update saturday set `13:00` = 1 where username = ?",[req.body.username], function (err, results) {
                                              if (err) throw err;
                                              res.status(200)
                                            });
                                          });   
                                        })
                                        router.route('/sat1330on').post(function(req, res) {
                                          con.connect(function(err) {
                                              //if (err) throw err;
                                              con.query("Update saturday set `13:30` = 1 where username = ?",[req.body.username], function (err, results) {
                                                if (err) throw err;
                                                res.status(200)
                                              });
                                            });   
                                          })
                                          router.route('/sat1400on').post(function(req, res) {
                                            con.connect(function(err) {
                                                //if (err) throw err;
                                                con.query("Update saturday set `14:00` = 1 where username = ?",[req.body.username], function (err, results) {
                                                  if (err) throw err;
                                                  res.status(200)
                                                });
                                              });   
                                            })
                                            router.route('/sat1430on').post(function(req, res) {
                                              con.connect(function(err) {
                                                  //if (err) throw err;
                                                  con.query("Update saturday set `14:30` = 1 where username = ?",[req.body.username], function (err, results) {
                                                    if (err) throw err;
                                                    res.status(200)
                                                  });
                                                });   
                                              })
                                            router.route('/sat1500on').post(function(req, res) {
                                              con.connect(function(err) {
                                                  //if (err) throw err;
                                                  con.query("Update saturday set `15:00` = 1 where username = ?",[req.body.username], function (err, results) {
                                                    if (err) throw err;
                                                    res.status(200)
                                                  });
                                                });   
                                              })
                                              router.route('/sat1530on').post(function(req, res) {
                                                con.connect(function(err) {
                                                    //if (err) throw err;
                                                    con.query("Update saturday set `15:30` = 1 where username = ?",[req.body.username], function (err, results) {
                                                      if (err) throw err;
                                                      res.status(200)
                                                    });
                                                  });   
                                                })
                                                router.route('/sat1600on').post(function(req, res) {
                                                  con.connect(function(err) {
                                                      //if (err) throw err;
                                                      con.query("Update saturday set `16:00` = 1 where username = ?",[req.body.username], function (err, results) {
                                                        if (err) throw err;
                                                        res.status(200)
                                                      });
                                                    });   
                                                  })
                                                  router.route('/sat1630on').post(function(req, res) {
                                                    con.connect(function(err) {
                                                        //if (err) throw err;
                                                        con.query("Update saturday set `16:30` = 1 where username = ?",[req.body.username], function (err, results) {
                                                          if (err) throw err;
                                                          res.status(200)
                                                        });
                                                      });   
                                                    })
                                                    router.route('/sat1700on').post(function(req, res) {
                                                      con.connect(function(err) {
                                                          //if (err) throw err;
                                                          con.query("Update saturday set `17:00` = 1 where username = ?",[req.body.username], function (err, results) {
                                                            if (err) throw err;
                                                            res.status(200)
                                                          });
                                                        });   
                                                      })
                                                      router.route('/sat1730on').post(function(req, res) {
                                                        con.connect(function(err) {
                                                            //if (err) throw err;
                                                            con.query("Update saturday set `17:30` = 1 where username = ?",[req.body.username], function (err, results) {
                                                              if (err) throw err;
                                                              res.status(200)
                                                            });
                                                          });   
                                                        })
                                                        router.route('/sat1800on').post(function(req, res) {
                                                          con.connect(function(err) {
                                                              //if (err) throw err;
                                                              con.query("Update saturday set `18:00` = 1 where username = ?",[req.body.username], function (err, results) {
                                                                if (err) throw err;
                                                                res.status(200)
                                                              });
                                                            });   
                                                          })
                                                          router.route('/sat1830on').post(function(req, res) {
                                                            con.connect(function(err) {
                                                                //if (err) throw err;
                                                                con.query("Update saturday set `18:30` = 1 where username = ?",[req.body.username], function (err, results) {
                                                                  if (err) throw err;
                                                                  res.status(200)
                                                                });
                                                              });   
                                                            })
                                                            router.route('/sat1900on').post(function(req, res) {
                                                              con.connect(function(err) {
                                                                  //if (err) throw err;
                                                                  con.query("Update saturday set `19:00` = 1 where username = ?",[req.body.username], function (err, results) {
                                                                    if (err) throw err;
                                                                    res.status(200)
                                                                  });
                                                                });   
                                                              })
                                                              router.route('/sat1930on').post(function(req, res) {
                                                                con.connect(function(err) {
                                                                    //if (err) throw err;
                                                                    con.query("Update saturday set `19:30` = 1 where username = ?",[req.body.username], function (err, results) {
                                                                      if (err) throw err;
                                                                      res.status(200)
                                                                    });
                                                                  });   
                                                                })
                                                                router.route('/sat2000on').post(function(req, res) {
                                                                  con.connect(function(err) {
                                                                      //if (err) throw err;
                                                                      con.query("Update saturday set `20:00` = 1 where username = ?",[req.body.username], function (err, results) {
                                                                        if (err) throw err;
                                                                        res.status(200)
                                                                      });
                                                                    });   
                                                                  })                                                 
              
               
                  router.route('/sat800off').post(function(req, res) {
                    con.connect(function(err) {
                        //if (err) throw err;
                        con.query("Update saturday set `8:00` = 0 where username = ?",[req.body.username], function (err, results) {
                          if (err) throw err;
                          res.status(200)
                        });
                      });   
                    })

                    router.route('/sat830off').post(function(req, res) {
                      con.connect(function(err) {
                          //if (err) throw err;
                          con.query("Update saturday set `8:30` = 0 where username = ?",[req.body.username], function (err, results) {
                            if (err) throw err;
                            res.status(200)
                          });
                        });   
                      })
                      router.route('/sat900off').post(function(req, res) {
                        con.connect(function(err) {
                            //if (err) throw err;
                            con.query("Update saturday set `9:00` = 0 where username = ?",[req.body.username], function (err, results) {
                              if (err) throw err;
                              res.status(200)
                            });
                          });   
                        })
                        router.route('/sat930off').post(function(req, res) {
                          con.connect(function(err) {
                              //if (err) throw err;
                              con.query("Update saturday set `9:30` = 0 where username = ?",[req.body.username], function (err, results) {
                                if (err) throw err;
                                res.status(200)
                              });
                            });   
                          })
                          router.route('/sat1000off').post(function(req, res) {
                            con.connect(function(err) {
                                //if (err) throw err;
                                con.query("Update saturday set `10:00` = 0 where username = ?",[req.body.username], function (err, results) {
                                  if (err) throw err;
                                  res.status(200)
                                });
                              });   
                            })
                            router.route('/sat1030off').post(function(req, res) {
                              con.connect(function(err) {
                                  //if (err) throw err;
                                  con.query("Update saturday set `10:30` = 0 where username = ?",[req.body.username], function (err, results) {
                                    if (err) throw err;
                                    res.status(200)
                                  });
                                });   
                              })
                              router.route('/sat1100off').post(function(req, res) {
                                con.connect(function(err) {
                                    //if (err) throw err;
                                    con.query("Update saturday set `11:00` = 0 where username = ?",[req.body.username], function (err, results) {
                                      if (err) throw err;
                                      res.status(200)
                                    });
                                  });   
                                })
                                router.route('/sat1130off').post(function(req, res) {
                                  con.connect(function(err) {
                                      //if (err) throw err;
                                      con.query("Update saturday set `11:30` = 0 where username = ?",[req.body.username], function (err, results) {
                                        if (err) throw err;
                                        res.status(200)
                                      });
                                    });   
                                  })
                                  router.route('/sat1200off').post(function(req, res) {
                                    con.connect(function(err) {
                                        //if (err) throw err;
                                        con.query("Update saturday set `12:00` = 0 where username = ?",[req.body.username], function (err, results) {
                                          if (err) throw err;
                                          res.status(200)
                                        });
                                      });   
                                    })
                                    router.route('/sat1230off').post(function(req, res) {
                                      con.connect(function(err) {
                                          //if (err) throw err;
                                          con.query("Update saturday set `12:30` = 0 where username = ?",[req.body.username], function (err, results) {
                                            if (err) throw err;
                                            res.status(200)
                                          });
                                        });   
                                      })
                                      router.route('/sat1300off').post(function(req, res) {
                                        con.connect(function(err) {
                                            //if (err) throw err;
                                            con.query("Update saturday set `13:00` = 0 where username = ?",[req.body.username], function (err, results) {
                                              if (err) throw err;
                                              res.status(200)
                                            });
                                          });   
                                        })
                                        router.route('/sat1330off').post(function(req, res) {
                                          con.connect(function(err) {
                                              //if (err) throw err;
                                              con.query("Update saturday set `13:30` = 0 where username = ?",[req.body.username], function (err, results) {
                                                if (err) throw err;
                                                res.status(200)
                                              });
                                            });   
                                          })
                                          router.route('/sat1400off').post(function(req, res) {
                                            con.connect(function(err) {
                                                //if (err) throw err;
                                                con.query("Update saturday set `14:00` = 0 where username = ?",[req.body.username], function (err, results) {
                                                  if (err) throw err;
                                                  res.status(200)
                                                });
                                              });   
                                            })
                                            router.route('/sat1430off').post(function(req, res) {
                                              con.connect(function(err) {
                                                  //if (err) throw err;
                                                  con.query("Update saturday set `14:30` = 0 where username = ?",[req.body.username], function (err, results) {
                                                    if (err) throw err;
                                                    res.status(200)
                                                  });
                                                });   
                                              })
                                            router.route('/sat1500off').post(function(req, res) {
                                              con.connect(function(err) {
                                                  //if (err) throw err;
                                                  con.query("Update saturday set `15:00` = 0 where username = ?",[req.body.username], function (err, results) {
                                                    if (err) throw err;
                                                    res.status(200)
                                                  });
                                                });   
                                              })
                                              router.route('/sat1530off').post(function(req, res) {
                                                con.connect(function(err) {
                                                    //if (err) throw err;
                                                    con.query("Update saturday set `15:30` = 0 where username = ?",[req.body.username], function (err, results) {
                                                      if (err) throw err;
                                                      res.status(200)
                                                    });
                                                  });   
                                                })
                                                router.route('/sat1600off').post(function(req, res) {
                                                  con.connect(function(err) {
                                                      //if (err) throw err;
                                                      con.query("Update saturday set `16:00` = 0 where username = ?",[req.body.username], function (err, results) {
                                                        if (err) throw err;
                                                        res.status(200)
                                                      });
                                                    });   
                                                  })
                                                  router.route('/sat1630off').post(function(req, res) {
                                                    con.connect(function(err) {
                                                        //if (err) throw err;
                                                        con.query("Update saturday set `16:30` = 0 where username = ?",[req.body.username], function (err, results) {
                                                          if (err) throw err;
                                                          res.status(200)
                                                        });
                                                      });   
                                                    })
                                                    router.route('/sat1700off').post(function(req, res) {
                                                      con.connect(function(err) {
                                                          //if (err) throw err;
                                                          con.query("Update saturday set `17:00` = 0 where username = ?",[req.body.username], function (err, results) {
                                                            if (err) throw err;
                                                            res.status(200)
                                                          });
                                                        });   
                                                      })
                                                      router.route('/sat1730off').post(function(req, res) {
                                                        con.connect(function(err) {
                                                            //if (err) throw err;
                                                            con.query("Update saturday set `17:30` = 0 where username = ?",[req.body.username], function (err, results) {
                                                              if (err) throw err;
                                                              res.status(200)
                                                            });
                                                          });   
                                                        })
                                                        router.route('/sat1800off').post(function(req, res) {
                                                          con.connect(function(err) {
                                                              //if (err) throw err;
                                                              con.query("Update saturday set `18:00` = 0 where username = ?",[req.body.username], function (err, results) {
                                                                if (err) throw err;
                                                                res.status(200)
                                                              });
                                                            });   
                                                          })
                                                          router.route('/sat1830off').post(function(req, res) {
                                                            con.connect(function(err) {
                                                                //if (err) throw err;
                                                                con.query("Update saturday set `18:30` = 0 where username = ?",[req.body.username], function (err, results) {
                                                                  if (err) throw err;
                                                                  res.status(200)
                                                                });
                                                              });   
                                                            })
                                                            router.route('/sat1900off').post(function(req, res) {
                                                              con.connect(function(err) {
                                                                  //if (err) throw err;
                                                                  con.query("Update saturday set `19:00` = 0 where username = ?",[req.body.username], function (err, results) {
                                                                    if (err) throw err;
                                                                    res.status(200)
                                                                  });
                                                                });   
                                                              })
                                                              router.route('/sat1930off').post(function(req, res) {
                                                                con.connect(function(err) {
                                                                    //if (err) throw err;
                                                                    con.query("Update saturday set `19:30` = 0 where username = ?",[req.body.username], function (err, results) {
                                                                      if (err) throw err;
                                                                      res.status(200)
                                                                    });
                                                                  });   
                                                                })
                                                                router.route('/sat2000off').post(function(req, res) {
                                                                  con.connect(function(err) {
                                                                      //if (err) throw err;
                                                                      con.query("Update saturday set `20:00` = 0 where username = ?",[req.body.username], function (err, results) {
                                                                        if (err) throw err;
                                                                        res.status(200)
                                                                      });
                                                                    });   
                                                                  })                                       
                                                                  
                  
               
                   
               router.route('/sun800on').post(function(req, res) {
                    con.connect(function(err) {
                        //if (err) throw err;
                        con.query("Update sunday set `8:00` = 1 where username = ?",[req.body.username], function (err, results) {
                          if (err) throw err;
                          res.status(200)
                        });
                      });   
                    })

                    router.route('/sun830on').post(function(req, res) {
                      con.connect(function(err) {
                          //if (err) throw err;
                          con.query("Update sunday set `8:30` = 1 where username = ?",[req.body.username], function (err, results) {
                            if (err) throw err;
                            res.status(200)
                          });
                        });   
                      })
                      router.route('/sun900on').post(function(req, res) {
                        con.connect(function(err) {
                            //if (err) throw err;
                            con.query("Update sunday set `9:00` = 1 where username = ?",[req.body.username], function (err, results) {
                              if (err) throw err;
                              res.status(200)
                            });
                          });   
                        })
                        router.route('/sun930on').post(function(req, res) {
                          con.connect(function(err) {
                              //if (err) throw err;
                              con.query("Update sunday set `9:30` = 1 where username = ?",[req.body.username], function (err, results) {
                                if (err) throw err;
                                res.status(200)
                              });
                            });   
                          })
                          router.route('/sun1000on').post(function(req, res) {
                            con.connect(function(err) {
                                //if (err) throw err;
                                con.query("Update sunday set `10:00` = 1 where username = ?",[req.body.username], function (err, results) {
                                  if (err) throw err;
                                  res.status(200)
                                });
                              });   
                            })
                            router.route('/sun1030on').post(function(req, res) {
                              con.connect(function(err) {
                                  //if (err) throw err;
                                  con.query("Update sunday set `10:30` = 1 where username = ?",[req.body.username], function (err, results) {
                                    if (err) throw err;
                                    res.status(200)
                                  });
                                });   
                              })
                              router.route('/sun1100on').post(function(req, res) {
                                con.connect(function(err) {
                                    //if (err) throw err;
                                    con.query("Update sunday set `11:00` = 1 where username = ?",[req.body.username], function (err, results) {
                                      if (err) throw err;
                                      res.status(200)
                                    });
                                  });   
                                })
                                router.route('/sun1130on').post(function(req, res) {
                                  con.connect(function(err) {
                                      //if (err) throw err;
                                      con.query("Update sunday set `11:30` = 1 where username = ?",[req.body.username], function (err, results) {
                                        if (err) throw err;
                                        res.status(200)
                                      });
                                    });   
                                  })
                                  router.route('/sun1200on').post(function(req, res) {
                                    con.connect(function(err) {
                                        //if (err) throw err;
                                        con.query("Update sunday set `12:00` = 1 where username = ?",[req.body.username], function (err, results) {
                                          if (err) throw err;
                                          res.status(200)
                                        });
                                      });   
                                    })
                                    router.route('/sun1230on').post(function(req, res) {
                                      con.connect(function(err) {
                                          //if (err) throw err;
                                          con.query("Update sunday set `12:30` = 1 where username = ?",[req.body.username], function (err, results) {
                                            if (err) throw err;
                                            res.status(200)
                                          });
                                        });   
                                      })
                                      router.route('/sun1300on').post(function(req, res) {
                                        con.connect(function(err) {
                                            //if (err) throw err;
                                            con.query("Update sunday set `13:00` = 1 where username = ?",[req.body.username], function (err, results) {
                                              if (err) throw err;
                                              res.status(200)
                                            });
                                          });   
                                        })
                                        router.route('/sun1330on').post(function(req, res) {
                                          con.connect(function(err) {
                                              //if (err) throw err;
                                              con.query("Update sunday set `13:30` = 1 where username = ?",[req.body.username], function (err, results) {
                                                if (err) throw err;
                                                res.status(200)
                                              });
                                            });   
                                          })
                                          router.route('/sun1400on').post(function(req, res) {
                                            con.connect(function(err) {
                                                //if (err) throw err;
                                                con.query("Update sunday set `14:00` = 1 where username = ?",[req.body.username], function (err, results) {
                                                  if (err) throw err;
                                                  res.status(200)
                                                });
                                              });   
                                            })
                                            router.route('/sun1430on').post(function(req, res) {
                                              con.connect(function(err) {
                                                  //if (err) throw err;
                                                  con.query("Update sunday set `14:30` = 1 where username = ?",[req.body.username], function (err, results) {
                                                    if (err) throw err;
                                                    res.status(200)
                                                  });
                                                });   
                                              })
                                            router.route('/sun1500on').post(function(req, res) {
                                              con.connect(function(err) {
                                                  //if (err) throw err;
                                                  con.query("Update sunday set `15:00` = 1 where username = ?",[req.body.username], function (err, results) {
                                                    if (err) throw err;
                                                    res.status(200)
                                                  });
                                                });   
                                              })
                                              router.route('/sun1530on').post(function(req, res) {
                                                con.connect(function(err) {
                                                    //if (err) throw err;
                                                    con.query("Update sunday set `15:30` = 1 where username = ?",[req.body.username], function (err, results) {
                                                      if (err) throw err;
                                                      res.status(200)
                                                    });
                                                  });   
                                                })
                                                router.route('/sun1600on').post(function(req, res) {
                                                  con.connect(function(err) {
                                                      //if (err) throw err;
                                                      con.query("Update sunday set `16:00` = 1 where username = ?",[req.body.username], function (err, results) {
                                                        if (err) throw err;
                                                        res.status(200)
                                                      });
                                                    });   
                                                  })
                                                  router.route('/sun1630on').post(function(req, res) {
                                                    con.connect(function(err) {
                                                        //if (err) throw err;
                                                        con.query("Update sunday set `16:30` = 1 where username = ?",[req.body.username], function (err, results) {
                                                          if (err) throw err;
                                                          res.status(200)
                                                        });
                                                      });   
                                                    })
                                                    router.route('/sun1700on').post(function(req, res) {
                                                      con.connect(function(err) {
                                                          //if (err) throw err;
                                                          con.query("Update sunday set `17:00` = 1 where username = ?",[req.body.username], function (err, results) {
                                                            if (err) throw err;
                                                            res.status(200)
                                                          });
                                                        });   
                                                      })
                                                      router.route('/sun1730on').post(function(req, res) {
                                                        con.connect(function(err) {
                                                            //if (err) throw err;
                                                            con.query("Update sunday set `17:30` = 1 where username = ?",[req.body.username], function (err, results) {
                                                              if (err) throw err;
                                                              res.status(200)
                                                            });
                                                          });   
                                                        })
                                                        router.route('/sun1800on').post(function(req, res) {
                                                          con.connect(function(err) {
                                                              //if (err) throw err;
                                                              con.query("Update sunday set `18:00` = 1 where username = ?",[req.body.username], function (err, results) {
                                                                if (err) throw err;
                                                                res.status(200)
                                                              });
                                                            });   
                                                          })
                                                          router.route('/sun1830on').post(function(req, res) {
                                                            con.connect(function(err) {
                                                                //if (err) throw err;
                                                                con.query("Update sunday set `18:30` = 1 where username = ?",[req.body.username], function (err, results) {
                                                                  if (err) throw err;
                                                                  res.status(200)
                                                                });
                                                              });   
                                                            })
                                                            router.route('/sun1900on').post(function(req, res) {
                                                              con.connect(function(err) {
                                                                  //if (err) throw err;
                                                                  con.query("Update sunday set `19:00` = 1 where username = ?",[req.body.username], function (err, results) {
                                                                    if (err) throw err;
                                                                    res.status(200)
                                                                  });
                                                                });   
                                                              })
                                                              router.route('/sun1930on').post(function(req, res) {
                                                                con.connect(function(err) {
                                                                    //if (err) throw err;
                                                                    con.query("Update sunday set `19:30` = 1 where username = ?",[req.body.username], function (err, results) {
                                                                      if (err) throw err;
                                                                      res.status(200)
                                                                    });
                                                                  });   
                                                                })
                                                                router.route('/sun2000on').post(function(req, res) {
                                                                  con.connect(function(err) {
                                                                      //if (err) throw err;
                                                                      con.query("Update sunday set `20:00` = 1 where username = ?",[req.body.username], function (err, results) {
                                                                        if (err) throw err;
                                                                        res.status(200)
                                                                      });
                                                                    });   
                                                                  })                       
                             
               
                  router.route('/sun800off').post(function(req, res) {
                    con.connect(function(err) {
                        //if (err) throw err;
                        con.query("Update sunday set `8:00` = 0 where username = ?",[req.body.username], function (err, results) {
                          if (err) throw err;
                          res.status(200)
                        });
                      });   
                    })

                    router.route('/sun830off').post(function(req, res) {
                      con.connect(function(err) {
                          //if (err) throw err;
                          con.query("Update sunday set `8:30` = 0 where username = ?",[req.body.username], function (err, results) {
                            if (err) throw err;
                            res.status(200)
                          });
                        });   
                      })
                      router.route('/sun900off').post(function(req, res) {
                        con.connect(function(err) {
                            //if (err) throw err;
                            con.query("Update sunday set `9:00` = 0 where username = ?",[req.body.username], function (err, results) {
                              if (err) throw err;
                              res.status(200)
                            });
                          });   
                        })
                        router.route('/sun930off').post(function(req, res) {
                          con.connect(function(err) {
                              //if (err) throw err;
                              con.query("Update sunday set `9:30` = 0 where username = ?",[req.body.username], function (err, results) {
                                if (err) throw err;
                                res.status(200)
                              });
                            });   
                          })
                          router.route('/sun1000off').post(function(req, res) {
                            con.connect(function(err) {
                                //if (err) throw err;
                                con.query("Update sunday set `10:00` = 0 where username = ?",[req.body.username], function (err, results) {
                                  if (err) throw err;
                                  res.status(200)
                                });
                              });   
                            })
                            router.route('/sun1030off').post(function(req, res) {
                              con.connect(function(err) {
                                  //if (err) throw err;
                                  con.query("Update sunday set `10:30` = 0 where username = ?",[req.body.username], function (err, results) {
                                    if (err) throw err;
                                    res.status(200)
                                  });
                                });   
                              })
                              router.route('/sun1100off').post(function(req, res) {
                                con.connect(function(err) {
                                    //if (err) throw err;
                                    con.query("Update sunday set `11:00` = 0 where username = ?",[req.body.username], function (err, results) {
                                      if (err) throw err;
                                      res.status(200)
                                    });
                                  });   
                                })
                                router.route('/sun1130off').post(function(req, res) {
                                  con.connect(function(err) {
                                      //if (err) throw err;
                                      con.query("Update sunday set `11:30` = 0 where username = ?",[req.body.username], function (err, results) {
                                        if (err) throw err;
                                        res.status(200)
                                      });
                                    });   
                                  })
                                  router.route('/sun1200off').post(function(req, res) {
                                    con.connect(function(err) {
                                        //if (err) throw err;
                                        con.query("Update sunday set `12:00` = 0 where username = ?",[req.body.username], function (err, results) {
                                          if (err) throw err;
                                          res.status(200)
                                        });
                                      });   
                                    })
                                    router.route('/sun1230off').post(function(req, res) {
                                      con.connect(function(err) {
                                          //if (err) throw err;
                                          con.query("Update sunday set `12:30` = 0 where username = ?",[req.body.username], function (err, results) {
                                            if (err) throw err;
                                            res.status(200)
                                          });
                                        });   
                                      })
                                      router.route('/sun1300off').post(function(req, res) {
                                        con.connect(function(err) {
                                            //if (err) throw err;
                                            con.query("Update sunday set `13:00` = 0 where username = ?",[req.body.username], function (err, results) {
                                              if (err) throw err;
                                              res.status(200)
                                            });
                                          });   
                                        })
                                        router.route('/sun1330off').post(function(req, res) {
                                          con.connect(function(err) {
                                              //if (err) throw err;
                                              con.query("Update sunday set `13:30` = 0 where username = ?",[req.body.username], function (err, results) {
                                                if (err) throw err;
                                                res.status(200)
                                              });
                                            });   
                                          })
                                          router.route('/sun1400off').post(function(req, res) {
                                            con.connect(function(err) {
                                                //if (err) throw err;
                                                con.query("Update sunday set `14:00` = 0 where username = ?",[req.body.username], function (err, results) {
                                                  if (err) throw err;
                                                  res.status(200)
                                                });
                                              });   
                                            })
                                            router.route('/sun1430off').post(function(req, res) {
                                              con.connect(function(err) {
                                                  //if (err) throw err;
                                                  con.query("Update sunday set `14:30` = 0 where username = ?",[req.body.username], function (err, results) {
                                                    if (err) throw err;
                                                    res.status(200)
                                                  });
                                                });   
                                              })
                                            router.route('/sun1500off').post(function(req, res) {
                                              con.connect(function(err) {
                                                  //if (err) throw err;
                                                  con.query("Update sunday set `15:00` = 0 where username = ?",[req.body.username], function (err, results) {
                                                    if (err) throw err;
                                                    res.status(200)
                                                  });
                                                });   
                                              })
                                              router.route('/sun1530off').post(function(req, res) {
                                                con.connect(function(err) {
                                                    //if (err) throw err;
                                                    con.query("Update sunday set `15:30` = 0 where username = ?",[req.body.username], function (err, results) {
                                                      if (err) throw err;
                                                      res.status(200)
                                                    });
                                                  });   
                                                })
                                                router.route('/sun1600off').post(function(req, res) {
                                                  con.connect(function(err) {
                                                      //if (err) throw err;
                                                      con.query("Update sunday set `16:00` = 0 where username = ?",[req.body.username], function (err, results) {
                                                        if (err) throw err;
                                                        res.status(200)
                                                      });
                                                    });   
                                                  })
                                                  router.route('/sun1630off').post(function(req, res) {
                                                    con.connect(function(err) {
                                                        //if (err) throw err;
                                                        con.query("Update sunday set `16:30` = 0 where username = ?",[req.body.username], function (err, results) {
                                                          if (err) throw err;
                                                          res.status(200)
                                                        });
                                                      });   
                                                    })
                                                    router.route('/sun1700off').post(function(req, res) {
                                                      con.connect(function(err) {
                                                          //if (err) throw err;
                                                          con.query("Update sunday set `17:00` = 0 where username = ?",[req.body.username], function (err, results) {
                                                            if (err) throw err;
                                                            res.status(200)
                                                          });
                                                        });   
                                                      })
                                                      router.route('/sun1730off').post(function(req, res) {
                                                        con.connect(function(err) {
                                                            //if (err) throw err;
                                                            con.query("Update sunday set `17:30` = 0 where username = ?",[req.body.username], function (err, results) {
                                                              if (err) throw err;
                                                              res.status(200)
                                                            });
                                                          });   
                                                        })
                                                        router.route('/sun1800off').post(function(req, res) {
                                                          con.connect(function(err) {
                                                              //if (err) throw err;
                                                              con.query("Update sunday set `18:00` = 0 where username = ?",[req.body.username], function (err, results) {
                                                                if (err) throw err;
                                                                res.status(200)
                                                              });
                                                            });   
                                                          })
                                                          router.route('/sun1830off').post(function(req, res) {
                                                            con.connect(function(err) {
                                                                //if (err) throw err;
                                                                con.query("Update sunday set `18:30` = 0 where username = ?",[req.body.username], function (err, results) {
                                                                  if (err) throw err;
                                                                  res.status(200)
                                                                });
                                                              });   
                                                            })
                                                            router.route('/sun1900off').post(function(req, res) {
                                                              con.connect(function(err) {
                                                                  //if (err) throw err;
                                                                  con.query("Update sunday set `19:00` = 0 where username = ?",[req.body.username], function (err, results) {
                                                                    if (err) throw err;
                                                                    res.status(200)
                                                                  });
                                                                });   
                                                              })
                                                              router.route('/sun1930off').post(function(req, res) {
                                                                con.connect(function(err) {
                                                                    //if (err) throw err;
                                                                    con.query("Update sunday set `19:30` = 0 where username = ?",[req.body.username], function (err, results) {
                                                                      if (err) throw err;
                                                                      res.status(200)
                                                                    });
                                                                  });   
                                                                })
                                                                router.route('/sun2000off').post(function(req, res) {
                                                                  con.connect(function(err) {
                                                                      //if (err) throw err;
                                                                      con.query("Update sunday set `20:00` = 0 where username = ?",[req.body.username], function (err, results) {
                                                                        if (err) throw err;
                                                                        res.status(200)
                                                                      });
                                                                    });   
                                                                  })                                                   

              router.route('/tutorslogin').get(function(req, res) {
                con.connect(function(err) {
                    //if (err) throw err;
                    con.query("SELECT * FROM tutors", function (err, data, fields) {
                      if (err) throw err;
                      console.log(data);
                      res.status(200).send(data)
                    });
                  });   
                });

                router.route('/temptutor').post(function(req, res) {
                  con.connect(function(err) {
                      //if (err) throw err;
                      con.query("Insert into tempTutorUsername (username) values (?)",[req.body.username ], function (err, results) {
                        if (err) throw err;
                        res.status(200)
                      });
                    });   
                  })

                  router.route('/tempadmin').post(function(req, res) {
                    con.connect(function(err) {
                        //if (err) throw err;
                        con.query("Insert into tempAdminUsername (username) values (?)",[req.body.username], function (err, results) {
                          if (err) throw err;
                          res.status(200)
                        });
                      });   
                    })

                  router.route('/gettemptutor').get(function(req, res) {
                    con.connect(function(err) {
                        //if (err) throw err;
                        con.query("SELECT * FROM tempTutorUsername", function (err, data, fields) {
                          if (err) throw err;
                          console.log(data);
                          res.status(200).send(data)
                        });
                      });   
                    })
                    router.route('/gettempadmin').get(function(req, res) {
                      con.connect(function(err) {
                          //if (err) throw err;
                          con.query("SELECT * FROM tempAdminUsername", function (err, data, fields) {
                            if (err) throw err;
                            console.log(data);
                            res.status(200).send(data)
                          });
                        });   
                      })
                    router.route('/deletetemptutor').post(function(req, res) {
                      con.connect(function(err) {
                          //if (err) throw err;
                          con.query("Delete from tempTutorUsername",function (err, results) {
                            if (err) throw err;
                            res.status(200)
                          });
                        });   
                      }) 

                      router.route('/deletetempadmin').post(function(req, res) {
                        con.connect(function(err) {
                            //if (err) throw err;
                            con.query("Delete from tempAdminUsername",function (err, results) {
                              if (err) throw err;
                              res.status(200)
                            });
                          });   
                        }) 

                      router.route('/deleteapps').post(function(req, res) {
                        con.connect(function(err) {
                            //if (err) throw err;
                            con.query("Delete from appointments",function (err, results) {
                              if (err) throw err;
                              res.status(200)
                            });
                          });   
                        }) ;

                    router.route('/appointment').post(function(req, res) {
                      con.connect(function(err) {
                          //if (err) throw err;
                          con.query("Insert into appointments (studentName,date,time,class,username,completed,canceled,noshow,apptid,email) values (?,?,?,?,?,0,0,0,?,?)",[req.body.studentName,req.body.date, req.body.time, req.body.class, req.body.username, req.body.appointmentId, req.body.studentEmail], function (err, results) {
                            if (err) throw err;
                            res.status(200)
                          });
                        });   
            
                      });
                      

                    
                      router.route('/appointmentid').get(function(req, res) {
                        con.connect(function(err) {
                            //if (err) throw err;
                            con.query("SELECT * FROM appointments", function (err, data, fields) {
                              if (err) throw err;
                              console.log(data);
                              res.status(200).send(data)
                            });
                          });   
                        });

          

                          router.route('/makeFile').post(function(req, res) {
                            var fs = require('fs');
                          
                            fs.writeFile('appointments.txt', req.body.text, function (err) {
                              if (err) throw err;
                              console.log('Replaced!');
                            });

                            
                                });

                                router.route('/download').get(function(req, res) {
                                  
                                    var file = __dirname + '\\appointments.txt';
                                    res.download(file,'\\appointments.txt');
                                  });
                              
                                      

                                router.route('/sendemail').post(function(req, res) {
                                  var nodemailer = require('nodemailer');

                                      var transporter = nodemailer.createTransport({
                                        service: 'gmail',
                                        auth: {
                                          user: 'mathcentercbu@gmail.com',
                                          pass: 'Tutoring1234'
                                        }
                                      });

                                      var mailOptions = {
                                        from: 'mathcentercbu@gmail.com',
                                        to: req.body.email,
                                        subject: 'New Tutoring Booking',
                                        text: 'Check your tutor page for a new appointment'
                                      };

                                      transporter.sendMail(mailOptions, function(error, info){
                                        if (error) {
                                          console.log(error);
                                        } else {
                                          console.log('Email sent: ' + info.response);
                                        }
                                      });

                                });
                                router.route('/completed').post(function(req, res) {
                                  con.connect(function(err) {
                                      //if (err) throw err;
                                      con.query("Update appointments set completed = 1 where apptId = ?", [req.body.id],function (err, results) {
                                        if (err) throw err;
                                        res.status(200)
                                      });
                                    });   
                                  });

                                  router.route('/canceled').post(function(req, res) {
                                    con.connect(function(err) {
                                        //if (err) throw err;
                                        con.query("Update appointments set canceled = 1 where apptId = ?", [req.body.id],function (err, results) {
                                          if (err) throw err;
                                          res.status(200)
                                        });
                                      });   
                                    }) ;  

                                    router.route('/noshow').post(function(req, res) {
                                      con.connect(function(err) {
                                          //if (err) throw err;
                                          con.query("Update appointments set noshow = 1 where apptId = ?", [req.body.id],function (err, results) {
                                            if (err) throw err;
                                            res.status(200)
                                          });
                                        });   
                                      }); 
                                      
                                        router.route('/cttutors').post(function(req, res) {
                                          con.connect(function(err) {
                                              //if (err) throw err;
                                              con.query("Insert into tutors (name,email,description,active,username,password) values ('null','null','null',0,?,?)",[req.body.username,req.body.password], function (err, results) {
                                                if (err) throw err;
                                                res.status(200)
                                              });
                                            });   
                                            con.connect(function(err) {
                                              //if (err) throw err;
                                              con.query("INSERT INTO `courses`(`tutorname`, `username`, `Alg105`, `Alg108`, `Alg118`, `Alg120`, `Math103`, `Math105`, `Math106`, `Math107`, `Math110`, `Math117`, `Math121`, `Math129`, `Math131`, `Math132`, `Math141`, `Math151`, `Math152`, `Math162`, `Math201`, `Math231`, `Math232`, `Math301`, `Math308`, `Math309`, `Math329`, `Math401`, `Math402`, `Math405`, `Math413`, `Math414`,`other`)VALUES('null',?,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1)",[req.body.username], function (err, results) {
                                                if (err) throw err;
                                                res.status(200)
                                              });
                                            }); 
                                  
                                            con.connect(function(err) {
                                              //if (err) throw err;
                                              con.query("INSERT INTO `monday`(`tutorname`, `username`, `working`, `8:00`, `8:30`, `9:00`, `9:30`, `10:00`, `10:30`, `11:00`, `11:30`, `12:00`, `12:30`, `13:00`, `13:30`, `14:00`, `14:30`, `15:00`, `15:30`, `16:00`, `16:30`, `17:30`, `18:00`, `18:30`, `19:00`, `19:30`, `20:00`) VALUES ('null',?,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0)",[req.body.username], function (err, results) {
                                                if (err) throw err;
                                                res.status(200)
                                              });
                                            });
                                            con.connect(function(err) {
                                              //if (err) throw err;
                                              con.query("INSERT INTO `tuesday`(`tutorname`, `username`, `working`, `8:00`, `8:30`, `9:00`, `9:30`, `10:00`, `10:30`, `11:00`, `11:30`, `12:00`, `12:30`, `13:00`, `13:30`, `14:00`, `14:30`, `15:00`, `15:30`, `16:00`, `16:30`, `17:30`, `18:00`, `18:30`, `19:00`, `19:30`, `20:00`) VALUES ('null',?,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0)",[req.body.username], function (err, results) {
                                                if (err) throw err;
                                                res.status(200)
                                              });
                                            });
                                            con.connect(function(err) {
                                              //if (err) throw err;
                                              con.query("INSERT INTO `wednesday`(`tutorname`, `username`, `working`, `8:00`, `8:30`, `9:00`, `9:30`, `10:00`, `10:30`, `11:00`, `11:30`, `12:00`, `12:30`, `13:00`, `13:30`, `14:00`, `14:30`, `15:00`, `15:30`, `16:00`, `16:30`, `17:30`, `18:00`, `18:30`, `19:00`, `19:30`, `20:00`) VALUES ('null',?,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0)",[req.body.username], function (err, results) {
                                                if (err) throw err;
                                                res.status(200)
                                              });
                                            });
                                            con.connect(function(err) {
                                              //if (err) throw err;
                                              con.query("INSERT INTO `thursday`(`tutorname`, `username`, `working`, `8:00`, `8:30`, `9:00`, `9:30`, `10:00`, `10:30`, `11:00`, `11:30`, `12:00`, `12:30`, `13:00`, `13:30`, `14:00`, `14:30`, `15:00`, `15:30`, `16:00`, `16:30`, `17:30`, `18:00`, `18:30`, `19:00`, `19:30`, `20:00`) VALUES ('null',?,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0)",[req.body.username], function (err, results) {
                                                if (err) throw err;
                                                res.status(200)
                                              });
                                            });
                                            con.connect(function(err) {
                                              //if (err) throw err;
                                              con.query("INSERT INTO `friday`(`tutorname`, `username`, `working`, `8:00`, `8:30`, `9:00`, `9:30`, `10:00`, `10:30`, `11:00`, `11:30`, `12:00`, `12:30`, `13:00`, `13:30`, `14:00`, `14:30`, `15:00`, `15:30`, `16:00`, `16:30`, `17:30`, `18:00`, `18:30`, `19:00`, `19:30`, `20:00`) VALUES ('null',?,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0)",[req.body.username], function (err, results) {
                                                if (err) throw err;
                                                res.status(200)
                                              });
                                            });
                                            con.connect(function(err) {
                                              //if (err) throw err;
                                              con.query("INSERT INTO `saturday`(`tutorname`, `username`, `working`, `8:00`, `8:30`, `9:00`, `9:30`, `10:00`, `10:30`, `11:00`, `11:30`, `12:00`, `12:30`, `13:00`, `13:30`, `14:00`, `14:30`, `15:00`, `15:30`, `16:00`, `16:30`, `17:30`, `18:00`, `18:30`, `19:00`, `19:30`, `20:00`) VALUES ('null',?,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0)",[req.body.username], function (err, results) {
                                                if (err) throw err;
                                                res.status(200)
                                              });
                                            });
                                            con.connect(function(err) {
                                              //if (err) throw err;
                                              con.query("INSERT INTO `sunday`(`tutorname`, `username`, `working`, `8:00`, `8:30`, `9:00`, `9:30`, `10:00`, `10:30`, `11:00`, `11:30`, `12:00`, `12:30`, `13:00`, `13:30`, `14:00`, `14:30`, `15:00`, `15:30`, `16:00`, `16:30`, `17:30`, `18:00`, `18:30`, `19:00`, `19:30`, `20:00`) VALUES ('null',?,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0)",[req.body.username], function (err, results) {
                                                if (err) throw err;
                                                res.status(200)
                                              });
                                            });
                                          })

                                              
                                                              router.route('/dttutors').post(function(req, res) {
                                                                con.connect(function(err) {
                                                                    //if (err) throw err;
                                                                    con.query("Delete from tutors where username = ?",[req.body.username], function (err, results) {
                                                                      if (err) throw err;
                                                                      res.status(200)
                                                                    });
                                                        
                                                                  });   
                                                                  con.connect(function(err) {
                                                                    //if (err) throw err;
                                                                    con.query("Delete from sunday where username = ?",[req.body.username], function (err, results) {
                                                                      if (err) throw err;
                                                                      res.status(200)
                                                                    });
                                                        
                                                                  }); 
                                                                  con.connect(function(err) {
                                                                    //if (err) throw err;
                                                                    con.query("Delete from courses where username = ?",[req.body.username], function (err, results) {
                                                                      if (err) throw err;
                                                                      res.status(200)
                                                                    });
                                                        
                                                                  }); 
                                                                  con.connect(function(err) {
                                                                    //if (err) throw err;
                                                                    con.query("Delete from monday where username = ?",[req.body.username], function (err, results) {
                                                                      if (err) throw err;
                                                                      res.status(200)
                                                                    });
                                                        
                                                                  }); 
                                                                  con.connect(function(err) {
                                                                    //if (err) throw err;
                                                                    con.query("Delete from tuesday where username = ?",[req.body.username], function (err, results) {
                                                                      if (err) throw err;
                                                                      res.status(200)
                                                                    });
                                                        
                                                                  }); 
                                                                  con.connect(function(err) {
                                                                    //if (err) throw err;
                                                                    con.query("Delete from wednesday where username = ?",[req.body.username], function (err, results) {
                                                                      if (err) throw err;
                                                                      res.status(200)
                                                                    });
                                                        
                                                                  }); 
                                                                  con.connect(function(err) {
                                                                    //if (err) throw err;
                                                                    con.query("Delete from thursday where username = ?",[req.body.username], function (err, results) {
                                                                      if (err) throw err;
                                                                      res.status(200)
                                                                    });
                                                        
                                                                  }); 
                                                                  con.connect(function(err) {
                                                                    //if (err) throw err;
                                                                    con.query("Delete from friday where username = ?",[req.body.username], function (err, results) {
                                                                      if (err) throw err;
                                                                      res.status(200)
                                                                    });
                                                        
                                                                  }); 
                                                                  con.connect(function(err) {
                                                                    //if (err) throw err;
                                                                    con.query("Delete from saturday where username = ?",[req.body.username], function (err, results) {
                                                                      if (err) throw err;
                                                                      res.status(200)
                                                                    });
                                                        
                                                                  }); 
                                    
                                                                })
                                                                router.route('/workmon').post(function(req, res) {
                                                                  con.connect(function(err) {
                                                                      //if (err) throw err;
                                                                      con.query("Update monday set working = 1 where username = ?", [req.body.username],function (err, results) {
                                                                        if (err) throw err;
                                                                        res.status(200)
                                                                      });
                                                                    });   
                                                                  }) 
                                                                  router.route('/worktue').post(function(req, res) {
                                                                    con.connect(function(err) {
                                                                        //if (err) throw err;
                                                                        con.query("Update tuesday set working = 1 where username = ?", [req.body.username],function (err, results) {
                                                                          if (err) throw err;
                                                                          res.status(200)
                                                                        });
                                                                      });   
                                                                    }) 
                                                                    router.route('/workwed').post(function(req, res) {
                                                                      con.connect(function(err) {
                                                                          //if (err) throw err;
                                                                          con.query("Update wednesday set working = 1 where username = ?", [req.body.username],function (err, results) {
                                                                            if (err) throw err;
                                                                            res.status(200)
                                                                          });
                                                                        });   
                                                                      }) 
                                                                      router.route('/workthu').post(function(req, res) {
                                                                        con.connect(function(err) {
                                                                            //if (err) throw err;
                                                                            con.query("Update thursday set working = 1 where username = ?", [req.body.username],function (err, results) {
                                                                              if (err) throw err;
                                                                              res.status(200)
                                                                            });
                                                                          });   
                                                                        }) 
                                                                        router.route('/workfri').post(function(req, res) {
                                                                          con.connect(function(err) {
                                                                              //if (err) throw err;
                                                                              con.query("Update friday set working = 1 where username = ?", [req.body.username],function (err, results) {
                                                                                if (err) throw err;
                                                                                res.status(200)
                                                                              });
                                                                            });   
                                                                          }) 
                                                                          router.route('/worksat').post(function(req, res) {
                                                                            con.connect(function(err) {
                                                                                //if (err) throw err;
                                                                                con.query("Update saturday set working = 1 where username = ?", [req.body.username],function (err, results) {
                                                                                  if (err) throw err;
                                                                                  res.status(200)
                                                                                });
                                                                              });   
                                                                            }) 
                                                                            router.route('/worksun').post(function(req, res) {
                                                                              con.connect(function(err) {
                                                                                  //if (err) throw err;
                                                                                  con.query("Update sunday set working = 1 where username = ?", [req.body.username],function (err, results) {
                                                                                    if (err) throw err;
                                                                                    res.status(200)
                                                                                  });
                                                                                });   
                                                                              }) 
                                                                              router.route('/noworkmon').post(function(req, res) {
                                                                                con.connect(function(err) {
                                                                                    //if (err) throw err;
                                                                                    con.query("Update monday set working = 0 where username = ?", [req.body.username],function (err, results) {
                                                                                      if (err) throw err;
                                                                                      res.status(200)
                                                                                    });
                                                                                  });   
                                                                                }) 

                                                                                router.route('/noworktue').post(function(req, res) {
                                                                                  con.connect(function(err) {
                                                                                      //if (err) throw err;
                                                                                      con.query("Update tuesday set working = 0 where username = ?", [req.body.username],function (err, results) {
                                                                                        if (err) throw err;
                                                                                        res.status(200)
                                                                                      });
                                                                                    });   
                                                                                  }) 
                                                                                  router.route('/noworkwed').post(function(req, res) {
                                                                                    con.connect(function(err) {
                                                                                        //if (err) throw err;
                                                                                        con.query("Update wednesday set working = 0 where username = ?", [req.body.username],function (err, results) {
                                                                                          if (err) throw err;
                                                                                          res.status(200)
                                                                                        });
                                                                                      });   
                                                                                    }) 
                                                                                    router.route('/noworkthu').post(function(req, res) {
                                                                                      con.connect(function(err) {
                                                                                          //if (err) throw err;
                                                                                          con.query("Update thursday set working = 0 where username = ?", [req.body.username],function (err, results) {
                                                                                            if (err) throw err;
                                                                                            res.status(200)
                                                                                          });
                                                                                        });   
                                                                                      }) 
                                                                                      router.route('/noworkfri').post(function(req, res) {
                                                                                        con.connect(function(err) {
                                                                                            //if (err) throw err;
                                                                                            con.query("Update friday set working = 0 where username = ?", [req.body.username],function (err, results) {
                                                                                              if (err) throw err;
                                                                                              res.status(200)
                                                                                            });
                                                                                          });   
                                                                                        }) 
                                                                                        router.route('/noworksat').post(function(req, res) {
                                                                                          con.connect(function(err) {
                                                                                              //if (err) throw err;
                                                                                              con.query("Update saturday set working = 0 where username = ?", [req.body.username],function (err, results) {
                                                                                                if (err) throw err;
                                                                                                res.status(200)
                                                                                              });
                                                                                            });   
                                                                                          }) 
                                                                                          router.route('/noworksun').post(function(req, res) {
                                                                                            con.connect(function(err) {
                                                                                                //if (err) throw err;
                                                                                                con.query("Update sunday set working = 0 where username = ?", [req.body.username],function (err, results) {
                                                                                                  if (err) throw err;
                                                                                                  res.status(200)
                                                                                                });
                                                                                              });   
                                                                                            }) 
                                                                                