var mysql = require('mysql');

var con = mysql.createConnection({
  host: "suttonnet.tk",
  user: "tutoringadmin",
  password: "math4me!",
  database: "tutoring"
});

//  con.connect(function(err) {
//    if (err) throw err;
//    console.log("Connected!");
//  });


con.connect(function(err) {
  if (err) throw err;
  con.query("SELECT * FROM coursesNames", function (err, result, fields) {
    if (err) throw err;
    console.log(result);
  });
});




// var removeDocument = function(data, collectionName, callback) {

//     MongoClient.connect(url, function(err, client) {
//         assert.equal(null, err);
//         const db = client.db("privateTutoring");
//         var collection = db.collection(collectionName);
//         // Insert a documents
//         collection.deleteMany(data);
//         callback();
//         client.close();
//       });
// }

// var findDocuments = function(data, collectionName, callback) {

//     MongoClient.connect(url, function(err, client) {
//         assert.equal(null, err);
//         const db = client.db("privateTutoring");
//         var collection = db.collection(collectionName);
//         // Insert a documents
//         collection.find(data).toArray(function(err, docs) {
//             assert.equal(err, null);
//             console.log("Searched for documents successfully");
//             callback(docs);
//           });
//         client.close();
//       });
// }
// module.exports = {
//     insertDocument: insertDocument,
//     removeDocument: removeDocument,
//     findDocuments: findDocuments
// }